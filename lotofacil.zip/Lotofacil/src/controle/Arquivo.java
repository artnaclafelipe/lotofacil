/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author felipe
 */
public class Arquivo extends java.io.File {
    
    private java.io.FileInputStream  mecanismoDeEntrada;
    private java.io.FileOutputStream mecanismoDeSaida;
    
    public Arquivo(String caminhoParaAruivo) throws Exception {
        super(caminhoParaAruivo);
        if(!this.exists()){
            int q=-1;
            q=JOptionPane.showConfirmDialog(null,"Arquivo "+caminhoParaAruivo+
            " nao existe, deseja cria-lo?");
            if(q>0)return;
            
            if(!this.createNewFile())
                throw new Exception("Nao foi possivel criar arquivo:"
                +caminhoParaAruivo+", abortando...");
        }
            
        if(!this.canRead())
            throw new Exception("Nao eh possivel proceder com operaçao de leitura"
            +" no arquivo:"+caminhoParaAruivo+", abortando...");
        
        if(!this.canWrite())
            throw new Exception("Nao eh possivel proceder com operaçao de escrita"
            +" no arquivo:"+caminhoParaAruivo+", abortando...");
        
        
        
    }
    
}
