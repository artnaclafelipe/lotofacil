/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 *
 * @author felipe
 */

public class JNovoJogoIntrnFrame extends javax.swing.JInternalFrame {

    private String TITULODAJANELA="Novo-Jogo#";
    private static int    ORDEMDAJANELA;
    private javax.swing.JButton  butaoDeAcesso;
    private int  indiceListagemDeVolante;
    private java.util.ArrayList<modelo.Volante> listagemDeVolante;
    private static final String NUMEROSZERO="00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00";
    private javax.swing.JPanel panelDaListagem;
    private javax.swing.JDesktopPane dskPane;
    private Thread exePlanoDeFundo;
    visao.JAguardeDlg dlgAguarde;
    /**
     * Creates new form JNovoJogoIntrnFrame
     */
        public JNovoJogoIntrnFrame(javax.swing.JDesktopPane dskPane,
           javax.swing.JPanel panelDaListagem,
           java.util.ArrayList<modelo.Volante> listagemDeVolante,
           String tituloDaJanela) {
            
            initComponents();
            dskPane.add(this);
            this.listagemDeVolante=listagemDeVolante;
            
            this.dlgAguarde=null;
        
             setTitle("ResultadoDePesquisa#"+tituloDaJanela);
        
        butaoDeAcesso = new javax.swing.JButton(getTitle());
        butaoDeAcesso.setPreferredSize(new java.awt.Dimension(460,70));
        butaoDeAcesso.setMinimumSize(new java.awt.Dimension(440,70));
        butaoDeAcesso.setMaximumSize(new java.awt.Dimension(440,70));
        butaoDeAcesso.setVisible(true);
        butaoDeAcesso.setAlignmentX(Component.CENTER_ALIGNMENT);
        butaoDeAcesso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JNovoJogoIntrnFrame.this.grabFocus();
                JNovoJogoIntrnFrame.this.moveToFront();
            }
        });

        
        panelDaListagem.add(butaoDeAcesso);
        
        vermelharTudo();
        
        indiceListagemDeVolante=-1;
        
        atualizarRotuloQuantidadeDaListagemDeVolante(-1);
        
        if(listagemDeVolante.size()>0)jmnuItemIrParaPrimeiroCartaoActionPerformedPrivado();
        
        setVisible(true);
            
        }
        
    public JNovoJogoIntrnFrame(javax.swing.JDesktopPane dskPane,
           javax.swing.JPanel panelDaListagem) {
        initComponents();
        
        dskPane.add(this);
        
        this.dskPane=dskPane;
        this.panelDaListagem=panelDaListagem;
        this.dlgAguarde=null;
        
        ORDEMDAJANELA=(new java.util.Random().nextInt(99999000-1)+1);
        setTitle("0:0"+TITULODAJANELA+String.valueOf(ORDEMDAJANELA));
        
        butaoDeAcesso = new javax.swing.JButton(getTitle());
        butaoDeAcesso.setPreferredSize(new java.awt.Dimension(460,70));
        butaoDeAcesso.setMinimumSize(new java.awt.Dimension(440,70));
        butaoDeAcesso.setMaximumSize(new java.awt.Dimension(440,70));
        butaoDeAcesso.setVisible(true);
        butaoDeAcesso.setAlignmentX(Component.CENTER_ALIGNMENT);
        butaoDeAcesso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JNovoJogoIntrnFrame.this.grabFocus();
                JNovoJogoIntrnFrame.this.moveToFront();
            }
        });

        
        panelDaListagem.add(butaoDeAcesso);
        
        vermelharTudo();
        
        indiceListagemDeVolante=-1;
        
                listagemDeVolante = new java.util.ArrayList();
        
        try
        {
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16,17"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16,17,18"));
            
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16,17"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16,17,18"));
            
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16,17"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16,17,18"));
            
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16,17"));
            listagemDeVolante.add(new modelo.Volante("09,08,07,06,05,04,03,02,01,10,11,12,13,14,15,16,17,18"));
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:construtor()\n"
            +e.getMessage());
        }
        
        atualizarRotuloQuantidadeDaListagemDeVolante(-1);
        
        if(listagemDeVolante.size()>0)jmnuItemIrParaPrimeiroCartaoActionPerformedPrivado();
        
        setVisible(true);
    }

    private void atualizarRotuloQuantidadeDaListagemDeVolante(int indiceCorrente){
        String posicao=String.valueOf(indiceCorrente)+":"+String.valueOf(listagemDeVolante.size());
        String titulo=posicao+TITULODAJANELA+String.valueOf(ORDEMDAJANELA);
        setTitle(titulo);
        butaoDeAcesso.setText(titulo);
    }
    
    public void aplicarNomeAoJogo(String nome){
        TITULODAJANELA=nome;
    }
    
    public String obterNomeDoJogo(){
        return TITULODAJANELA;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpnelSimbolo = new javax.swing.JPanel();
        jlblSimbolo01 = new javax.swing.JLabel();
        jpnelSimboloAzul012 = new javax.swing.JPanel();
        jpnelSimboloAzul011 = new javax.swing.JPanel();
        jlblSimbolo02 = new javax.swing.JLabel();
        jpnelSimboloAzul021 = new javax.swing.JPanel();
        jpnelSimboloVermelho021 = new javax.swing.JPanel();
        jlblSimbolo03 = new javax.swing.JLabel();
        jpnelSimboloVermelho031 = new javax.swing.JPanel();
        jpnelSimboloVermelho032 = new javax.swing.JPanel();
        jlblSimbolo04 = new javax.swing.JLabel();
        jpnelSimboloVermelho041 = new javax.swing.JPanel();
        jpnelSimboloAzul041 = new javax.swing.JPanel();
        jlblSimboloPrecoSorteio11 = new javax.swing.JLabel();
        jlblSimboloPrecoSorteio12 = new javax.swing.JLabel();
        jlblSimboloPrecoSorteio14 = new javax.swing.JLabel();
        jlblSimboloPrecoSorteio13 = new javax.swing.JLabel();
        jlblSimboloPrecoSorteio15 = new javax.swing.JLabel();
        jlblSimboloPrecoPagar15 = new javax.swing.JLabel();
        jlblSimboloPrecoPagar16 = new javax.swing.JLabel();
        jlblSimboloPrecoPagar17 = new javax.swing.JLabel();
        jlblSimboloPrecoPagar18 = new javax.swing.JLabel();
        jtxtfSimboloPrecoSorteio11 = new javax.swing.JFormattedTextField();
        jtxtfSimboloPrecoSorteio12 = new javax.swing.JFormattedTextField();
        jtxtfSimboloPrecoSorteio13 = new javax.swing.JFormattedTextField();
        jtxtfSimboloPrecoSorteio14 = new javax.swing.JFormattedTextField();
        jtxtfSimboloPrecoSorteio15 = new javax.swing.JFormattedTextField();
        jpnelPincel = new javax.swing.JPanel();
        jlblPincelAzul = new javax.swing.JLabel();
        jpnelPincelAzul = new javax.swing.JPanel();
        jpnelPincelVermelho = new javax.swing.JPanel();
        jlblPincelVermelho = new javax.swing.JLabel();
        jlblPincelVermelharTudo = new javax.swing.JLabel();
        jpnelPincelVermelharTudo02 = new javax.swing.JPanel();
        jpnelPincelVermelharTudo01 = new javax.swing.JPanel();
        jpnelPincelVermelharTudo3 = new javax.swing.JPanel();
        jpnelPincelVermelharTudo2 = new javax.swing.JPanel();
        jlblPincelPintarNumero = new javax.swing.JLabel();
        jpnelPincelPintarNumero01 = new javax.swing.JPanel();
        jlblPincelPrecoDoCartao = new javax.swing.JLabel();
        jpnelNumero = new javax.swing.JPanel();
        jpnelNumero01 = new javax.swing.JPanel();
        jlblNumero01 = new javax.swing.JLabel();
        jpnelNumero02 = new javax.swing.JPanel();
        jlblNumero02 = new javax.swing.JLabel();
        jpnelNumero03 = new javax.swing.JPanel();
        jlblNumero03 = new javax.swing.JLabel();
        jpnelNumero04 = new javax.swing.JPanel();
        jlblNumero04 = new javax.swing.JLabel();
        jpnelNumero05 = new javax.swing.JPanel();
        jlblNumero05 = new javax.swing.JLabel();
        jpnelNumero06 = new javax.swing.JPanel();
        jlblNumero06 = new javax.swing.JLabel();
        jpnelNumero07 = new javax.swing.JPanel();
        jlblNumero07 = new javax.swing.JLabel();
        jpnelNumero08 = new javax.swing.JPanel();
        jlblNumero08 = new javax.swing.JLabel();
        jpnelNumero09 = new javax.swing.JPanel();
        jlblNumero09 = new javax.swing.JLabel();
        jpnelNumero10 = new javax.swing.JPanel();
        jlblNumero10 = new javax.swing.JLabel();
        jpnelNumero11 = new javax.swing.JPanel();
        jlblNumero11 = new javax.swing.JLabel();
        jpnelNumero12 = new javax.swing.JPanel();
        jlblNumero12 = new javax.swing.JLabel();
        jpnelNumero13 = new javax.swing.JPanel();
        jlblNumero13 = new javax.swing.JLabel();
        jpnelNumero14 = new javax.swing.JPanel();
        jlblNumero14 = new javax.swing.JLabel();
        jpnelNumero15 = new javax.swing.JPanel();
        jlblNumero15 = new javax.swing.JLabel();
        jpnelNumero16 = new javax.swing.JPanel();
        jlblNumero16 = new javax.swing.JLabel();
        jpnelNumero17 = new javax.swing.JPanel();
        jlblNumero17 = new javax.swing.JLabel();
        jpnelNumero18 = new javax.swing.JPanel();
        jlblNumero18 = new javax.swing.JLabel();
        jpnelNumero19 = new javax.swing.JPanel();
        jlblNumero19 = new javax.swing.JLabel();
        jpnelNumero20 = new javax.swing.JPanel();
        jlblNumero20 = new javax.swing.JLabel();
        jpnelNumero21 = new javax.swing.JPanel();
        jlblNumero21 = new javax.swing.JLabel();
        jpnelNumero22 = new javax.swing.JPanel();
        jlblNumero22 = new javax.swing.JLabel();
        jpnelNumero23 = new javax.swing.JPanel();
        jlblNumero23 = new javax.swing.JLabel();
        jpnelNumero24 = new javax.swing.JPanel();
        jlblNumero24 = new javax.swing.JLabel();
        jpnelNumero25 = new javax.swing.JPanel();
        jlblNumero25 = new javax.swing.JLabel();
        jlblPincelTotalPintadoAzul = new javax.swing.JLabel();
        jlblPincelNumero = new javax.swing.JLabel();
        jpnelNumeroPintado = new javax.swing.JPanel();
        jlblNumeroPintado = new javax.swing.JLabel();
        jbtnIncluirCartao = new javax.swing.JButton();
        jbtnIrParaPrimeiroCartao = new javax.swing.JButton();
        jbtnIrParaProximoCartao = new javax.swing.JButton();
        jbtnIrParaAnteriorCartao = new javax.swing.JButton();
        jbtnIrParaUltimoCartao = new javax.swing.JButton();
        jbtnIrParaEspecificoCartao = new javax.swing.JButton();
        jbtnExcluirCartao = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jbtnRestaurarCartaoSalvo = new javax.swing.JButton();
        jbtnSalvarCartao = new javax.swing.JButton();
        jtxtfVolantePreco = new javax.swing.JTextField();
        jlblVolantePreco = new javax.swing.JLabel();
        jbtnVolantePreco = new javax.swing.JButton();
        jmnuBarPrincipal = new javax.swing.JMenuBar();
        jmnuPainel = new javax.swing.JMenu();
        jmnuItemPincelAzul = new javax.swing.JMenuItem();
        jmnuItemPincelVermelho = new javax.swing.JMenuItem();
        jmnuItemVermelharTudo = new javax.swing.JMenuItem();
        jmnuItemNumeros = new javax.swing.JMenu();
        jmnuItemNumeros01 = new javax.swing.JMenuItem();
        jmnuItemNumeros02 = new javax.swing.JMenuItem();
        jmnuItemNumeros03 = new javax.swing.JMenuItem();
        jmnuItemNumeros04 = new javax.swing.JMenuItem();
        jmnuItemNumeros05 = new javax.swing.JMenuItem();
        jmnuItemNumeros06 = new javax.swing.JMenuItem();
        jmnuItemNumeros07 = new javax.swing.JMenuItem();
        jmnuItemNumeros08 = new javax.swing.JMenuItem();
        jmnuItemNumeros09 = new javax.swing.JMenuItem();
        jmnuItemNumeros00 = new javax.swing.JMenuItem();
        jmnuItemNumerosZerar = new javax.swing.JMenuItem();
        jmnuItemNumerosApagar = new javax.swing.JMenuItem();
        jmnuItemNumerosPintarNumero = new javax.swing.JMenuItem();
        jmnuItemIrParaPrimeiroCartao = new javax.swing.JMenuItem();
        jmnuItemIrParaProximoCartao = new javax.swing.JMenuItem();
        jmnuItemIrParaAnteriorCartao = new javax.swing.JMenuItem();
        jmnuItemIrParaUltimoCartao = new javax.swing.JMenuItem();
        jmnuItemIrParaEspecificoCartao = new javax.swing.JMenuItem();
        jmnuItemIncluirCartao = new javax.swing.JMenuItem();
        jmnuItemExcluirCartao = new javax.swing.JMenuItem();
        jmnuItemFechar = new javax.swing.JMenuItem();
        jmnuItemRestaurarCartaoSalvo = new javax.swing.JMenuItem();
        jmnuItemSalvarCartao = new javax.swing.JMenuItem();
        jmnuItemObterEntradaComTeclado = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setClosable(true);
        setIconifiable(true);
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosing(evt);
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameActivated(evt);
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        jpnelSimbolo.setBackground(java.awt.Color.black);

        jlblSimbolo01.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimbolo01.setForeground(java.awt.Color.white);
        jlblSimbolo01.setText("01");

        jpnelSimboloAzul012.setBackground(java.awt.Color.blue);

        javax.swing.GroupLayout jpnelSimboloAzul012Layout = new javax.swing.GroupLayout(jpnelSimboloAzul012);
        jpnelSimboloAzul012.setLayout(jpnelSimboloAzul012Layout);
        jpnelSimboloAzul012Layout.setHorizontalGroup(
            jpnelSimboloAzul012Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelSimboloAzul012Layout.setVerticalGroup(
            jpnelSimboloAzul012Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jpnelSimboloAzul011.setBackground(java.awt.Color.blue);

        javax.swing.GroupLayout jpnelSimboloAzul011Layout = new javax.swing.GroupLayout(jpnelSimboloAzul011);
        jpnelSimboloAzul011.setLayout(jpnelSimboloAzul011Layout);
        jpnelSimboloAzul011Layout.setHorizontalGroup(
            jpnelSimboloAzul011Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelSimboloAzul011Layout.setVerticalGroup(
            jpnelSimboloAzul011Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jlblSimbolo02.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimbolo02.setForeground(java.awt.Color.white);
        jlblSimbolo02.setText("02");

        jpnelSimboloAzul021.setBackground(java.awt.Color.blue);

        javax.swing.GroupLayout jpnelSimboloAzul021Layout = new javax.swing.GroupLayout(jpnelSimboloAzul021);
        jpnelSimboloAzul021.setLayout(jpnelSimboloAzul021Layout);
        jpnelSimboloAzul021Layout.setHorizontalGroup(
            jpnelSimboloAzul021Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelSimboloAzul021Layout.setVerticalGroup(
            jpnelSimboloAzul021Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jpnelSimboloVermelho021.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelSimboloVermelho021Layout = new javax.swing.GroupLayout(jpnelSimboloVermelho021);
        jpnelSimboloVermelho021.setLayout(jpnelSimboloVermelho021Layout);
        jpnelSimboloVermelho021Layout.setHorizontalGroup(
            jpnelSimboloVermelho021Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelSimboloVermelho021Layout.setVerticalGroup(
            jpnelSimboloVermelho021Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jlblSimbolo03.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimbolo03.setForeground(java.awt.Color.white);
        jlblSimbolo03.setText("03");

        jpnelSimboloVermelho031.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelSimboloVermelho031Layout = new javax.swing.GroupLayout(jpnelSimboloVermelho031);
        jpnelSimboloVermelho031.setLayout(jpnelSimboloVermelho031Layout);
        jpnelSimboloVermelho031Layout.setHorizontalGroup(
            jpnelSimboloVermelho031Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelSimboloVermelho031Layout.setVerticalGroup(
            jpnelSimboloVermelho031Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jpnelSimboloVermelho032.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelSimboloVermelho032Layout = new javax.swing.GroupLayout(jpnelSimboloVermelho032);
        jpnelSimboloVermelho032.setLayout(jpnelSimboloVermelho032Layout);
        jpnelSimboloVermelho032Layout.setHorizontalGroup(
            jpnelSimboloVermelho032Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelSimboloVermelho032Layout.setVerticalGroup(
            jpnelSimboloVermelho032Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jlblSimbolo04.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimbolo04.setForeground(java.awt.Color.white);
        jlblSimbolo04.setText("04");

        jpnelSimboloVermelho041.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelSimboloVermelho041Layout = new javax.swing.GroupLayout(jpnelSimboloVermelho041);
        jpnelSimboloVermelho041.setLayout(jpnelSimboloVermelho041Layout);
        jpnelSimboloVermelho041Layout.setHorizontalGroup(
            jpnelSimboloVermelho041Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelSimboloVermelho041Layout.setVerticalGroup(
            jpnelSimboloVermelho041Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jpnelSimboloAzul041.setBackground(java.awt.Color.blue
        );

        javax.swing.GroupLayout jpnelSimboloAzul041Layout = new javax.swing.GroupLayout(jpnelSimboloAzul041);
        jpnelSimboloAzul041.setLayout(jpnelSimboloAzul041Layout);
        jpnelSimboloAzul041Layout.setHorizontalGroup(
            jpnelSimboloAzul041Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelSimboloAzul041Layout.setVerticalGroup(
            jpnelSimboloAzul041Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jlblSimboloPrecoSorteio11.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoSorteio11.setForeground(java.awt.Color.white);
        jlblSimboloPrecoSorteio11.setText("11");

        jlblSimboloPrecoSorteio12.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoSorteio12.setForeground(java.awt.Color.white);
        jlblSimboloPrecoSorteio12.setText("12");

        jlblSimboloPrecoSorteio14.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoSorteio14.setForeground(java.awt.Color.white);
        jlblSimboloPrecoSorteio14.setText("14");

        jlblSimboloPrecoSorteio13.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoSorteio13.setForeground(java.awt.Color.white);
        jlblSimboloPrecoSorteio13.setText("13");

        jlblSimboloPrecoSorteio15.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoSorteio15.setForeground(java.awt.Color.white);
        jlblSimboloPrecoSorteio15.setText("15");

        jlblSimboloPrecoPagar15.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoPagar15.setForeground(java.awt.Color.white);
        jlblSimboloPrecoPagar15.setText("15 - R$ 2,00");

        jlblSimboloPrecoPagar16.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoPagar16.setForeground(java.awt.Color.white);
        jlblSimboloPrecoPagar16.setText("16 - R$ 32,00");

        jlblSimboloPrecoPagar17.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoPagar17.setForeground(java.awt.Color.white);
        jlblSimboloPrecoPagar17.setText("17 - R$ 272,00");

        jlblSimboloPrecoPagar18.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblSimboloPrecoPagar18.setForeground(java.awt.Color.white);
        jlblSimboloPrecoPagar18.setText("18 - R$ 1632,00");

        jtxtfSimboloPrecoSorteio11.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        jtxtfSimboloPrecoSorteio11.setText("4.00");
        jtxtfSimboloPrecoSorteio11.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jtxtfSimboloPrecoSorteio11FocusLost(evt);
            }
        });
        jtxtfSimboloPrecoSorteio11.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jtxtfSimboloPrecoSorteio11KeyPressed(evt);
            }
        });

        jtxtfSimboloPrecoSorteio12.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        jtxtfSimboloPrecoSorteio12.setText("8.00");
        jtxtfSimboloPrecoSorteio12.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jtxtfSimboloPrecoSorteio12FocusLost(evt);
            }
        });
        jtxtfSimboloPrecoSorteio12.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jtxtfSimboloPrecoSorteio12KeyPressed(evt);
            }
        });

        jtxtfSimboloPrecoSorteio13.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        jtxtfSimboloPrecoSorteio13.setText("20.00");
        jtxtfSimboloPrecoSorteio13.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jtxtfSimboloPrecoSorteio13FocusLost(evt);
            }
        });
        jtxtfSimboloPrecoSorteio13.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jtxtfSimboloPrecoSorteio13KeyPressed(evt);
            }
        });

        jtxtfSimboloPrecoSorteio14.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        jtxtfSimboloPrecoSorteio14.setText("0.00");
        jtxtfSimboloPrecoSorteio14.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jtxtfSimboloPrecoSorteio14FocusLost(evt);
            }
        });
        jtxtfSimboloPrecoSorteio14.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jtxtfSimboloPrecoSorteio14KeyPressed(evt);
            }
        });

        jtxtfSimboloPrecoSorteio15.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        jtxtfSimboloPrecoSorteio15.setText("0.00");
        jtxtfSimboloPrecoSorteio15.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jtxtfSimboloPrecoSorteio15FocusLost(evt);
            }
        });
        jtxtfSimboloPrecoSorteio15.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jtxtfSimboloPrecoSorteio15KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSimboloLayout = new javax.swing.GroupLayout(jpnelSimbolo);
        jpnelSimbolo.setLayout(jpnelSimboloLayout);
        jpnelSimboloLayout.setHorizontalGroup(
            jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSimboloLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelSimboloLayout.createSequentialGroup()
                        .addComponent(jlblSimboloPrecoSorteio11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxtfSimboloPrecoSorteio11, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelSimboloLayout.createSequentialGroup()
                        .addComponent(jlblSimboloPrecoSorteio12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxtfSimboloPrecoSorteio12, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelSimboloLayout.createSequentialGroup()
                        .addComponent(jlblSimboloPrecoSorteio13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxtfSimboloPrecoSorteio13, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelSimboloLayout.createSequentialGroup()
                        .addComponent(jlblSimboloPrecoSorteio14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxtfSimboloPrecoSorteio14, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelSimboloLayout.createSequentialGroup()
                        .addComponent(jlblSimboloPrecoSorteio15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxtfSimboloPrecoSorteio15, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jlblSimboloPrecoPagar18)
                    .addComponent(jlblSimboloPrecoPagar17)
                    .addComponent(jlblSimboloPrecoPagar16)
                    .addComponent(jlblSimboloPrecoPagar15)
                    .addGroup(jpnelSimboloLayout.createSequentialGroup()
                        .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblSimbolo04)
                            .addComponent(jlblSimbolo03)
                            .addComponent(jlblSimbolo02)
                            .addComponent(jlblSimbolo01))
                        .addGap(38, 38, 38)
                        .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelSimboloLayout.createSequentialGroup()
                                .addComponent(jpnelSimboloAzul011, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelSimboloAzul012, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelSimboloLayout.createSequentialGroup()
                                .addComponent(jpnelSimboloAzul021, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelSimboloVermelho021, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelSimboloLayout.createSequentialGroup()
                                .addComponent(jpnelSimboloVermelho031, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelSimboloVermelho032, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelSimboloLayout.createSequentialGroup()
                                .addComponent(jpnelSimboloVermelho041, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelSimboloAzul041, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jpnelSimboloLayout.setVerticalGroup(
            jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSimboloLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelSimboloAzul011, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelSimboloAzul012, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblSimbolo01))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelSimboloAzul021, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelSimboloVermelho021, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblSimbolo02))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelSimboloVermelho031, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelSimboloVermelho032, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblSimbolo03))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelSimboloVermelho041, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelSimboloAzul041, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlblSimbolo04))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblSimboloPrecoSorteio11)
                    .addComponent(jtxtfSimboloPrecoSorteio11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblSimboloPrecoSorteio12)
                    .addComponent(jtxtfSimboloPrecoSorteio12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblSimboloPrecoSorteio13)
                    .addComponent(jtxtfSimboloPrecoSorteio13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlblSimboloPrecoSorteio14)
                    .addComponent(jtxtfSimboloPrecoSorteio14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelSimboloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlblSimboloPrecoSorteio15)
                    .addComponent(jtxtfSimboloPrecoSorteio15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblSimboloPrecoPagar18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblSimboloPrecoPagar17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblSimboloPrecoPagar16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblSimboloPrecoPagar15)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        jpnelPincel.setBackground(java.awt.Color.black);

        jlblPincelAzul.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblPincelAzul.setForeground(java.awt.Color.blue);
        jlblPincelAzul.setText("F1");

        jpnelPincelAzul.setBackground(java.awt.Color.blue);

        javax.swing.GroupLayout jpnelPincelAzulLayout = new javax.swing.GroupLayout(jpnelPincelAzul);
        jpnelPincelAzul.setLayout(jpnelPincelAzulLayout);
        jpnelPincelAzulLayout.setHorizontalGroup(
            jpnelPincelAzulLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelPincelAzulLayout.setVerticalGroup(
            jpnelPincelAzulLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jpnelPincelVermelho.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelPincelVermelhoLayout = new javax.swing.GroupLayout(jpnelPincelVermelho);
        jpnelPincelVermelho.setLayout(jpnelPincelVermelhoLayout);
        jpnelPincelVermelhoLayout.setHorizontalGroup(
            jpnelPincelVermelhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelPincelVermelhoLayout.setVerticalGroup(
            jpnelPincelVermelhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jlblPincelVermelho.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblPincelVermelho.setForeground(java.awt.Color.white);
        jlblPincelVermelho.setText("F2");

        jlblPincelVermelharTudo.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblPincelVermelharTudo.setForeground(java.awt.Color.white);
        jlblPincelVermelharTudo.setText("F3");

        jpnelPincelVermelharTudo02.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelPincelVermelharTudo02Layout = new javax.swing.GroupLayout(jpnelPincelVermelharTudo02);
        jpnelPincelVermelharTudo02.setLayout(jpnelPincelVermelharTudo02Layout);
        jpnelPincelVermelharTudo02Layout.setHorizontalGroup(
            jpnelPincelVermelharTudo02Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelPincelVermelharTudo02Layout.setVerticalGroup(
            jpnelPincelVermelharTudo02Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jpnelPincelVermelharTudo01.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelPincelVermelharTudo01Layout = new javax.swing.GroupLayout(jpnelPincelVermelharTudo01);
        jpnelPincelVermelharTudo01.setLayout(jpnelPincelVermelharTudo01Layout);
        jpnelPincelVermelharTudo01Layout.setHorizontalGroup(
            jpnelPincelVermelharTudo01Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelPincelVermelharTudo01Layout.setVerticalGroup(
            jpnelPincelVermelharTudo01Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jpnelPincelVermelharTudo3.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelPincelVermelharTudo3Layout = new javax.swing.GroupLayout(jpnelPincelVermelharTudo3);
        jpnelPincelVermelharTudo3.setLayout(jpnelPincelVermelharTudo3Layout);
        jpnelPincelVermelharTudo3Layout.setHorizontalGroup(
            jpnelPincelVermelharTudo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelPincelVermelharTudo3Layout.setVerticalGroup(
            jpnelPincelVermelharTudo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jpnelPincelVermelharTudo2.setBackground(java.awt.Color.red);

        javax.swing.GroupLayout jpnelPincelVermelharTudo2Layout = new javax.swing.GroupLayout(jpnelPincelVermelharTudo2);
        jpnelPincelVermelharTudo2.setLayout(jpnelPincelVermelharTudo2Layout);
        jpnelPincelVermelharTudo2Layout.setHorizontalGroup(
            jpnelPincelVermelharTudo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 23, Short.MAX_VALUE)
        );
        jpnelPincelVermelharTudo2Layout.setVerticalGroup(
            jpnelPincelVermelharTudo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 22, Short.MAX_VALUE)
        );

        jlblPincelPintarNumero.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblPincelPintarNumero.setForeground(java.awt.Color.white);
        jlblPincelPintarNumero.setText("ENTER");

        jpnelPincelPintarNumero01.setBackground(java.awt.Color.blue);

        javax.swing.GroupLayout jpnelPincelPintarNumero01Layout = new javax.swing.GroupLayout(jpnelPincelPintarNumero01);
        jpnelPincelPintarNumero01.setLayout(jpnelPincelPintarNumero01Layout);
        jpnelPincelPintarNumero01Layout.setHorizontalGroup(
            jpnelPincelPintarNumero01Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 58, Short.MAX_VALUE)
        );
        jpnelPincelPintarNumero01Layout.setVerticalGroup(
            jpnelPincelPintarNumero01Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jlblPincelPrecoDoCartao.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblPincelPrecoDoCartao.setForeground(java.awt.Color.white);
        jlblPincelPrecoDoCartao.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblPincelPrecoDoCartao.setText("R$ 0,00");

        javax.swing.GroupLayout jpnelPincelLayout = new javax.swing.GroupLayout(jpnelPincel);
        jpnelPincel.setLayout(jpnelPincelLayout);
        jpnelPincelLayout.setHorizontalGroup(
            jpnelPincelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelPincelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblPincelAzul)
                .addGap(3, 3, 3)
                .addComponent(jpnelPincelAzul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblPincelVermelho)
                .addGap(3, 3, 3)
                .addComponent(jpnelPincelVermelho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblPincelVermelharTudo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelPincelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelPincelLayout.createSequentialGroup()
                        .addComponent(jpnelPincelVermelharTudo01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelPincelVermelharTudo02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelPincelLayout.createSequentialGroup()
                        .addComponent(jpnelPincelVermelharTudo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelPincelVermelharTudo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlblPincelPintarNumero)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpnelPincelPintarNumero01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblPincelPrecoDoCartao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnelPincelLayout.setVerticalGroup(
            jpnelPincelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelPincelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlblPincelPintarNumero)
                .addGap(27, 27, 27))
            .addGroup(jpnelPincelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelPincelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelPincelLayout.createSequentialGroup()
                        .addGroup(jpnelPincelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jpnelPincelVermelharTudo02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelPincelVermelharTudo01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addGroup(jpnelPincelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jpnelPincelVermelharTudo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelPincelVermelharTudo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelPincelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jpnelPincelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlblPincelVermelharTudo)
                            .addComponent(jpnelPincelVermelho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblPincelVermelho)
                            .addComponent(jpnelPincelAzul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlblPincelAzul))
                        .addGap(24, 24, 24))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelPincelLayout.createSequentialGroup()
                        .addComponent(jpnelPincelPintarNumero01, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
            .addGroup(jpnelPincelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jlblPincelPrecoDoCartao)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jpnelNumero.setBackground(java.awt.Color.black);

        jpnelNumero01.setBackground(java.awt.Color.red);

        jlblNumero01.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero01.setForeground(java.awt.Color.white);
        jlblNumero01.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero01.setText("01");

        javax.swing.GroupLayout jpnelNumero01Layout = new javax.swing.GroupLayout(jpnelNumero01);
        jpnelNumero01.setLayout(jpnelNumero01Layout);
        jpnelNumero01Layout.setHorizontalGroup(
            jpnelNumero01Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero01, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero01Layout.setVerticalGroup(
            jpnelNumero01Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero01, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero02.setBackground(java.awt.Color.red);

        jlblNumero02.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero02.setForeground(java.awt.Color.white);
        jlblNumero02.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero02.setText("02");

        javax.swing.GroupLayout jpnelNumero02Layout = new javax.swing.GroupLayout(jpnelNumero02);
        jpnelNumero02.setLayout(jpnelNumero02Layout);
        jpnelNumero02Layout.setHorizontalGroup(
            jpnelNumero02Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero02, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero02Layout.setVerticalGroup(
            jpnelNumero02Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero02, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero03.setBackground(java.awt.Color.red);

        jlblNumero03.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero03.setForeground(java.awt.Color.white);
        jlblNumero03.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero03.setText("03");

        javax.swing.GroupLayout jpnelNumero03Layout = new javax.swing.GroupLayout(jpnelNumero03);
        jpnelNumero03.setLayout(jpnelNumero03Layout);
        jpnelNumero03Layout.setHorizontalGroup(
            jpnelNumero03Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero03, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero03Layout.setVerticalGroup(
            jpnelNumero03Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero03, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero04.setBackground(java.awt.Color.red);

        jlblNumero04.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero04.setForeground(java.awt.Color.white);
        jlblNumero04.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero04.setText("04");

        javax.swing.GroupLayout jpnelNumero04Layout = new javax.swing.GroupLayout(jpnelNumero04);
        jpnelNumero04.setLayout(jpnelNumero04Layout);
        jpnelNumero04Layout.setHorizontalGroup(
            jpnelNumero04Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero04, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero04Layout.setVerticalGroup(
            jpnelNumero04Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero04, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero05.setBackground(java.awt.Color.red);

        jlblNumero05.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero05.setForeground(java.awt.Color.white);
        jlblNumero05.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero05.setText("05");

        javax.swing.GroupLayout jpnelNumero05Layout = new javax.swing.GroupLayout(jpnelNumero05);
        jpnelNumero05.setLayout(jpnelNumero05Layout);
        jpnelNumero05Layout.setHorizontalGroup(
            jpnelNumero05Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero05, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero05Layout.setVerticalGroup(
            jpnelNumero05Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero05, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero06.setBackground(java.awt.Color.red);

        jlblNumero06.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero06.setForeground(java.awt.Color.white);
        jlblNumero06.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero06.setText("06");

        javax.swing.GroupLayout jpnelNumero06Layout = new javax.swing.GroupLayout(jpnelNumero06);
        jpnelNumero06.setLayout(jpnelNumero06Layout);
        jpnelNumero06Layout.setHorizontalGroup(
            jpnelNumero06Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero06, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero06Layout.setVerticalGroup(
            jpnelNumero06Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero06, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero07.setBackground(java.awt.Color.red);

        jlblNumero07.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero07.setForeground(java.awt.Color.white);
        jlblNumero07.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero07.setText("07");

        javax.swing.GroupLayout jpnelNumero07Layout = new javax.swing.GroupLayout(jpnelNumero07);
        jpnelNumero07.setLayout(jpnelNumero07Layout);
        jpnelNumero07Layout.setHorizontalGroup(
            jpnelNumero07Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero07, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero07Layout.setVerticalGroup(
            jpnelNumero07Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero07, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero08.setBackground(java.awt.Color.red);

        jlblNumero08.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero08.setForeground(java.awt.Color.white);
        jlblNumero08.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero08.setText("08");

        javax.swing.GroupLayout jpnelNumero08Layout = new javax.swing.GroupLayout(jpnelNumero08);
        jpnelNumero08.setLayout(jpnelNumero08Layout);
        jpnelNumero08Layout.setHorizontalGroup(
            jpnelNumero08Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero08, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero08Layout.setVerticalGroup(
            jpnelNumero08Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero08, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero09.setBackground(java.awt.Color.red);

        jlblNumero09.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero09.setForeground(java.awt.Color.white);
        jlblNumero09.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero09.setText("09");

        javax.swing.GroupLayout jpnelNumero09Layout = new javax.swing.GroupLayout(jpnelNumero09);
        jpnelNumero09.setLayout(jpnelNumero09Layout);
        jpnelNumero09Layout.setHorizontalGroup(
            jpnelNumero09Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero09, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero09Layout.setVerticalGroup(
            jpnelNumero09Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero09, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero10.setBackground(java.awt.Color.red);

        jlblNumero10.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero10.setForeground(java.awt.Color.white);
        jlblNumero10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero10.setText("10");

        javax.swing.GroupLayout jpnelNumero10Layout = new javax.swing.GroupLayout(jpnelNumero10);
        jpnelNumero10.setLayout(jpnelNumero10Layout);
        jpnelNumero10Layout.setHorizontalGroup(
            jpnelNumero10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero10, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero10Layout.setVerticalGroup(
            jpnelNumero10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero10, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero11.setBackground(java.awt.Color.red);

        jlblNumero11.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero11.setForeground(java.awt.Color.white);
        jlblNumero11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero11.setText("11");

        javax.swing.GroupLayout jpnelNumero11Layout = new javax.swing.GroupLayout(jpnelNumero11);
        jpnelNumero11.setLayout(jpnelNumero11Layout);
        jpnelNumero11Layout.setHorizontalGroup(
            jpnelNumero11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero11, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero11Layout.setVerticalGroup(
            jpnelNumero11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero11, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero12.setBackground(java.awt.Color.red);

        jlblNumero12.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero12.setForeground(java.awt.Color.white);
        jlblNumero12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero12.setText("12");

        javax.swing.GroupLayout jpnelNumero12Layout = new javax.swing.GroupLayout(jpnelNumero12);
        jpnelNumero12.setLayout(jpnelNumero12Layout);
        jpnelNumero12Layout.setHorizontalGroup(
            jpnelNumero12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero12, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero12Layout.setVerticalGroup(
            jpnelNumero12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero12, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero13.setBackground(java.awt.Color.red);

        jlblNumero13.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero13.setForeground(java.awt.Color.white);
        jlblNumero13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero13.setText("13");

        javax.swing.GroupLayout jpnelNumero13Layout = new javax.swing.GroupLayout(jpnelNumero13);
        jpnelNumero13.setLayout(jpnelNumero13Layout);
        jpnelNumero13Layout.setHorizontalGroup(
            jpnelNumero13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero13, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero13Layout.setVerticalGroup(
            jpnelNumero13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero13, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero14.setBackground(java.awt.Color.red);

        jlblNumero14.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero14.setForeground(java.awt.Color.white);
        jlblNumero14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero14.setText("14");

        javax.swing.GroupLayout jpnelNumero14Layout = new javax.swing.GroupLayout(jpnelNumero14);
        jpnelNumero14.setLayout(jpnelNumero14Layout);
        jpnelNumero14Layout.setHorizontalGroup(
            jpnelNumero14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero14, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero14Layout.setVerticalGroup(
            jpnelNumero14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero14, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero15.setBackground(java.awt.Color.red);

        jlblNumero15.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero15.setForeground(java.awt.Color.white);
        jlblNumero15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero15.setText("15");

        javax.swing.GroupLayout jpnelNumero15Layout = new javax.swing.GroupLayout(jpnelNumero15);
        jpnelNumero15.setLayout(jpnelNumero15Layout);
        jpnelNumero15Layout.setHorizontalGroup(
            jpnelNumero15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero15, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero15Layout.setVerticalGroup(
            jpnelNumero15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero15, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero16.setBackground(java.awt.Color.red);

        jlblNumero16.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero16.setForeground(java.awt.Color.white);
        jlblNumero16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero16.setText("16");

        javax.swing.GroupLayout jpnelNumero16Layout = new javax.swing.GroupLayout(jpnelNumero16);
        jpnelNumero16.setLayout(jpnelNumero16Layout);
        jpnelNumero16Layout.setHorizontalGroup(
            jpnelNumero16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero16, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero16Layout.setVerticalGroup(
            jpnelNumero16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero16, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero17.setBackground(java.awt.Color.red);

        jlblNumero17.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero17.setForeground(java.awt.Color.white);
        jlblNumero17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero17.setText("17");

        javax.swing.GroupLayout jpnelNumero17Layout = new javax.swing.GroupLayout(jpnelNumero17);
        jpnelNumero17.setLayout(jpnelNumero17Layout);
        jpnelNumero17Layout.setHorizontalGroup(
            jpnelNumero17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero17, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero17Layout.setVerticalGroup(
            jpnelNumero17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero17, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero18.setBackground(java.awt.Color.red);

        jlblNumero18.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero18.setForeground(java.awt.Color.white);
        jlblNumero18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero18.setText("18");

        javax.swing.GroupLayout jpnelNumero18Layout = new javax.swing.GroupLayout(jpnelNumero18);
        jpnelNumero18.setLayout(jpnelNumero18Layout);
        jpnelNumero18Layout.setHorizontalGroup(
            jpnelNumero18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero18, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero18Layout.setVerticalGroup(
            jpnelNumero18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero18, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero19.setBackground(java.awt.Color.red);

        jlblNumero19.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero19.setForeground(java.awt.Color.white);
        jlblNumero19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero19.setText("19");

        javax.swing.GroupLayout jpnelNumero19Layout = new javax.swing.GroupLayout(jpnelNumero19);
        jpnelNumero19.setLayout(jpnelNumero19Layout);
        jpnelNumero19Layout.setHorizontalGroup(
            jpnelNumero19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero19, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero19Layout.setVerticalGroup(
            jpnelNumero19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero19, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero20.setBackground(java.awt.Color.red);

        jlblNumero20.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero20.setForeground(java.awt.Color.white);
        jlblNumero20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero20.setText("20");

        javax.swing.GroupLayout jpnelNumero20Layout = new javax.swing.GroupLayout(jpnelNumero20);
        jpnelNumero20.setLayout(jpnelNumero20Layout);
        jpnelNumero20Layout.setHorizontalGroup(
            jpnelNumero20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero20, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero20Layout.setVerticalGroup(
            jpnelNumero20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero20, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero21.setBackground(java.awt.Color.red);

        jlblNumero21.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero21.setForeground(java.awt.Color.white);
        jlblNumero21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero21.setText("21");

        javax.swing.GroupLayout jpnelNumero21Layout = new javax.swing.GroupLayout(jpnelNumero21);
        jpnelNumero21.setLayout(jpnelNumero21Layout);
        jpnelNumero21Layout.setHorizontalGroup(
            jpnelNumero21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero21, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero21Layout.setVerticalGroup(
            jpnelNumero21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero21, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero22.setBackground(java.awt.Color.red);

        jlblNumero22.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero22.setForeground(java.awt.Color.white);
        jlblNumero22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero22.setText("22");

        javax.swing.GroupLayout jpnelNumero22Layout = new javax.swing.GroupLayout(jpnelNumero22);
        jpnelNumero22.setLayout(jpnelNumero22Layout);
        jpnelNumero22Layout.setHorizontalGroup(
            jpnelNumero22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero22, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero22Layout.setVerticalGroup(
            jpnelNumero22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero22, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero23.setBackground(java.awt.Color.red);

        jlblNumero23.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero23.setForeground(java.awt.Color.white);
        jlblNumero23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero23.setText("23");

        javax.swing.GroupLayout jpnelNumero23Layout = new javax.swing.GroupLayout(jpnelNumero23);
        jpnelNumero23.setLayout(jpnelNumero23Layout);
        jpnelNumero23Layout.setHorizontalGroup(
            jpnelNumero23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero23, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero23Layout.setVerticalGroup(
            jpnelNumero23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero23, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero24.setBackground(java.awt.Color.red);

        jlblNumero24.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero24.setForeground(java.awt.Color.white);
        jlblNumero24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero24.setText("24");

        javax.swing.GroupLayout jpnelNumero24Layout = new javax.swing.GroupLayout(jpnelNumero24);
        jpnelNumero24.setLayout(jpnelNumero24Layout);
        jpnelNumero24Layout.setHorizontalGroup(
            jpnelNumero24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero24, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero24Layout.setVerticalGroup(
            jpnelNumero24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero24, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jpnelNumero25.setBackground(java.awt.Color.red);

        jlblNumero25.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumero25.setForeground(java.awt.Color.white);
        jlblNumero25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumero25.setText("25");

        javax.swing.GroupLayout jpnelNumero25Layout = new javax.swing.GroupLayout(jpnelNumero25);
        jpnelNumero25.setLayout(jpnelNumero25Layout);
        jpnelNumero25Layout.setHorizontalGroup(
            jpnelNumero25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero25, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
        );
        jpnelNumero25Layout.setVerticalGroup(
            jpnelNumero25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumero25, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jlblPincelTotalPintadoAzul.setFont(new java.awt.Font("Dialog", 1, 48)); // NOI18N
        jlblPincelTotalPintadoAzul.setForeground(java.awt.Color.white);
        jlblPincelTotalPintadoAzul.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblPincelTotalPintadoAzul.setText("00");
        jlblPincelTotalPintadoAzul.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jlblPincelTotalPintadoAzulPropertyChange(evt);
            }
        });

        jlblPincelNumero.setFont(new java.awt.Font("Dialog", 1, 48)); // NOI18N
        jlblPincelNumero.setForeground(java.awt.Color.white);
        jlblPincelNumero.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblPincelNumero.setText("00");

        javax.swing.GroupLayout jpnelNumeroLayout = new javax.swing.GroupLayout(jpnelNumero);
        jpnelNumero.setLayout(jpnelNumeroLayout);
        jpnelNumeroLayout.setHorizontalGroup(
            jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelNumeroLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jlblPincelTotalPintadoAzul)
                .addGap(70, 70, 70)
                .addGroup(jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelNumeroLayout.createSequentialGroup()
                        .addComponent(jpnelNumero21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelNumeroLayout.createSequentialGroup()
                        .addComponent(jpnelNumero01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero03, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero05, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelNumeroLayout.createSequentialGroup()
                        .addComponent(jpnelNumero06, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero07, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero08, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero09, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelNumeroLayout.createSequentialGroup()
                        .addComponent(jpnelNumero11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelNumeroLayout.createSequentialGroup()
                        .addComponent(jpnelNumero16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumero20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelNumeroLayout.createSequentialGroup()
                    .addContainerGap(446, Short.MAX_VALUE)
                    .addComponent(jlblPincelNumero)
                    .addGap(76, 76, 76)))
        );
        jpnelNumeroLayout.setVerticalGroup(
            jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelNumeroLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumero05, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero04, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero03, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero02, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumero10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero09, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero08, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero07, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero06, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumero15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumero20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumero25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumero21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelNumeroLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblPincelTotalPintadoAzul, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jpnelNumeroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jpnelNumeroLayout.createSequentialGroup()
                    .addGap(67, 67, 67)
                    .addComponent(jlblPincelNumero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(61, 61, 61)))
        );

        jpnelNumeroPintado.setBackground(java.awt.Color.blue);

        jlblNumeroPintado.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumeroPintado.setForeground(java.awt.Color.white);
        jlblNumeroPintado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumeroPintado.setText("00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00");

        javax.swing.GroupLayout jpnelNumeroPintadoLayout = new javax.swing.GroupLayout(jpnelNumeroPintado);
        jpnelNumeroPintado.setLayout(jpnelNumeroPintadoLayout);
        jpnelNumeroPintadoLayout.setHorizontalGroup(
            jpnelNumeroPintadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumeroPintado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jpnelNumeroPintadoLayout.setVerticalGroup(
            jpnelNumeroPintadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumeroPintado, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
        );

        jbtnIncluirCartao.setText("+");
        jbtnIncluirCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIncluirCartaoActionPerformed(evt);
            }
        });
        jbtnIncluirCartao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnIncluirCartaoKeyPressed(evt);
            }
        });

        jbtnIrParaPrimeiroCartao.setText("<<");
        jbtnIrParaPrimeiroCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIrParaPrimeiroCartaoActionPerformed(evt);
            }
        });
        jbtnIrParaPrimeiroCartao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnIrParaPrimeiroCartaoKeyPressed(evt);
            }
        });

        jbtnIrParaProximoCartao.setText(">");
        jbtnIrParaProximoCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIrParaProximoCartaoActionPerformed(evt);
            }
        });
        jbtnIrParaProximoCartao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnIrParaProximoCartaoKeyPressed(evt);
            }
        });

        jbtnIrParaAnteriorCartao.setText("<");
        jbtnIrParaAnteriorCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIrParaAnteriorCartaoActionPerformed(evt);
            }
        });
        jbtnIrParaAnteriorCartao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnIrParaAnteriorCartaoKeyPressed(evt);
            }
        });

        jbtnIrParaUltimoCartao.setText(">>");
        jbtnIrParaUltimoCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIrParaUltimoCartaoActionPerformed(evt);
            }
        });
        jbtnIrParaUltimoCartao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnIrParaUltimoCartaoKeyPressed(evt);
            }
        });

        jbtnIrParaEspecificoCartao.setText(">?");
        jbtnIrParaEspecificoCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIrParaEspecificoCartaoActionPerformed(evt);
            }
        });
        jbtnIrParaEspecificoCartao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnIrParaEspecificoCartaoKeyPressed(evt);
            }
        });

        jbtnExcluirCartao.setText("-");
        jbtnExcluirCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnExcluirCartaoActionPerformed(evt);
            }
        });
        jbtnExcluirCartao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnExcluirCartaoKeyPressed(evt);
            }
        });

        jButton1.setText("Fechar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jbtnRestaurarCartaoSalvo.setText("Restaurar CTRL+R");
        jbtnRestaurarCartaoSalvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnRestaurarCartaoSalvoActionPerformed(evt);
            }
        });
        jbtnRestaurarCartaoSalvo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnRestaurarCartaoSalvoKeyPressed(evt);
            }
        });

        jbtnSalvarCartao.setText("Salvar CTRL+C");
        jbtnSalvarCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnSalvarCartaoActionPerformed(evt);
            }
        });
        jbtnSalvarCartao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jbtnSalvarCartaoKeyPressed(evt);
            }
        });

        jtxtfVolantePreco.setText("00 00 00 00 00 00 00 00 00 00 00 00 00 00 00");

        jlblVolantePreco.setForeground(java.awt.Color.red);
        jlblVolantePreco.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblVolantePreco.setText("R$ 0,00");

        jbtnVolantePreco.setText("R$?");
        jbtnVolantePreco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnVolantePrecoActionPerformed(evt);
            }
        });

        jmnuPainel.setText("Painel");

        jmnuItemPincelAzul.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        jmnuItemPincelAzul.setText("Pincel Azul");
        jmnuItemPincelAzul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemPincelAzulActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemPincelAzul);

        jmnuItemPincelVermelho.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        jmnuItemPincelVermelho.setText("Pincel Vermelho");
        jmnuItemPincelVermelho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemPincelVermelhoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemPincelVermelho);

        jmnuItemVermelharTudo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        jmnuItemVermelharTudo.setText("Vermelhar Tudo");
        jmnuItemVermelharTudo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemVermelharTudoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemVermelharTudo);

        jmnuItemNumeros.setText("Numeros");

        jmnuItemNumeros01.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_1, 0));
        jmnuItemNumeros01.setText("01");
        jmnuItemNumeros01.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros01ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros01);

        jmnuItemNumeros02.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_2, 0));
        jmnuItemNumeros02.setText("02");
        jmnuItemNumeros02.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros02ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros02);

        jmnuItemNumeros03.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_3, 0));
        jmnuItemNumeros03.setText("03");
        jmnuItemNumeros03.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros03ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros03);

        jmnuItemNumeros04.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_4, 0));
        jmnuItemNumeros04.setText("04");
        jmnuItemNumeros04.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros04ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros04);

        jmnuItemNumeros05.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_5, 0));
        jmnuItemNumeros05.setText("05");
        jmnuItemNumeros05.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros05ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros05);

        jmnuItemNumeros06.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_6, 0));
        jmnuItemNumeros06.setText("06");
        jmnuItemNumeros06.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros06ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros06);

        jmnuItemNumeros07.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_7, 0));
        jmnuItemNumeros07.setText("07");
        jmnuItemNumeros07.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros07ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros07);

        jmnuItemNumeros08.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_8, 0));
        jmnuItemNumeros08.setText("08");
        jmnuItemNumeros08.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros08ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros08);

        jmnuItemNumeros09.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_9, 0));
        jmnuItemNumeros09.setText("09");
        jmnuItemNumeros09.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros09ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros09);

        jmnuItemNumeros00.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_0, 0));
        jmnuItemNumeros00.setText("00");
        jmnuItemNumeros00.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumeros00ActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumeros00);

        jmnuItemNumerosZerar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_0, java.awt.event.InputEvent.CTRL_MASK));
        jmnuItemNumerosZerar.setText("ZERAR");
        jmnuItemNumerosZerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumerosZerarActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumerosZerar);

        jmnuItemNumerosApagar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_BACK_SPACE, 0));
        jmnuItemNumerosApagar.setText("TECLA BACKSPACE");
        jmnuItemNumerosApagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumerosApagarActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumerosApagar);

        jmnuItemNumerosPintarNumero.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ENTER, 0));
        jmnuItemNumerosPintarNumero.setText("Pintar Numero");
        jmnuItemNumerosPintarNumero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemNumerosPintarNumeroActionPerformed(evt);
            }
        });
        jmnuItemNumeros.add(jmnuItemNumerosPintarNumero);

        jmnuPainel.add(jmnuItemNumeros);

        jmnuItemIrParaPrimeiroCartao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        jmnuItemIrParaPrimeiroCartao.setText("Ir Para Primeiro Cartao");
        jmnuItemIrParaPrimeiroCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemIrParaPrimeiroCartaoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemIrParaPrimeiroCartao);

        jmnuItemIrParaProximoCartao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        jmnuItemIrParaProximoCartao.setText("Ir Para Proximo Cartao");
        jmnuItemIrParaProximoCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemIrParaProximoCartaoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemIrParaProximoCartao);

        jmnuItemIrParaAnteriorCartao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F6, 0));
        jmnuItemIrParaAnteriorCartao.setText("Ir Para Anterior Cartao");
        jmnuItemIrParaAnteriorCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemIrParaAnteriorCartaoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemIrParaAnteriorCartao);

        jmnuItemIrParaUltimoCartao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F7, 0));
        jmnuItemIrParaUltimoCartao.setText("Ir Para Ultimo Cartao");
        jmnuItemIrParaUltimoCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemIrParaUltimoCartaoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemIrParaUltimoCartao);

        jmnuItemIrParaEspecificoCartao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F8, 0));
        jmnuItemIrParaEspecificoCartao.setText("Ir Para Especifico Cartao");
        jmnuItemIrParaEspecificoCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemIrParaEspecificoCartaoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemIrParaEspecificoCartao);

        jmnuItemIncluirCartao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        jmnuItemIncluirCartao.setText("Incluir Cartao");
        jmnuItemIncluirCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemIncluirCartaoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemIncluirCartao);

        jmnuItemExcluirCartao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        jmnuItemExcluirCartao.setText("Excluir Cartao");
        jmnuItemExcluirCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemExcluirCartaoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemExcluirCartao);

        jmnuItemFechar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.CTRL_MASK));
        jmnuItemFechar.setText("Fechar");
        jmnuItemFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemFecharActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemFechar);

        jmnuItemRestaurarCartaoSalvo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        jmnuItemRestaurarCartaoSalvo.setText("Restaurar Cartao Salvo");
        jmnuItemRestaurarCartaoSalvo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemRestaurarCartaoSalvoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemRestaurarCartaoSalvo);

        jmnuItemSalvarCartao.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        jmnuItemSalvarCartao.setText("Salvar Cartao");
        jmnuItemSalvarCartao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemSalvarCartaoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemSalvarCartao);

        jmnuItemObterEntradaComTeclado.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        jmnuItemObterEntradaComTeclado.setText("Entrada Com Teclado");
        jmnuItemObterEntradaComTeclado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuItemObterEntradaComTecladoActionPerformed(evt);
            }
        });
        jmnuPainel.add(jmnuItemObterEntradaComTeclado);

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Preco Volante No Sorteio");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jmnuPainel.add(jMenuItem1);

        jmnuBarPrincipal.add(jmnuPainel);

        setJMenuBar(jmnuBarPrincipal);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelPincel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelNumero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelNumeroPintado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jbtnIncluirCartao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jbtnExcluirCartao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jbtnRestaurarCartaoSalvo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jbtnIrParaPrimeiroCartao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jbtnIrParaProximoCartao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jbtnIrParaAnteriorCartao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jbtnIrParaUltimoCartao)
                                .addGap(39, 39, 39))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jbtnSalvarCartao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jtxtfVolantePreco)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jbtnVolantePreco)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jbtnIrParaEspecificoCartao)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton1))
                            .addComponent(jlblVolantePreco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpnelSimbolo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelSimbolo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jpnelPincel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpnelNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpnelNumeroPintado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jbtnIncluirCartao)
                            .addComponent(jbtnIrParaPrimeiroCartao)
                            .addComponent(jbtnIrParaProximoCartao)
                            .addComponent(jbtnIrParaAnteriorCartao)
                            .addComponent(jbtnIrParaUltimoCartao)
                            .addComponent(jbtnIrParaEspecificoCartao)
                            .addComponent(jbtnExcluirCartao)
                            .addComponent(jButton1)
                            .addComponent(jbtnRestaurarCartaoSalvo))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jbtnSalvarCartao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jtxtfVolantePreco)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jlblVolantePreco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jbtnVolantePreco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formInternalFrameClosing(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosing
        this.butaoDeAcesso.setVisible(false);
    }//GEN-LAST:event_formInternalFrameClosing

    private void jmnuItemPincelAzulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemPincelAzulActionPerformed
        jlblPincelAzul.setForeground(java.awt.Color.blue);
        jlblPincelVermelho.setForeground(java.awt.Color.white);
    }//GEN-LAST:event_jmnuItemPincelAzulActionPerformed

    private void jmnuItemPincelVermelhoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemPincelVermelhoActionPerformed
        jlblPincelAzul.setForeground(java.awt.Color.white);
        jlblPincelVermelho.setForeground(java.awt.Color.red);
    }//GEN-LAST:event_jmnuItemPincelVermelhoActionPerformed

    private void jmnuItemVermelharTudoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemVermelharTudoActionPerformed
        vermelharTudo();
    }//GEN-LAST:event_jmnuItemVermelharTudoActionPerformed

    private void jmnuItemNumeros00ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros00ActionPerformed
        
        if(jlblPincelNumero.getText().length()==2){
           jlblPincelNumero.setText("0");
        }else if(jlblPincelNumero.getText().length()==1){
         String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"0";
         Integer intg=Integer.valueOf(str);
         if(intg==0 || intg==1 || intg==2 || intg==3 || intg==4 || intg==5
            || intg==6 || intg==7 || intg==8 || intg==9
                 || intg==20 || intg==10)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros00ActionPerformed

    private void jmnuItemNumerosZerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumerosZerarActionPerformed
        zerarPincelNumero();
    }//GEN-LAST:event_jmnuItemNumerosZerarActionPerformed

    private void jmnuItemNumeros01ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros01ActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           jlblPincelNumero.setText("1");
        }else if(jlblPincelNumero.getText().length()==1){
         String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"1";
         Integer intg=Integer.valueOf(str);
         if(intg==10 || intg==1 || intg==21
           || intg==11 || intg==12 || intg==13
           || intg==14 || intg==15 || intg==16
           || intg==17 || intg==18 || intg==19)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros01ActionPerformed

    private void jmnuItemNumerosApagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumerosApagarActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           String str=String.valueOf(jlblPincelNumero.getText().charAt(0));
           jlblPincelNumero.setText(str);
        }else if(jlblPincelNumero.getText().length()==1){
            jlblPincelNumero.setText("00");
        }
    }//GEN-LAST:event_jmnuItemNumerosApagarActionPerformed

    private void jmnuItemNumeros02ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros02ActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           jlblPincelNumero.setText("2");
        }else if(jlblPincelNumero.getText().length()==1){
         String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"2";
         Integer intg=Integer.valueOf(str);
         if(intg==20 || intg==2 || intg==12 || intg==22)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros02ActionPerformed

    private void jmnuItemNumeros03ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros03ActionPerformed
       if(jlblPincelNumero.getText().length()==2){
           //jlblPincelNumero.setText("3");
           return;
        }else if(jlblPincelNumero.getText().length()==1){
         String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"3";
         Integer intg=Integer.valueOf(str);
         if(intg==3 || intg==13 || intg==23)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros03ActionPerformed

    private void formInternalFrameActivated(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameActivated
        grabFocus();
    }//GEN-LAST:event_formInternalFrameActivated

    private void jmnuItemNumeros04ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros04ActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           //jlblPincelNumero.setText("4");
           return;
        }else if(jlblPincelNumero.getText().length()==1){
         String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"4";
         Integer intg=Integer.valueOf(str);
         if(intg==4 || intg==14 || intg==24)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros04ActionPerformed

    private void jmnuItemNumeros05ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros05ActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           //jlblPincelNumero.setText("5");
           return;
        }else if(jlblPincelNumero.getText().length()==1){
         String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"5";
         Integer intg=Integer.valueOf(str);
         if(intg==5 || intg==15 || intg==25)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros05ActionPerformed

    private void jmnuItemNumeros06ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros06ActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           //jlblPincelNumero.setText("6");
           return;
        }else if(jlblPincelNumero.getText().length()==1){
         String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"6";
         Integer intg=Integer.valueOf(str);
         if(intg==6 || intg==16)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros06ActionPerformed

    private void jmnuItemNumeros07ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros07ActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           //jlblPincelNumero.setText("7");
           return;
        }else if(jlblPincelNumero.getText().length()==1){
        String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"7";
         Integer intg=Integer.valueOf(str);
         if(intg==7 || intg==17)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros07ActionPerformed

    private void jmnuItemNumeros08ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros08ActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           //jlblPincelNumero.setText("8");
           return;
        }else if(jlblPincelNumero.getText().length()==1){
         String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"8";
         Integer intg=Integer.valueOf(str);
         if(intg==8 || intg==18)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros08ActionPerformed

    private void jmnuItemNumeros09ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumeros09ActionPerformed
        if(jlblPincelNumero.getText().length()==2){
           //jlblPincelNumero.setText("9");
           return;
        }else if(jlblPincelNumero.getText().length()==1){
        String str=String.valueOf(jlblPincelNumero.getText().charAt(0))+"9";
         Integer intg=Integer.valueOf(str);
         if(intg==9 || intg==19)
         jlblPincelNumero.setText(str);
        }
    }//GEN-LAST:event_jmnuItemNumeros09ActionPerformed

    private void jmnuItemNumerosPintarNumeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemNumerosPintarNumeroActionPerformed
        pintarNumeroSequencia1(jlblPincelNumero.getText());
        pintarNumeroSequencia2(jlblPincelNumero.getText());
        /*if(indiceListagemDeVolante==-1){
            pintarNumeroSequencia1(jlblPincelNumero.getText());
            pintarNumeroSequencia2(jlblPincelNumero.getText());
        }else if(indiceListagemDeVolante>=0){
            pintarNumeroSequencia3(jlblPincelNumero.getText());
            pintarNumeroSequencia2(jlblPincelNumero.getText());
        }*/
    }//GEN-LAST:event_jmnuItemNumerosPintarNumeroActionPerformed

    private void jlblPincelTotalPintadoAzulPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jlblPincelTotalPintadoAzulPropertyChange
        Integer intg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
        if(intg==15)
            jlblPincelPrecoDoCartao.setText("R$ 2,00");
        else if(intg==16)
            jlblPincelPrecoDoCartao.setText("R$ 32,00");
        else if(intg==17)
            jlblPincelPrecoDoCartao.setText("R$ 272,00");
        else if(intg==18)
            jlblPincelPrecoDoCartao.setText("R$ 1632,00");
        else jlblPincelPrecoDoCartao.setText("R$ 00,00");
    }//GEN-LAST:event_jlblPincelTotalPintadoAzulPropertyChange

    private void jtxtfSimboloPrecoSorteio11KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio11KeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio11KeyPressed

    private void jtxtfSimboloPrecoSorteio12KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio12KeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio12KeyPressed

    private void jtxtfSimboloPrecoSorteio13KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio13KeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio13KeyPressed

    private void jtxtfSimboloPrecoSorteio14KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio14KeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio14KeyPressed

    private void jtxtfSimboloPrecoSorteio15KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio15KeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio15KeyPressed

    private void jtxtfSimboloPrecoSorteio11FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio11FocusLost
        if(jtxtfSimboloPrecoSorteio11.getText().isEmpty())
        jtxtfSimboloPrecoSorteio11.setText("4.00");
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio11FocusLost

    private void jtxtfSimboloPrecoSorteio12FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio12FocusLost
        if(jtxtfSimboloPrecoSorteio12.getText().isEmpty())
        jtxtfSimboloPrecoSorteio12.setText("8.00");
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio12FocusLost

    private void jtxtfSimboloPrecoSorteio13FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio13FocusLost
        if(jtxtfSimboloPrecoSorteio13.getText().isEmpty())
        jtxtfSimboloPrecoSorteio13.setText("20.00");
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio13FocusLost

    private void jtxtfSimboloPrecoSorteio14FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio14FocusLost
        if(jtxtfSimboloPrecoSorteio14.getText().isEmpty())
        jtxtfSimboloPrecoSorteio14.setText("00.00");
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio14FocusLost

    private void jtxtfSimboloPrecoSorteio15FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtxtfSimboloPrecoSorteio15FocusLost
        if(jtxtfSimboloPrecoSorteio15.getText().isEmpty())
        jtxtfSimboloPrecoSorteio15.setText("00.00");
    }//GEN-LAST:event_jtxtfSimboloPrecoSorteio15FocusLost
private void jmnuItemIrParaPrimeiroCartaoActionPerformedPrivado(){
    try
    {
        if(listagemDeVolante.size()<0)
            throw new Exception("Nao existe volante cadastrado para proceder com operaçao...");
        indiceListagemDeVolante=0;
        modelo.Volante v = listagemDeVolante.get(indiceListagemDeVolante);
        vermelharTudo();
        for(int i=0;i<v.obterGrupoDoVolante();i++){
            String substr=v.obterDezenaDoVolantePeloIndice(i);
            pintarNumeroSequencia2(substr);
            pintarNumeroSequencia1(substr);
        }
        jlblPincelNumero.setText("00");
        atualizarRotuloQuantidadeDaListagemDeVolante(indiceListagemDeVolante);
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:jmnuItemIrParaPrimeiroCartaoActionPerformedPrivado()\n"
            +e.getMessage());
    }
}
    private void jmnuItemIrParaPrimeiroCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemIrParaPrimeiroCartaoActionPerformed
        jmnuItemIrParaPrimeiroCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemIrParaPrimeiroCartaoActionPerformed
private void jmnuItemIrParaProximoCartaoActionPerformedPrivato(){
    try
    {
    if(listagemDeVolante.size()<0)
            throw new Exception("Nao existe volante cadastrado para proceder com operaçao...");
    
    if(indiceListagemDeVolante==(listagemDeVolante.size()-1))
            throw new Exception("Nao existe proximo volante para proceder com operaçao...");
    
        indiceListagemDeVolante++;
        modelo.Volante v = listagemDeVolante.get(indiceListagemDeVolante);
        vermelharTudo();
        for(int i=0;i<v.obterGrupoDoVolante();i++){
            String substr=v.obterDezenaDoVolantePeloIndice(i);
            pintarNumeroSequencia2(substr);
            pintarNumeroSequencia1(substr);
        }
        jlblPincelNumero.setText("00");
        atualizarRotuloQuantidadeDaListagemDeVolante(indiceListagemDeVolante);
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:jmnuItemIrParaProximoCartaoActionPerformedPrivato()\n"
            +e.getMessage());
    }
}
    private void jmnuItemIrParaProximoCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemIrParaProximoCartaoActionPerformed
        jmnuItemIrParaProximoCartaoActionPerformedPrivato();
    }//GEN-LAST:event_jmnuItemIrParaProximoCartaoActionPerformed
private void   jmnuItemIrParaAnteriorCartaoActionPerformedPrivado(){
    try
    {
    if(listagemDeVolante.size()<0)
            throw new Exception("Nao existe volante cadastrado para proceder com operaçao...");
    
    if(indiceListagemDeVolante==0)
            throw new Exception("Nao existe volante anterior para proceder com operaçao...");
    
        indiceListagemDeVolante--;
        modelo.Volante v = listagemDeVolante.get(indiceListagemDeVolante);
        vermelharTudo();
        for(int i=0;i<v.obterGrupoDoVolante();i++){
            String substr=v.obterDezenaDoVolantePeloIndice(i);
            pintarNumeroSequencia2(substr);
            pintarNumeroSequencia1(substr);
        }
        jlblPincelNumero.setText("00");
        atualizarRotuloQuantidadeDaListagemDeVolante(indiceListagemDeVolante);
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:jmnuItemIrParaAnteriorCartaoActionPerformedPrivado()\n"
            +e.getMessage());
    }
}
    private void jmnuItemIrParaAnteriorCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemIrParaAnteriorCartaoActionPerformed
        jmnuItemIrParaAnteriorCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemIrParaAnteriorCartaoActionPerformed
private void jmnuItemIrParaUltimoCartaoActionPerformedPrivado(){
    try
    {
        if(listagemDeVolante.size()<0)
            throw new Exception("Nao existe volante cadastrado para proceder com operaçao...");
        indiceListagemDeVolante=(listagemDeVolante.size()-1);
        modelo.Volante v = listagemDeVolante.get(indiceListagemDeVolante);
        vermelharTudo();
        for(int i=0;i<v.obterGrupoDoVolante();i++){
            String substr=v.obterDezenaDoVolantePeloIndice(i);
            pintarNumeroSequencia2(substr);
            pintarNumeroSequencia1(substr);
        }
        jlblPincelNumero.setText("00");
        atualizarRotuloQuantidadeDaListagemDeVolante(indiceListagemDeVolante);
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:jmnuItemIrParaUltimoCartaoActionPerformedPrivado()\n"
            +e.getMessage());
    }
}
    private void jmnuItemIrParaUltimoCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemIrParaUltimoCartaoActionPerformed
        jmnuItemIrParaUltimoCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemIrParaUltimoCartaoActionPerformed
private void jmnuItemIrParaEspecificoCartaoActionPerformedPrivado(){
    try
    {
        if(dlgAguarde!=null)
        if(dlgAguarde.isVisible())
        if(exePlanoDeFundo.isAlive())return;
       
        if(listagemDeVolante.size()<0)
            throw new Exception("Nao existe volante cadastrado para proceder com operaçao...");
        
        String strv=JOptionPane.showInputDialog(this,
        "Entre com indice do volante ou digite um volante para pesquisar e ir...",
        "",JOptionPane.YES_NO_OPTION);
        
       if(strv==null || strv.isEmpty())return;
        
        String strv2="";
        for(int i=0;i<strv.length();i++){
            String str=String.valueOf(strv.charAt(i));
            if(!str.equalsIgnoreCase(" "))
            strv2+=str;    
        }
        
        if((strv2.length()%2)!=0){
            strv="";
            for(int i=0;i<(strv2.length()-1);i+=2){
                String str=strv2.substring(i,i+2);
                strv+=str+",";
            }
            strv+=String.valueOf(strv2.charAt((strv2.length()-1)));
            strv2=strv;
        }else {
            strv="";
            for(int i=0;i<strv2.length();i+=2){
                String str=strv2.substring(i,i+2);
                strv+=str+",";
            }
            strv2="";
            for(int i=0;i<(strv.length()-1);i++){
                String str=String.valueOf(strv.charAt(i));
                strv2+=str;
            }
        }
        modelo.Volante v = new modelo.Volante(strv2);
       if(v.obterGrupoDoVolante()==1){
           Integer intg=Integer.valueOf(v.obterVolante());
           if(intg>(listagemDeVolante.size()-1))
               throw new Exception("Indice "+String.valueOf(intg)+
                       " maior que o limite de 0:"
                       +String.valueOf((listagemDeVolante.size()-1)));
           
           modelo.Volante vv = listagemDeVolante.get(intg);
           indiceListagemDeVolante=intg;
           vermelharTudo();
           for(int i=0;i<vv.obterGrupoDoVolante();i++){
            String substr=vv.obterDezenaDoVolantePeloIndice(i);
            pintarNumeroSequencia2(substr);
            pintarNumeroSequencia1(substr);
           }
           jlblPincelNumero.setText("00");
           atualizarRotuloQuantidadeDaListagemDeVolante(indiceListagemDeVolante);
           return;
       }
       
       exePlanoDeFundo = new Thread(new Runnable() {
            @Override
            public void run() {
              JNovoJogoIntrnFrame.this.dlgAguarde = new visao.JAguardeDlg(null,true);
              while(!JNovoJogoIntrnFrame.this.dlgAguarde.isVisible());
              while(JNovoJogoIntrnFrame.this.dlgAguarde.isVisible()){
                  
              }
              JNovoJogoIntrnFrame.this.dlgAguarde.dispose();
              while(JNovoJogoIntrnFrame.this.dlgAguarde.isVisible());
              JNovoJogoIntrnFrame.this.dlgAguarde=null;
              JNovoJogoIntrnFrame.this.grabFocus();
            }
        });exePlanoDeFundo.start();
       
       
        
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:jmnuItemIrParaEspecificoCartaoActionPerformedPrivado()\n"
            +e.getMessage());
    }
}
    private void jmnuItemIrParaEspecificoCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemIrParaEspecificoCartaoActionPerformed
        jmnuItemIrParaEspecificoCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemIrParaEspecificoCartaoActionPerformed

    private void jbtnIncluirCartaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnIncluirCartaoKeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jbtnIncluirCartaoKeyPressed

    private void jbtnExcluirCartaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnExcluirCartaoKeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jbtnExcluirCartaoKeyPressed

    private void jbtnIrParaPrimeiroCartaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnIrParaPrimeiroCartaoKeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jbtnIrParaPrimeiroCartaoKeyPressed

    private void jbtnIrParaProximoCartaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnIrParaProximoCartaoKeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jbtnIrParaProximoCartaoKeyPressed

    private void jbtnIrParaAnteriorCartaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnIrParaAnteriorCartaoKeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jbtnIrParaAnteriorCartaoKeyPressed

    private void jbtnIrParaUltimoCartaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnIrParaUltimoCartaoKeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jbtnIrParaUltimoCartaoKeyPressed

    private void jbtnIrParaEspecificoCartaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnIrParaEspecificoCartaoKeyPressed
        if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jbtnIrParaEspecificoCartaoKeyPressed
private void jmnuItemIncluirCartaoActionPerformedPrivado(){
    try
    {
        int q=-1;
                q=JOptionPane.showInternalConfirmDialog(this,
                "Deseja salvar o volante atual? Caso contrario sera perdido as modificaçoes...",
                "",JOptionPane.YES_NO_CANCEL_OPTION);
        if(q==0){
            if(indiceListagemDeVolante==-1){
                modelo.Volante v = new modelo.Volante(modelarNumeroPintadoNoFormatoVolante(
                jlblNumeroPintado.getText()));
                listagemDeVolante.add(v);
                vermelharTudo();
                atualizarRotuloQuantidadeDaListagemDeVolante(-1);
            }else if(indiceListagemDeVolante>=0){
                modelo.Volante v = new modelo.Volante(modelarNumeroPintadoNoFormatoVolante(
                jlblNumeroPintado.getText()));
                listagemDeVolante.get(indiceListagemDeVolante).aplicarVolante(
                v.obterVolante());
                vermelharTudo();
                atualizarRotuloQuantidadeDaListagemDeVolante(-1);
                indiceListagemDeVolante=-1;
            }
        }else if(q==1){
            indiceListagemDeVolante=-1;
            vermelharTudo();
            atualizarRotuloQuantidadeDaListagemDeVolante(-1);
        }else if(q==2){
            return;
        }else if(q==3){
            return;
        }
        
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
        "JNovoJogoIntrnFrame.java\nMetodo:jmnuItemIncluirCartaoActionPerformedPrivado()\n"
        +e.getMessage());
    }
}
    private void jmnuItemIncluirCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemIncluirCartaoActionPerformed
        jmnuItemIncluirCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemIncluirCartaoActionPerformed
private void jmnuItemExcluirCartaoActionPerformedPrivado(){
    
}
    private void jmnuItemExcluirCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemExcluirCartaoActionPerformed
        jmnuItemExcluirCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemExcluirCartaoActionPerformed

    private void jbtnExcluirCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnExcluirCartaoActionPerformed
        jmnuItemExcluirCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jbtnExcluirCartaoActionPerformed

    private void jbtnIncluirCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIncluirCartaoActionPerformed
        jmnuItemIncluirCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jbtnIncluirCartaoActionPerformed

    private void jbtnIrParaPrimeiroCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIrParaPrimeiroCartaoActionPerformed
        jmnuItemIrParaPrimeiroCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jbtnIrParaPrimeiroCartaoActionPerformed

    private void jbtnIrParaProximoCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIrParaProximoCartaoActionPerformed
                jmnuItemIrParaProximoCartaoActionPerformedPrivato();
    }//GEN-LAST:event_jbtnIrParaProximoCartaoActionPerformed

    private void jbtnIrParaAnteriorCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIrParaAnteriorCartaoActionPerformed
        jmnuItemIrParaAnteriorCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jbtnIrParaAnteriorCartaoActionPerformed

    private void jbtnIrParaUltimoCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIrParaUltimoCartaoActionPerformed
        jmnuItemIrParaUltimoCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jbtnIrParaUltimoCartaoActionPerformed

    private void jbtnIrParaEspecificoCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIrParaEspecificoCartaoActionPerformed
        jmnuItemIrParaEspecificoCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jbtnIrParaEspecificoCartaoActionPerformed
private void jmnuItemFecharActionPerformedPrivado(){
    butaoDeAcesso.setVisible(false);
    dispose();
}
    private void jmnuItemFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemFecharActionPerformed
        jmnuItemFecharActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemFecharActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        jmnuItemFecharActionPerformedPrivado();
    }//GEN-LAST:event_jButton1ActionPerformed
    private void jmnuItemRestaurarCartaoSalvoActionPerformedPrivado(){
    try
    {
        if(indiceListagemDeVolante==-1)
            throw new Exception("Nao existe volante cadastrado para proceder com operaçao...");
        
        modelo.Volante v = listagemDeVolante.get(indiceListagemDeVolante);
        vermelharTudo();
        for(int i=0;i<v.obterGrupoDoVolante();i++){
            String substr=v.obterDezenaDoVolantePeloIndice(i);
            pintarNumeroSequencia2(substr);
            pintarNumeroSequencia1(substr);
        }
        jlblPincelNumero.setText("00");
        atualizarRotuloQuantidadeDaListagemDeVolante(indiceListagemDeVolante);
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:jmnuItemRestaurarCartaoSalvoActionPerformedPrivado()\n"
            +e.getMessage());
    }
    }
    private void jmnuItemRestaurarCartaoSalvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemRestaurarCartaoSalvoActionPerformed
        jmnuItemRestaurarCartaoSalvoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemRestaurarCartaoSalvoActionPerformed

    private void jbtnRestaurarCartaoSalvoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnRestaurarCartaoSalvoActionPerformed
        jmnuItemRestaurarCartaoSalvoActionPerformedPrivado();
    }//GEN-LAST:event_jbtnRestaurarCartaoSalvoActionPerformed

    private void jbtnRestaurarCartaoSalvoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnRestaurarCartaoSalvoKeyPressed
         if(evt.getKeyCode()==java.awt.event.KeyEvent.VK_ESCAPE)
         grabFocus();   
    }//GEN-LAST:event_jbtnRestaurarCartaoSalvoKeyPressed
private void jmnuItemSalvarCartaoActionPerformedPrivado(){
    try
    {
        int q=-1;
                q=JOptionPane.showInternalConfirmDialog(this,
                "Deseja salvar o volante atual? Caso contrario sera perdido as modificaçoes...",
                "",JOptionPane.YES_NO_OPTION);
        if(q==0){
            if(indiceListagemDeVolante==-1){
                modelo.Volante v = new modelo.Volante(modelarNumeroPintadoNoFormatoVolante(
                jlblNumeroPintado.getText()));
                listagemDeVolante.add(v);
                indiceListagemDeVolante=(listagemDeVolante.size()-1);
                atualizarRotuloQuantidadeDaListagemDeVolante(indiceListagemDeVolante);
            }else if(indiceListagemDeVolante>=0){
                modelo.Volante v = new modelo.Volante(modelarNumeroPintadoNoFormatoVolante(
                jlblNumeroPintado.getText()));
                listagemDeVolante.get(indiceListagemDeVolante).aplicarVolante(
                v.obterVolante());
                atualizarRotuloQuantidadeDaListagemDeVolante(indiceListagemDeVolante);
                indiceListagemDeVolante=-1;
            }
        }else if(q==1){
            return;
        }
        
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
        "JNovoJogoIntrnFrame.java\nMetodo:jmnuItemSalvarCartaoActionPerformedPrivado()\n"
        +e.getMessage());
    }
}
    private void jmnuItemSalvarCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemSalvarCartaoActionPerformed
        jmnuItemSalvarCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemSalvarCartaoActionPerformed

    private void jbtnSalvarCartaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnSalvarCartaoActionPerformed
        jmnuItemSalvarCartaoActionPerformedPrivado();
    }//GEN-LAST:event_jbtnSalvarCartaoActionPerformed

    private void jbtnSalvarCartaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jbtnSalvarCartaoKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnSalvarCartaoKeyPressed
    private void jmnuItemObterEntradaComTecladoActionPerformedPrivado(){
        requestFocus(true);
        requestFocusInWindow(true);
        grabFocus();
        
    }
    private void jmnuItemObterEntradaComTecladoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmnuItemObterEntradaComTecladoActionPerformed
        jmnuItemObterEntradaComTecladoActionPerformedPrivado();
    }//GEN-LAST:event_jmnuItemObterEntradaComTecladoActionPerformed

    private void jbtnVolantePrecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnVolantePrecoActionPerformed
        jMenuItem1ActionPerformedPrivado();
    }//GEN-LAST:event_jbtnVolantePrecoActionPerformed
    private void jMenuItem1ActionPerformedPrivado(){
        
        
    try
    {
        if(jlblNumeroPintado.getText().equalsIgnoreCase(NUMEROSZERO))return;
        if(jtxtfVolantePreco.getText().isEmpty())return;
        if(jtxtfVolantePreco.getText()==null)return;
        
        String strv=modelarNumeroPintadoNoFormatoVolante(jtxtfVolantePreco.getText());
        String strv2=modelarNumeroPintadoNoFormatoVolante(jlblNumeroPintado.getText());;
       if(strv==null || strv.isEmpty())return;
        
        
        modelo.Volante v1 = new modelo.Volante(strv);
        modelo.Volante v2 = new modelo.Volante(strv2);
        v2.aplicarPrecoDeQuartozePontos(Double.valueOf(jtxtfSimboloPrecoSorteio14.getText()));
        v2.aplicarPrecoDeQuinzePontos(Double.valueOf(jtxtfSimboloPrecoSorteio15.getText()));
        v2.aplicarPrecoDeOnzePontos(Double.valueOf(jtxtfSimboloPrecoSorteio11.getText()));
        v2.aplicarPrecoDeDozePontos(Double.valueOf(jtxtfSimboloPrecoSorteio12.getText()));
        v2.aplicarPrecoDeTrezePontos(Double.valueOf(jtxtfSimboloPrecoSorteio13.getText()));
        double p = v2.calcularPrecoDoVolanteComSorteio(strv);
        jlblVolantePreco.setText("R$ "+String.valueOf(p));
        
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:jMenuItem1ActionPerformedPrivado()\n"
            +e.getMessage());
    }
        
    }
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        jMenuItem1ActionPerformedPrivado();
    }//GEN-LAST:event_jMenuItem1ActionPerformed
    private String modelarNumeroPintadoNoFormatoVolante(String numeroPintado){
        String jlblNumeroPintadoMod="";
        for(int i=0;i<numeroPintado.length();i++){
               if(numeroPintado.charAt(i)==' ')
                    jlblNumeroPintadoMod+=",";
               else
                    jlblNumeroPintadoMod+=String.valueOf(numeroPintado.charAt(i));    
               
        }
       return jlblNumeroPintadoMod;
}
 
private String demodelarNumeroPintadoNoFormatoVolante(String numeroPintado){
        String jlblNumeroPintadoMod="";
        for(int i=0;i<numeroPintado.length();i++){
               if(numeroPintado.charAt(i)==',')
                    jlblNumeroPintadoMod+=" ";
               else
                    jlblNumeroPintadoMod+=String.valueOf(numeroPintado.charAt(i));    
               
        }
       return jlblNumeroPintadoMod;
}
private void pintarNumeroSequencia2(String numeroStr){
    java.awt.Color cor=obterCorDoPincel();
    try
    {
    if(numeroStr.length()!=2)throw new Exception("Numero deve ser composto de dois digitos...");
    Integer intg=Integer.valueOf(numeroStr);
    switch(intg){
            case 1:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                           jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero01.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero01.setBackground(cor);
                }
            break;
            case 2:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero02.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero02.setBackground(cor);
                }
            break;
            case 3:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero03.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero03.setBackground(cor);
                }
            break;
            case 4:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero04.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero04.setBackground(cor);
                }
            break;
            case 5:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero05.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero05.setBackground(cor);
                }
            break;
            case 6:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero06.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero06.setBackground(cor);
                }
            break;
            case 7:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero07.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero07.setBackground(cor);
                }
            break;
            case 8:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero08.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero08.setBackground(cor);
                }
            break;
            case 9:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero09.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero09.setBackground(cor);
                }
            break;
            case 10:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero10.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero10.setBackground(cor);
                }
            break;
            case 11:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero11.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero11.setBackground(cor);
                }
            break;
            case 12:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero12.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero12.setBackground(cor);
                }
            break;
            case 13:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero13.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero13.setBackground(cor);
                }
            break;
            case 14:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero14.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero14.setBackground(cor);
                }
            break;
            case 15:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero15.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero15.setBackground(cor);
                }
            break;
            case 16:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero16.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero16.setBackground(cor);
                }
            break;
            case 17:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero17.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero17.setBackground(cor);
                }
            break;
            case 18:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero18.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero18.setBackground(cor);
                }
            break;
            case 19:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero19.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero19.setBackground(cor);
                }
            break;
            case 20:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero20.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero20.setBackground(cor);
                }
            break;
            case 21:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero21.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero21.setBackground(cor);
                }
            break;
            case 22:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero22.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero22.setBackground(cor);
                }
            break;
            case 23:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero23.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero23.setBackground(cor);
                    
                }
            break;
            case 24:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero24.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero24.setBackground(cor);
                    
                }
            break;
            case 25:
                if(cor==java.awt.Color.blue){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==18)return;
                        intgg++;
                        if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                        jpnelNumero25.setBackground(cor);
                    
                }else if(cor==java.awt.Color.red){
                    Integer intgg=Integer.valueOf(jlblPincelTotalPintadoAzul.getText());
                    if(intgg==0)return;
                    intgg--;
                    if(intgg>=0 && intgg<=9)
                        jlblPincelTotalPintadoAzul.setText("0"+String.valueOf(intgg));
                        else
                        jlblPincelTotalPintadoAzul.setText(String.valueOf(intgg));    
                    jpnelNumero25.setBackground(cor);
                    
                    
                }
            break;
        }
        jlblPincelNumero.setText("00");
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,
        "JNovoJogoIntrnFrame.java\nMetodo:pintarNumeroSequencia2(String numero)\n"
        +e.getMessage());
    }
}
private void pintarNumeroSequencia3(String numero){
        try
        {
              pintarNumeroSequencia1(numero);
              String strv=modelarNumeroPintadoNoFormatoVolante(jlblNumeroPintado.getText());
              modelo.Volante v = listagemDeVolante.get(indiceListagemDeVolante);
              v.aplicarVolante(strv);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:pintarNumeroSequencia3(String numero)\n"
            +e.getMessage());
        }
        
    }
    
    private void pintarNumeroSequencia1(String numero){
        try
        {
            if(obterCorDoPincel()==java.awt.Color.blue){
                if(Integer.valueOf(numero)==0)return;
                   String jlblNumeroPintadoStr=modelarNumeroPintadoNoFormatoVolante(jlblNumeroPintado.getText());
                   modelo.Volante v = new  modelo.Volante(jlblNumeroPintadoStr);
                   v.removerDezena("00");
                   v.acrescentarDezena(numero);
                   jlblNumeroPintadoStr=demodelarNumeroPintadoNoFormatoVolante(v.obterVolante());
                   jlblNumeroPintado.setText(jlblNumeroPintadoStr);
            }else if(obterCorDoPincel()==java.awt.Color.red){
              String jlblNumeroPintadoMod=modelarNumeroPintadoNoFormatoVolante(jlblNumeroPintado.getText());
              modelo.Volante v =  new modelo.Volante(jlblNumeroPintadoMod);
              if(v.obterIndiceDaDezenaNoVolante(jlblPincelNumero.getText())==-1)
              return;   
              v.removerDezena(jlblPincelNumero.getText());
              jlblNumeroPintadoMod=demodelarNumeroPintadoNoFormatoVolante((v.obterVolante()+" 00"));
              jlblNumeroPintado.setText(jlblNumeroPintadoMod);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,
            "JNovoJogoIntrnFrame.java\nMetodo:pintarNumeroSequencia1()\n"
            +e.getMessage());
        }
        
    }
    
    private void zerarPincelNumero(){
        jlblPincelTotalPintadoAzul.setText("00");
    }
    private void vermelharTudo(){
        jpnelNumero01.setBackground(java.awt.Color.red);
        jpnelNumero02.setBackground(java.awt.Color.red);
        jpnelNumero03.setBackground(java.awt.Color.red);
        jpnelNumero04.setBackground(java.awt.Color.red);
        jpnelNumero05.setBackground(java.awt.Color.red);
        jpnelNumero06.setBackground(java.awt.Color.red);
        jpnelNumero07.setBackground(java.awt.Color.red);
        jpnelNumero08.setBackground(java.awt.Color.red);
        jpnelNumero09.setBackground(java.awt.Color.red);
        jpnelNumero10.setBackground(java.awt.Color.red);
        jpnelNumero11.setBackground(java.awt.Color.red);
        jpnelNumero12.setBackground(java.awt.Color.red);
        jpnelNumero13.setBackground(java.awt.Color.red);
        jpnelNumero14.setBackground(java.awt.Color.red);
        jpnelNumero15.setBackground(java.awt.Color.red);
        jpnelNumero16.setBackground(java.awt.Color.red);
        jpnelNumero17.setBackground(java.awt.Color.red);
        jpnelNumero18.setBackground(java.awt.Color.red);
        jpnelNumero19.setBackground(java.awt.Color.red);
        jpnelNumero20.setBackground(java.awt.Color.red);
        jpnelNumero21.setBackground(java.awt.Color.red);
        jpnelNumero22.setBackground(java.awt.Color.red);
        jpnelNumero23.setBackground(java.awt.Color.red);
        jpnelNumero24.setBackground(java.awt.Color.red);
        jpnelNumero25.setBackground(java.awt.Color.red);
        jlblNumeroPintado.setText(NUMEROSZERO);
        jlblPincelTotalPintadoAzul.setText("00");
        jlblPincelNumero.setText("00");
    }
    private java.awt.Color obterCorDoPincel(){
        if(jlblPincelAzul.getForeground()==java.awt.Color.blue){
            return java.awt.Color.blue;
        }else if(jlblPincelVermelho.getForeground()==java.awt.Color.red){
            return java.awt.Color.red;
        }else return java.awt.Color.blue;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JButton jbtnExcluirCartao;
    private javax.swing.JButton jbtnIncluirCartao;
    private javax.swing.JButton jbtnIrParaAnteriorCartao;
    private javax.swing.JButton jbtnIrParaEspecificoCartao;
    private javax.swing.JButton jbtnIrParaPrimeiroCartao;
    private javax.swing.JButton jbtnIrParaProximoCartao;
    private javax.swing.JButton jbtnIrParaUltimoCartao;
    private javax.swing.JButton jbtnRestaurarCartaoSalvo;
    private javax.swing.JButton jbtnSalvarCartao;
    private javax.swing.JButton jbtnVolantePreco;
    private javax.swing.JLabel jlblNumero01;
    private javax.swing.JLabel jlblNumero02;
    private javax.swing.JLabel jlblNumero03;
    private javax.swing.JLabel jlblNumero04;
    private javax.swing.JLabel jlblNumero05;
    private javax.swing.JLabel jlblNumero06;
    private javax.swing.JLabel jlblNumero07;
    private javax.swing.JLabel jlblNumero08;
    private javax.swing.JLabel jlblNumero09;
    private javax.swing.JLabel jlblNumero10;
    private javax.swing.JLabel jlblNumero11;
    private javax.swing.JLabel jlblNumero12;
    private javax.swing.JLabel jlblNumero13;
    private javax.swing.JLabel jlblNumero14;
    private javax.swing.JLabel jlblNumero15;
    private javax.swing.JLabel jlblNumero16;
    private javax.swing.JLabel jlblNumero17;
    private javax.swing.JLabel jlblNumero18;
    private javax.swing.JLabel jlblNumero19;
    private javax.swing.JLabel jlblNumero20;
    private javax.swing.JLabel jlblNumero21;
    private javax.swing.JLabel jlblNumero22;
    private javax.swing.JLabel jlblNumero23;
    private javax.swing.JLabel jlblNumero24;
    private javax.swing.JLabel jlblNumero25;
    private javax.swing.JLabel jlblNumeroPintado;
    private javax.swing.JLabel jlblPincelAzul;
    private javax.swing.JLabel jlblPincelNumero;
    private javax.swing.JLabel jlblPincelPintarNumero;
    private javax.swing.JLabel jlblPincelPrecoDoCartao;
    private javax.swing.JLabel jlblPincelTotalPintadoAzul;
    private javax.swing.JLabel jlblPincelVermelharTudo;
    private javax.swing.JLabel jlblPincelVermelho;
    private javax.swing.JLabel jlblSimbolo01;
    private javax.swing.JLabel jlblSimbolo02;
    private javax.swing.JLabel jlblSimbolo03;
    private javax.swing.JLabel jlblSimbolo04;
    private javax.swing.JLabel jlblSimboloPrecoPagar15;
    private javax.swing.JLabel jlblSimboloPrecoPagar16;
    private javax.swing.JLabel jlblSimboloPrecoPagar17;
    private javax.swing.JLabel jlblSimboloPrecoPagar18;
    private javax.swing.JLabel jlblSimboloPrecoSorteio11;
    private javax.swing.JLabel jlblSimboloPrecoSorteio12;
    private javax.swing.JLabel jlblSimboloPrecoSorteio13;
    private javax.swing.JLabel jlblSimboloPrecoSorteio14;
    private javax.swing.JLabel jlblSimboloPrecoSorteio15;
    private javax.swing.JLabel jlblVolantePreco;
    private javax.swing.JMenuBar jmnuBarPrincipal;
    private javax.swing.JMenuItem jmnuItemExcluirCartao;
    private javax.swing.JMenuItem jmnuItemFechar;
    private javax.swing.JMenuItem jmnuItemIncluirCartao;
    private javax.swing.JMenuItem jmnuItemIrParaAnteriorCartao;
    private javax.swing.JMenuItem jmnuItemIrParaEspecificoCartao;
    private javax.swing.JMenuItem jmnuItemIrParaPrimeiroCartao;
    private javax.swing.JMenuItem jmnuItemIrParaProximoCartao;
    private javax.swing.JMenuItem jmnuItemIrParaUltimoCartao;
    private javax.swing.JMenu jmnuItemNumeros;
    private javax.swing.JMenuItem jmnuItemNumeros00;
    private javax.swing.JMenuItem jmnuItemNumeros01;
    private javax.swing.JMenuItem jmnuItemNumeros02;
    private javax.swing.JMenuItem jmnuItemNumeros03;
    private javax.swing.JMenuItem jmnuItemNumeros04;
    private javax.swing.JMenuItem jmnuItemNumeros05;
    private javax.swing.JMenuItem jmnuItemNumeros06;
    private javax.swing.JMenuItem jmnuItemNumeros07;
    private javax.swing.JMenuItem jmnuItemNumeros08;
    private javax.swing.JMenuItem jmnuItemNumeros09;
    private javax.swing.JMenuItem jmnuItemNumerosApagar;
    private javax.swing.JMenuItem jmnuItemNumerosPintarNumero;
    private javax.swing.JMenuItem jmnuItemNumerosZerar;
    private javax.swing.JMenuItem jmnuItemObterEntradaComTeclado;
    private javax.swing.JMenuItem jmnuItemPincelAzul;
    private javax.swing.JMenuItem jmnuItemPincelVermelho;
    private javax.swing.JMenuItem jmnuItemRestaurarCartaoSalvo;
    private javax.swing.JMenuItem jmnuItemSalvarCartao;
    private javax.swing.JMenuItem jmnuItemVermelharTudo;
    private javax.swing.JMenu jmnuPainel;
    private javax.swing.JPanel jpnelNumero;
    private javax.swing.JPanel jpnelNumero01;
    private javax.swing.JPanel jpnelNumero02;
    private javax.swing.JPanel jpnelNumero03;
    private javax.swing.JPanel jpnelNumero04;
    private javax.swing.JPanel jpnelNumero05;
    private javax.swing.JPanel jpnelNumero06;
    private javax.swing.JPanel jpnelNumero07;
    private javax.swing.JPanel jpnelNumero08;
    private javax.swing.JPanel jpnelNumero09;
    private javax.swing.JPanel jpnelNumero10;
    private javax.swing.JPanel jpnelNumero11;
    private javax.swing.JPanel jpnelNumero12;
    private javax.swing.JPanel jpnelNumero13;
    private javax.swing.JPanel jpnelNumero14;
    private javax.swing.JPanel jpnelNumero15;
    private javax.swing.JPanel jpnelNumero16;
    private javax.swing.JPanel jpnelNumero17;
    private javax.swing.JPanel jpnelNumero18;
    private javax.swing.JPanel jpnelNumero19;
    private javax.swing.JPanel jpnelNumero20;
    private javax.swing.JPanel jpnelNumero21;
    private javax.swing.JPanel jpnelNumero22;
    private javax.swing.JPanel jpnelNumero23;
    private javax.swing.JPanel jpnelNumero24;
    private javax.swing.JPanel jpnelNumero25;
    private javax.swing.JPanel jpnelNumeroPintado;
    private javax.swing.JPanel jpnelPincel;
    private javax.swing.JPanel jpnelPincelAzul;
    private javax.swing.JPanel jpnelPincelPintarNumero01;
    private javax.swing.JPanel jpnelPincelVermelharTudo01;
    private javax.swing.JPanel jpnelPincelVermelharTudo02;
    private javax.swing.JPanel jpnelPincelVermelharTudo2;
    private javax.swing.JPanel jpnelPincelVermelharTudo3;
    private javax.swing.JPanel jpnelPincelVermelho;
    private javax.swing.JPanel jpnelSimbolo;
    private javax.swing.JPanel jpnelSimboloAzul011;
    private javax.swing.JPanel jpnelSimboloAzul012;
    private javax.swing.JPanel jpnelSimboloAzul021;
    private javax.swing.JPanel jpnelSimboloAzul041;
    private javax.swing.JPanel jpnelSimboloVermelho021;
    private javax.swing.JPanel jpnelSimboloVermelho031;
    private javax.swing.JPanel jpnelSimboloVermelho032;
    private javax.swing.JPanel jpnelSimboloVermelho041;
    private javax.swing.JFormattedTextField jtxtfSimboloPrecoSorteio11;
    private javax.swing.JFormattedTextField jtxtfSimboloPrecoSorteio12;
    private javax.swing.JFormattedTextField jtxtfSimboloPrecoSorteio13;
    private javax.swing.JFormattedTextField jtxtfSimboloPrecoSorteio14;
    private javax.swing.JFormattedTextField jtxtfSimboloPrecoSorteio15;
    private javax.swing.JTextField jtxtfVolantePreco;
    // End of variables declaration//GEN-END:variables
}
