/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author felipe
 */
public class Volante {

    private int    grupoDoVolante;
    private String volante;
    
    public Volante()throws Exception{
       grupoDoVolante=0;
       volante=null;
    }
    
    public Volante(Volante volante)throws Exception{
       if(obterGrupoDoVolante(volante.obterVolante())!=15
        && obterGrupoDoVolante(volante.obterVolante())!=16
         && obterGrupoDoVolante(volante.obterVolante())!=17
         && obterGrupoDoVolante(volante.obterVolante())!=18)
     throw new Exception("Volante.java\nMetodo:Volante(Volante volante)\n"
     +"Grupo do volante nao validado...\n"
     +"Grupo do volante deve ser da categoria de 15,16,17 ou 18...");    
     
     if(verificarExistenciaDeDezenaMultiplicada(volante.obterVolante()))
     throw new Exception("Volante.java\nMetodo:Volante(Volante volante)\n"
     +"Foi verificado existencia de dezena multiplicada...\n");
     
     this.grupoDoVolante=obterGrupoDoVolante(volante.obterVolante());
     this.volante=ordenarVolanteOrdemCrescente(volante.obterVolante());
    }
    
    public Volante(final String volante)throws Exception{
     
    if(obterGrupoDoVolante(volante)!=15
        && obterGrupoDoVolante(volante)!=16
         && obterGrupoDoVolante(volante)!=17
         && obterGrupoDoVolante(volante)!=18)
     throw new Exception("Volante.java\nMetodo:Volante(final String volante)\n"
     +"Grupo do volante nao validado...\n"
     +"Grupo do volante deve ser da categoria de 15,16,17 ou 18...");    
     
     if(verificarExistenciaDeDezenaMultiplicada(volante))
     throw new Exception("Volante.java\nMetodo:Volante(final String volante)\n"
     +"Foi verificado existencia de dezena multiplicada...\n");
     
     this.volante=ordenarVolanteOrdemCrescente(volante);
     javax.swing.JOptionPane.showMessageDialog(null,"olA:d");
     this.grupoDoVolante=obterGrupoDoVolante(volante);
    
    }
    
    public int calcularPontoDoVolanteComSorteio(final String sorteio)
    throws Exception{
      int resposta=0;
        for(int i=0;i<sorteio.length();i++){
            
        }
      return resposta;
    }
    
    private String ordenarVolanteOrdemCrescente(final String volante)
    throws Exception {
        String resposta=null;
        if(obterGrupoDoVolante(volante)!=15
        && obterGrupoDoVolante(volante)!=16
         && obterGrupoDoVolante(volante)!=17
         && obterGrupoDoVolante(volante)!=18)
     throw new Exception("Volante.java\nMetodo:ordenarVolanteOrdemCrescente(final String volante)\n"
     +"Grupo do volante nao validado...\n"
     +"Grupo do volante deve ser da categoria de 15,16,17 ou 18...");    
     
     if(verificarExistenciaDeDezenaMultiplicada(volante))
     throw new Exception("Volante.java\nMetodo:ordenarVolanteOrdemCrescente(final String volante)\n"
     +"Foi verificado existencia de dezena multiplicada...");
     resposta="";
     for(int j=1;j<26;j++){
         for(int i=0;i<volante.length();i+=2){
             final Integer intg1=Integer.valueOf(volante.substring(i,i+2));
             final String str1=volante.substring(i,i+2);
             if(intg1==j){
                 resposta+=str1;
                 break;
             }
         }
     }
        
       return resposta;
    }
    
    public String obterIndiceDoVolante(int indice) throws Exception{
        String resposta=null;
        
        if(indice>18 || indice<0)
        throw new Exception("Volante.java\nMetodo:obterIndiceDoVolante(int indice)\n"
        +"Indice fora da faixa permitida >= 0 <= 18...");    
        
        if(this.volante==null)
        throw new Exception("Volante.java\nMetodo:obterIndiceDoVolante(int indice)\n"
        +"Nao ha volante povoado por numero...");    
        
        indice*=2;
        if(indice>(this.volante.length()))
        throw new Exception("Volante.java\nMetodo:obterIndiceDoVolante(int indice)\n"
        +"Indice maior do que faixa permitida...");    
        
        resposta="";
        resposta=this.volante.substring(indice,indice+2);
        
        return resposta;
    }
    
    public String obterVolante() throws Exception{
        return volante;
    }
    
    public int obterGrupoDoVolante() throws Exception{
        return grupoDoVolante;
    }
    
    public void aplicarVolante(final String volante) throws Exception{
        if(obterGrupoDoVolante(volante)!=15
        && obterGrupoDoVolante(volante)!=16
         && obterGrupoDoVolante(volante)!=17
         && obterGrupoDoVolante(volante)!=18)
     throw new Exception("Volante.java\nMetodo:aplicarVolante(final String volante)\n"
     +"Grupo do volante nao validado...\n"
     +"Grupo do volante deve ser da categoria de 15,16,17 ou 18...");    
     
     if(verificarExistenciaDeDezenaMultiplicada(volante))
     throw new Exception("Volante.java\nMetodo:aplicarVolante(final String volante)\n"
     +"Foi verificado existencia de dezena multiplicada...\n");
     
     this.grupoDoVolante=obterGrupoDoVolante(volante);
     this.volante=volante;
    }
    
    private int obterGrupoDoVolante(final String volante)throws Exception{
    if(!verificarUnidadeDaDezena(volante))
    throw new Exception("Volante.java\nMetodo:obterGrupoDoVolante(final String volante)\n"
    +"Unidade da dezena dever ser composta de dois digitos...");
    return (volante.length()/2);
    }
    
    private static boolean verificarUnidadeDaDezena(final String volante)
    throws Exception{
        int len=volante.length();
        int divisao=(len/2);
        if(divisao!=15 && divisao!=16 && divisao!=17 && divisao!=18)
        return false;
        return true;
    }
    
    private static boolean verificarExistenciaDeDezenaMultiplicada(final String volante)
    throws Exception{
    if(!verificarUnidadeDaDezena(volante))
    throw new Exception("Volante.java\nMetodo:verificarExistenciaDeDezenaMultiplicada(final String volante)\n"
    +"Unidade da dezena dever ser composta de dois digitos...");
    for(int i=0;i<volante.length();i+=2){
            final String dezena=volante.substring(i,i+2);
            int j=(i+2);
            while(j<volante.length()){
                final String dez=volante.substring(j,j+2);
                if(dezena.equalsIgnoreCase(dez))return true;
                j+=2;
            }
                
        }
        return false;
    }
    
    private static boolean verificarExistenciaDeNumerosSomente(final String volante)
    throws Exception {
        final String caracterValido="0987654321 ";
        for(int i=0;i<volante.length();i++){
            for(int j=0;j<caracterValido.length();j++){
                if(volante.charAt(i)!=caracterValido.charAt(j) && 
                        j==(caracterValido.length()-1)){
                    return false;
                }else if(volante.charAt(i)==caracterValido.charAt(j)){
                    break;
                }   
            }
        }
        return true;
    }
    
}
