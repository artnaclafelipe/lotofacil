/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author felipe
 */
public class Volante {

    public static boolean verificarExistenciaDeNumerosSomente(String volante){
        boolean resposta=true;
        final String caracterValido="0987654321 ";
        for(int i=0;i<volante.length() &&  resposta==true;i++){
            for(int j=0;j<caracterValido.length() &&  resposta==true;j++){
                if(volante.charAt(i)!=caracterValido.charAt(j) && 
                        j==(caracterValido.length()-1)){
                    resposta=false;
                    break;
                }else if(volante.charAt(i)==caracterValido.charAt(j)){
                    break;
                }   
            }
        }
        return resposta;
    }
    
}
