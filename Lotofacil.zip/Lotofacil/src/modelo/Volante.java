/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author felipe
 */
public class Volante {

    
    private static boolean verificarUnidadeDaDezena(final String volante)
    throws Exception{
        int len=volante.length();
        int divisao=(len/2);
        if(divisao!=15 && divisao!=16 && divisao!=17 && divisao!=18)
        return false;
        return true;
    }
    
    private static boolean verificarExistenciaDeDezenaMultiplicada(final String volante)
    throws Exception{
        if(!verificarUnidadeDaDezena(volante))
        throw new Exception("Volante.java\nLinha:+-27\n"
        +"Unidade da dezena dever ser composta de dois digitos...");
        for(int i=0;i<volante.length();i+=2){
            final String dezena=volante.substring(i,i+2);
            int j=(i+2);
            while(j<volante.length()){
                String dez=volante.substring(j,j+2);
                if(dezena.equalsIgnoreCase(dez))return true;
                j+=2;
            }
                
        }
        return false;
    }
    
    private static boolean verificarExistenciaDeNumerosSomente(final String volante)
    throws Exception {
        final String caracterValido="0987654321 ";
        for(int i=0;i<volante.length();i++){
            for(int j=0;j<caracterValido.length();j++){
                if(volante.charAt(i)!=caracterValido.charAt(j) && 
                        j==(caracterValido.length()-1)){
                    return false;
                }else if(volante.charAt(i)==caracterValido.charAt(j)){
                    break;
                }   
            }
        }
        return true;
    }
    
}
