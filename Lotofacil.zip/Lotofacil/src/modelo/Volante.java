/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import javax.swing.JOptionPane;

/**
 *
 * @author felipe
 */
public class Volante {

    private int    grupoDoVolante;
    private String volante;
    private double precoDoVolante;
    
    public Volante()throws Exception{
       precoDoVolante=grupoDoVolante=0;
       volante=null;
    }
    
    public Volante(Volante volante)throws Exception{
    
    if(!verificarUnidadeDaDezena(volante.obterVolante()))
    throw new Exception("Volante.java\nMetodo:Volante(Volante volante)\n"
    +"Unidade da dezena dever ser composta de dois digitos...");
        
     if(obterGrupoDoVolante(volante.obterVolante())>18)
     throw new Exception("Volante.java\nMetodo:Volante(Volante volante)\n"
     +"Grupo do volante nao validado...\n"
     +"Grupo do volante deve ser da categoria de 15,16,17 ou 18...");    
     
     if(verificarExistenciaDeDezenaMultiplicada(volante.obterVolante()))
     throw new Exception("Volante.java\nMetodo:Volante(Volante volante)\n"
     +"Foi verificado existencia de dezena multiplicada...\n");
     
     this.grupoDoVolante=obterGrupoDoVolante(volante.obterVolante());
     this.volante=ordenarVolanteOrdemCrescente(volante.obterVolante());
     this.precoDoVolante=obterPrecoDoVolante(volante.obterVolante());
    }
    
    public Volante(final String volante)throws Exception{
     if(!verificarUnidadeDaDezena(volante))
    throw new Exception("Volante.java\nMetodo:Volante(final String volante)\n"
    +"Unidade da dezena dever ser composta de dois digitos...");
        
     if(obterGrupoDoVolante(volante)>18)
     throw new Exception("Volante.java\nMetodo:Volante(final String volante)\n"
     +"Grupo do volante nao validado...\n"
     +"Grupo do volante deve ser da categoria de 15,16,17 ou 18...");    
     
     if(verificarExistenciaDeDezenaMultiplicada(volante))
     throw new Exception("Volante.java\nMetodo:Volante(final String volante)\n"
     +"Foi verificado existencia de dezena multiplicada...\n");
     
     this.grupoDoVolante=obterGrupoDoVolante(volante);
     this.volante=ordenarVolanteOrdemCrescente(volante);
     this.precoDoVolante=obterPrecoDoVolante(volante);
    }
    
    public int calcularPontoDoVolanteComSorteio(final String sorteio)
    throws Exception{
      int resposta=0;
        for(int i=0;i<sorteio.length();i++){
            
        }
      return resposta;
    }
    
    private String ordenarVolanteOrdemCrescente(final String volante)
    throws Exception {
     String resposta="";
     int dezenaInserida=0;
     for(int j=0;j<26;j++){
         for(int i=0;i<volante.length();i+=3){
             final Integer intg1=Integer.valueOf(volante.substring(i,i+2));
             final String str1=volante.substring(i,i+2);
             if(intg1==0 && dezenaInserida<19){
                 resposta+=str1;
                 dezenaInserida++;
                 continue;
             }
             if(intg1==j){
                 resposta+=str1;
                 break;
             }
         }
     }
    String strResposta="";
    for(int i=0;i<resposta.length();i+=2){
            String substr=resposta.substring(i,i+2);
            strResposta+=substr+",";
    }
    resposta="";
    for(int i=0;i<(strResposta.length()-1);i++){
            String substr=String.valueOf(strResposta.charAt(i));
            resposta+=substr;
    }
       return resposta;
    }
    
    public String obterDezenaDoVolantePeloIndice(final int indice) throws Exception{
        String resposta=null;
        
        if(indice>18 || indice<0)
        throw new Exception("Volante.java\nMetodo:obterIndiceDoVolante(int indice)\n"
        +"Indice fora da faixa permitida >= 0 <= 18...");    
        
        if(this.volante==null)
        throw new Exception("Volante.java\nMetodo:obterIndiceDoVolante(int indice)\n"
        +"Nao ha volante povoado por numero...");    
        
        int indice2=indice*3;
        if(indice2>(this.volante.length()))
        throw new Exception("Volante.java\nMetodo:obterIndiceDoVolante(int indice)\n"
        +"Indice maior do que faixa permitida...");    
        
        resposta="";
        resposta=this.volante.substring(indice2,indice2+2);
        
        return resposta;
    }
    
    public void acrescentarDezena(final String dezena)throws Exception{
        if(dezena.length()!=2)
        throw new Exception("Volante.java\nMetodo:acrescentarDezena(final String dezena)\n"
        +"A dezena dever ser composta por dois digitos...");        
        
        if(obterGrupoDoVolante()==18)
        throw new Exception("Volante.java\nMetodo:acrescentarDezena(final String dezena)\n"
        +"O numero maximo de 18 dezenas foi alcançado...");        
        
        this.volante=ordenarVolanteOrdemCrescente((this.volante+dezena));
        this.grupoDoVolante=obterGrupoDoVolante(this.volante);
        
    }
    
    public void removerDezena(final String dezena)throws Exception{
        if(dezena.length()!=2)
        throw new Exception("Volante.java\nMetodo:acrescentarDezena(final String dezena)\n"
        +"A dezena dever ser composta por dois digitos...");        
        
        if(obterGrupoDoVolante()==0)
        throw new Exception("Volante.java\nMetodo:acrescentarDezena(final String dezena)\n"
        +"O numero minimo de 0 dezena foi alcançado...");        
        
        int indiceDaDezenaNoVolante=obterIndiceDaDezenaNoVolante(dezena);
        String str="";
        for(int i=0;i<obterGrupoDoVolante();i++){
            if(i!=indiceDaDezenaNoVolante)
            str+=obterDezenaDoVolantePeloIndice(i);
        }
        this.volante=ordenarVolanteOrdemCrescente(str);
        this.grupoDoVolante=obterGrupoDoVolante(this.volante);
    }
    
    public int obterIndiceDaDezenaNoVolante(final String dezena)throws Exception{
        for(int i=0;i<18;i++){
            int substrInt=(i*3);
            if(substrInt>this.volante.length())return -1;
            String str=this.volante.substring(substrInt,substrInt+2);
            if(str.equalsIgnoreCase(dezena)){
                return i;
            }
        }
        return -1;
    }
    
    public double obterPrecoDoVolante() throws Exception{
      return precoDoVolante;
    }
        
    private double obterPrecoDoVolante(final String volante) throws Exception{
    int len=0;
    for(int i=0;i<volante.length();i++)
    if(volante.charAt(i)!=',')
    len++;    
    int divisao=(len/2);
    if(divisao==15)return (double)2.00;
    if(divisao==16)return (double)32.00;
    if(divisao==17)return (double)272.00;
    if(divisao==18)return (double)1632.00;
    return (double)0.00;
    }
    
    public String obterVolante() throws Exception{
        return volante;
    }
    
    public int obterGrupoDoVolante() throws Exception{
        return grupoDoVolante;
    }
    
    public void aplicarVolante(final String volante) throws Exception{
     if(!verificarUnidadeDaDezena(volante))
    throw new Exception("Volante.java\nMetodo:aplicarVolante(final String volante)\n"
    +"Unidade da dezena dever ser composta de dois digitos...");
        
     if(obterGrupoDoVolante(volante)>18)
     throw new Exception("Volante.java\nMetodo:aplicarVolante(final String volante)\n"
     +"Grupo do volante nao validado...\n"
     +"Grupo do volante deve ser da categoria de 15,16,17 ou 18...");    
     
     if(verificarExistenciaDeDezenaMultiplicada(volante))
     throw new Exception("Volante.java\nMetodo:aplicarVolante(final String volante)\n"
     +"Foi verificado existencia de dezena multiplicada...\n");
     
     this.grupoDoVolante=obterGrupoDoVolante(volante);
     this.volante=ordenarVolanteOrdemCrescente(volante);
     this.precoDoVolante=obterPrecoDoVolante(volante);
    }
    
    private int obterGrupoDoVolante(final String volante)throws Exception{
    int len=0;
    for(int i=0;i<volante.length();i++)
    if(volante.charAt(i)!=',')
    len++;    
    int divisao=(len/2);
    if(divisao==15 || divisao==16 || divisao==17 || divisao==18)return divisao;
    return 0;
    }
    
    private static boolean verificarUnidadeDaDezena(final String volante)
    throws Exception{
    int len=0;
    for(int i=0;i<volante.length();i++)if(volante.charAt(i)!=',')len++;    
    if((len%2)==0)return true;
    return false;
    }
    
    private static boolean verificarExistenciaDeDezenaMultiplicada(final String volante)
    throws Exception{
    for(int i=0;i<26;i++){
            int quantidadeRepetitiva=0;
            for(int j=0;j<volante.length();j+=3){
                String substr=volante.substring(j,j+2);
                Integer substrInt=Integer.valueOf(substr);
                if(substrInt!=0)
                if(substrInt==i)quantidadeRepetitiva++;    
            }
            if(quantidadeRepetitiva>1)return true;
                
    }
        return false;
    }
    
    private static boolean verificarExistenciaDeNumerosSomente(final String volante)
    throws Exception {
        final String caracterValido="0987654321,";
        for(int i=0;i<volante.length();i++){
            for(int j=0;j<caracterValido.length();j++){
                if(volante.charAt(i)!=caracterValido.charAt(j) && 
                        j==(caracterValido.length()-1)){
                    return false;
                }else if(volante.charAt(i)==caracterValido.charAt(j)){
                    break;
                }   
            }
        }
        return true;
    }
    
}
