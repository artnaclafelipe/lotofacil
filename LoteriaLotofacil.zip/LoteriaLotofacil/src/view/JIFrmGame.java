/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import javax.swing.SwingUtilities;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import model.JBtnMoveFrmToFront;
import java.awt.Color;
import javax.swing.JOptionPane;
import model.Game;
import view.JDlgWait;
import java.util.ArrayList;
import model.JBtnMoveFrmToFront;
/**
 *
 * @author felipe
 */
public class JIFrmGame extends javax.swing.JInternalFrame {

    private enum enmSignal{add,del};
    private String title;
    private static int order = 1;
    private JBtnMoveFrmToFront jbtnMoveFrmToFront = null;
    private enmSignal signal;
    private final static String ZERONUMBERVIEW = "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00";
    private ArrayList<Game> gameList;
    private int registeredGameIndex=-1;
    private static String MSGSORTEDNUMBERINDEXOUTOFRANGE="JIFrmGame.java\nindice de numero sorteado fora da faixa";
    private JDlgWait  jdlgWait;
    private Thread thrDlgWaitOne;
    private javax.swing.JDesktopPane jdskPane;
    private javax.swing.JPanel panelLister;
    
    private void commonConstruct(){
        initComponents();
        setIconifiable(true);
        setClosable(true);
        setSignal(enmSignal.add);
        
        addInternalFrameListener(new InternalFrameListener(){
            @Override
            public void internalFrameOpened(InternalFrameEvent ife) {
              
            }

            @Override
            public void internalFrameClosing(InternalFrameEvent ife) {
                SwingUtilities.invokeLater(new Runnable() {
                @Override
                 public void run() {
                     if(jbtnMoveFrmToFront!=null)
                     JIFrmGame.this.jbtnMoveFrmToFront.destroy();
                 }
                     
                });
            }
            @Override
            public void internalFrameClosed(InternalFrameEvent ife) {
               
            }

            @Override
            public void internalFrameIconified(InternalFrameEvent ife) {
                
            }

            @Override
            public void internalFrameDeiconified(InternalFrameEvent ife) {
               
            }

            @Override
            public void internalFrameActivated(InternalFrameEvent ife) {
               grabFocus();
            }

            @Override
            public void internalFrameDeactivated(InternalFrameEvent ife) {
               
            }
        });
        jdskPane.add(this);
    }
    
    /**
     * Creates new form JIFrmGame
     */
    public JIFrmGame(javax.swing.JDesktopPane jdskPane,
            javax.swing.JPanel panelLister,
            ArrayList<Game> gameList,
            String title) {
        
        this.jdskPane=jdskPane;
        this.panelLister=panelLister;
        
        commonConstruct();
        
        this.gameList = gameList;
        this.title = "Resultado-Pesuisa#"+title;
        setTitle(" 0:"+String.valueOf(gameList.size())+" "+this.title);
        
        try
        {
          registeredGameIndex=0;
          resetAllNumberPanel();
          Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
           }
        }catch(Exception e){
            JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
            +"\n"+"linha:"
            +String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                        
        }
        jbtnMoveFrmToFront = new JBtnMoveFrmToFront(this);
        panelLister.add(jbtnMoveFrmToFront);
        jbtnMoveFrmToFront.setText(getTitle());
        
        if(gameList.size()>0)
        JmnuItemNavegateGoFirstActionPerformedPublic();
        else
        resetAllNumberPanel();
        
    }
    
    public JIFrmGame(javax.swing.JDesktopPane jdskPane, 
            javax.swing.JPanel panelLister) {
        
        this.jdskPane=jdskPane;
        this.panelLister=panelLister;
        commonConstruct();
        
        this.title = "Novo Jogo-Bolao#"+String.valueOf(order++);
        gameList = new ArrayList();
        setTitle(" 0:"+String.valueOf(gameList.size())+" "+title);
        
        try
        {
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            
            gameList.add(new Game("22 21 20 19 14 13 09 08 07 06 05 04 03 02 01"));
            
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            
            gameList.add(new Game("23 22 21 20 19 13 09 08 07 06 05 04 03 02 01"));
            
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            gameList.add(new Game("25 24 23 22 21 20 09 08 07 06 05 04 03 02 01"));
            
            gameList.add(new Game("24 23 22 21 20 19 09 08 07 06 05 04 03 02 01"));
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }
        
        jbtnMoveFrmToFront = new JBtnMoveFrmToFront(this);
        panelLister.add(jbtnMoveFrmToFront);
        jbtnMoveFrmToFront.setText(getTitle());
        
        if(gameList.size()>0)
        JmnuItemNavegateGoFirstActionPerformedPublic();
        else
        resetAllNumberPanel();    
    }
    

    private enmSignal getSignal(){
        return this.signal;
    }
    
    private void setSignal(enmSignal sign){
        this.signal = sign;        
    }
    
    private void resetAllNumberPanel(){
        Color jlblViewSignalSymbolColor = jlblViewSignalSymbol.getForeground();
        jlblViewSignalSymbol.setForeground(Color.red);
        enmSignal currentSignalVal = getSignal();
        setSignal(enmSignal.del);
        jlblSorted.setText(ZERONUMBERVIEW);
        jlblSortedTotal.setText("00");
        jlblNumberView.setText("00");
        jpnelNumberOne.setBackground(Color.red);
        jpnelNumberOne1.setBackground(Color.red);
        jpnelNumberTwo.setBackground(Color.red);
        jpnelNumberTwo1.setBackground(Color.red);
        jpnelNumberThree.setBackground(Color.red);
        jpnelNumberThree1.setBackground(Color.red);
        jpnelNumberFour.setBackground(Color.red);
        jpnelNumberFour1.setBackground(Color.red);
        jpnelNumberFive.setBackground(Color.red);
        jpnelNumberFive1.setBackground(Color.red);
        jpnelNumberSix.setBackground(Color.red);
        jpnelNumberSix1.setBackground(Color.red);
        jpnelNumberSeven.setBackground(Color.red);
        jpnelNumberSeven1.setBackground(Color.red);
        jpnelNumberEight.setBackground(Color.red);
        jpnelNumberEight1.setBackground(Color.red);
        jpnelNumberNine.setBackground(Color.red);
        jpnelNumberNine1.setBackground(Color.red);
        jpnelNumberTen.setBackground(Color.red);
        jpnelNumberTen1.setBackground(Color.red);
        jpnelNumberEleven.setBackground(Color.red);
        jpnelNumberEleven1.setBackground(Color.red);
        jpnelNumberTwelth.setBackground(Color.red);
        jpnelNumberTwelth1.setBackground(Color.red);
        jpnelNumberThirthTeen.setBackground(Color.red);
        jpnelNumberThirthTeen1.setBackground(Color.red);
        jpnelNumberFourTeen.setBackground(Color.red);
        jpnelNumberFourTeen1.setBackground(Color.red);
        jpnelNumberFithTeen.setBackground(Color.red);
        jpnelNumberFithTeen1.setBackground(Color.red);
        jpnelNumberSixTeen.setBackground(Color.red);
        jpnelNumberSixTeen1.setBackground(Color.red);
        jpnelNumberSevenTeen.setBackground(Color.red);
        jpnelNumberSevenTeen1.setBackground(Color.red);
        jpnelNumberEightTeen.setBackground(Color.red);
        jpnelNumberEightTeen1.setBackground(Color.red);
        jpnelNumberNineTeen.setBackground(Color.red);
        jpnelNumberNineTeen1.setBackground(Color.red);
        jpnelNumberTwenty.setBackground(Color.red);
        jpnelNumberTwenty1.setBackground(Color.red);
        jpnelNumberTwentyOne.setBackground(Color.red);
        jpnelNumberTwentyOne1.setBackground(Color.red);
        jpnelNumberTwentyTwo.setBackground(Color.red);
        jpnelNumberTwentyTwo1.setBackground(Color.red);
        jpnelNumberTwentyThree.setBackground(Color.red);
        jpnelNumberTwentyThree1.setBackground(Color.red);
        jpnelNumberTwentyFour.setBackground(Color.red);
        jpnelNumberTwentyFour1.setBackground(Color.red);
        jpnelNumberTwentyFive.setBackground(Color.red);
        jpnelNumberTwentyFive1.setBackground(Color.red);
        setSignal(currentSignalVal);
        jlblViewSignalSymbol.setForeground(jlblViewSignalSymbolColor);
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpnelSymbolism = new javax.swing.JPanel();
        jlblSymbolismOne = new javax.swing.JLabel();
        jpnelSymbolismOneBlue1 = new javax.swing.JPanel();
        jpnelSymbolismOneBlue2 = new javax.swing.JPanel();
        jpnelSymbolismTwoRed = new javax.swing.JPanel();
        jlblSymbolismTwo = new javax.swing.JLabel();
        jpnelSymbolismTwoBlue = new javax.swing.JPanel();
        jlblSymbolismThree = new javax.swing.JLabel();
        jpnelSymbolismThreeRed1 = new javax.swing.JPanel();
        jpnelSymbolismThreeRed2 = new javax.swing.JPanel();
        jlblSymbolismFour = new javax.swing.JLabel();
        jpnelSymbolismFourRed = new javax.swing.JPanel();
        jpnelSymbolismFourBlue = new javax.swing.JPanel();
        jpnelView = new javax.swing.JPanel();
        jlblViewPincel = new javax.swing.JLabel();
        jpnelViewPincelBlue = new javax.swing.JPanel();
        jlblViewPincelBlue = new javax.swing.JLabel();
        jpnelViewPincelRed = new javax.swing.JPanel();
        jlblViewPincelRed = new javax.swing.JLabel();
        jlblViewSignalSymbol = new javax.swing.JLabel();
        jlblViewPrice = new javax.swing.JLabel();
        jpnelNumber = new javax.swing.JPanel();
        jpnelNumberFive = new javax.swing.JPanel();
        jlblNumberFive = new javax.swing.JLabel();
        jpnelNumberFour = new javax.swing.JPanel();
        jlblNumberFour = new javax.swing.JLabel();
        jpnelNumberThree = new javax.swing.JPanel();
        jlblNumberThree = new javax.swing.JLabel();
        jpnelNumberTwo = new javax.swing.JPanel();
        jlblNumberTwo = new javax.swing.JLabel();
        jpnelNumberOne = new javax.swing.JPanel();
        jlblNumberOne = new javax.swing.JLabel();
        jpnelNumberTen = new javax.swing.JPanel();
        jlblNumberTen = new javax.swing.JLabel();
        jpnelNumberNine = new javax.swing.JPanel();
        jlblNumberNine = new javax.swing.JLabel();
        jpnelNumberEight = new javax.swing.JPanel();
        jlblNumberEight = new javax.swing.JLabel();
        jpnelNumberSeven = new javax.swing.JPanel();
        jlblNumberSeven = new javax.swing.JLabel();
        jpnelNumberSix = new javax.swing.JPanel();
        jlblNumberSix = new javax.swing.JLabel();
        jpnelNumberFithTeen = new javax.swing.JPanel();
        jlblNumberFithTeen = new javax.swing.JLabel();
        jpnelNumberFourTeen = new javax.swing.JPanel();
        jlblNumberFourTeen = new javax.swing.JLabel();
        jpnelNumberThirthTeen = new javax.swing.JPanel();
        jlblNumberThirthTeen = new javax.swing.JLabel();
        jpnelNumberTwelth = new javax.swing.JPanel();
        jlblNumberTwelth = new javax.swing.JLabel();
        jpnelNumberEleven = new javax.swing.JPanel();
        jlblNumberEleven = new javax.swing.JLabel();
        jpnelNumberTwenty = new javax.swing.JPanel();
        jlblNumberTwenty = new javax.swing.JLabel();
        jpnelNumberNineTeen = new javax.swing.JPanel();
        jlblNumberNineTeen = new javax.swing.JLabel();
        jpnelNumberEightTeen = new javax.swing.JPanel();
        jlblNumberEightTeen = new javax.swing.JLabel();
        jpnelNumberSevenTeen = new javax.swing.JPanel();
        jlblNumberSevenTeen = new javax.swing.JLabel();
        jpnelNumberSixTeen = new javax.swing.JPanel();
        jlblNumberSixTeen = new javax.swing.JLabel();
        jpnelNumberTwentyFive = new javax.swing.JPanel();
        jlblNumberTwentyFive = new javax.swing.JLabel();
        jpnelNumberTwentyFour = new javax.swing.JPanel();
        jlblNumberTwentyFour = new javax.swing.JLabel();
        jpnelNumberTwentyThree = new javax.swing.JPanel();
        jlblNumberTwentyThree = new javax.swing.JLabel();
        jpnelNumberTwentyTwo = new javax.swing.JPanel();
        jlblNumberTwentyTwo = new javax.swing.JLabel();
        jpnelNumberTwentyOne = new javax.swing.JPanel();
        jlblNumberTwentyOne = new javax.swing.JLabel();
        jlblNumberView = new javax.swing.JLabel();
        jpnelNumberFive1 = new javax.swing.JPanel();
        jlblNumberFive1 = new javax.swing.JLabel();
        jpnelNumberFour1 = new javax.swing.JPanel();
        jlblNumberFour1 = new javax.swing.JLabel();
        jpnelNumberThree1 = new javax.swing.JPanel();
        jlblNumberThree1 = new javax.swing.JLabel();
        jpnelNumberTwo1 = new javax.swing.JPanel();
        jlblNumberTwo1 = new javax.swing.JLabel();
        jpnelNumberOne1 = new javax.swing.JPanel();
        jlblNumberOne1 = new javax.swing.JLabel();
        jpnelNumberTen1 = new javax.swing.JPanel();
        jlblNumberTen1 = new javax.swing.JLabel();
        jpnelNumberNine1 = new javax.swing.JPanel();
        jlblNumberNine1 = new javax.swing.JLabel();
        jpnelNumberEight1 = new javax.swing.JPanel();
        jlblNumberEight1 = new javax.swing.JLabel();
        jpnelNumberSeven1 = new javax.swing.JPanel();
        jlblNumberSeven1 = new javax.swing.JLabel();
        jpnelNumberSix1 = new javax.swing.JPanel();
        jlblNumberSix1 = new javax.swing.JLabel();
        jpnelNumberFithTeen1 = new javax.swing.JPanel();
        jlblNumberFithTeen1 = new javax.swing.JLabel();
        jpnelNumberFourTeen1 = new javax.swing.JPanel();
        jlblNumberFourTeen1 = new javax.swing.JLabel();
        jpnelNumberThirthTeen1 = new javax.swing.JPanel();
        jlblNumberThirthTeen1 = new javax.swing.JLabel();
        jpnelNumberTwelth1 = new javax.swing.JPanel();
        jlblNumberTwelth1 = new javax.swing.JLabel();
        jpnelNumberEleven1 = new javax.swing.JPanel();
        jlblNumberEleven1 = new javax.swing.JLabel();
        jpnelNumberTwenty1 = new javax.swing.JPanel();
        jlblNumberTwenty1 = new javax.swing.JLabel();
        jpnelNumberNineTeen1 = new javax.swing.JPanel();
        jlblNumberNineTeen1 = new javax.swing.JLabel();
        jpnelNumberEightTeen1 = new javax.swing.JPanel();
        jlblNumberEightTeen1 = new javax.swing.JLabel();
        jpnelNumberSevenTeen1 = new javax.swing.JPanel();
        jlblNumberSevenTeen1 = new javax.swing.JLabel();
        jpnelNumberSixTeen1 = new javax.swing.JPanel();
        jlblNumberSixTeen1 = new javax.swing.JLabel();
        jpnelNumberTwentyFive1 = new javax.swing.JPanel();
        jlblNumberTwentyFive1 = new javax.swing.JLabel();
        jpnelNumberTwentyFour1 = new javax.swing.JPanel();
        jlblNumberTwentyFour1 = new javax.swing.JLabel();
        jpnelNumberTwentyThree1 = new javax.swing.JPanel();
        jlblNumberTwentyThree1 = new javax.swing.JLabel();
        jpnelNumberTwentyTwo1 = new javax.swing.JPanel();
        jlblNumberTwentyTwo1 = new javax.swing.JLabel();
        jpnelNumberTwentyOne1 = new javax.swing.JPanel();
        jlblNumberTwentyOne1 = new javax.swing.JLabel();
        jpnelSorted = new javax.swing.JPanel();
        jlblSorted = new javax.swing.JLabel();
        jlblSortedTotal = new javax.swing.JLabel();
        jlblPrice15 = new javax.swing.JLabel();
        jlblPrice16 = new javax.swing.JLabel();
        jlblPrice18 = new javax.swing.JLabel();
        jlblPrice17 = new javax.swing.JLabel();
        JmnuBarGame = new javax.swing.JMenuBar();
        jmnuCard = new javax.swing.JMenu();
        JmnuItemCardNew = new javax.swing.JMenuItem();
        JmnuItemCardSave = new javax.swing.JMenuItem();
        JmnuItemCardDelete = new javax.swing.JMenuItem();
        JmnuItemCardUndo = new javax.swing.JMenuItem();
        jmnuNavegate = new javax.swing.JMenu();
        JmnuItemNavegateGoFirst = new javax.swing.JMenuItem();
        JmnuItemNavegateGoNext = new javax.swing.JMenuItem();
        JmnuItemNavegateGoPrevious = new javax.swing.JMenuItem();
        JmnuItemNavegateGoLast = new javax.swing.JMenuItem();
        JmnuItemNavegateGoTo = new javax.swing.JMenuItem();
        JmnuItemPanel = new javax.swing.JMenu();
        JmnuItemPanelPincelRed = new javax.swing.JMenuItem();
        JmnuItemPanelPincelBlue = new javax.swing.JMenuItem();
        JmnuItemPanelRedAll = new javax.swing.JMenuItem();
        JmnuItemPanelNumbers = new javax.swing.JMenu();
        JmnuItemPanelNumbersOne = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersTwo = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersThree = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersFour = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersFive = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersSix = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersSeven = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersEight = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersNine = new javax.swing.JMenuItem();
        JmnuItemPanelNumbersZero = new javax.swing.JMenuItem();
        JmnuItemPanelPaintNumber = new javax.swing.JMenuItem();
        JmnuItemPanelBackspace = new javax.swing.JMenuItem();
        JmnuItemPanelEscape = new javax.swing.JMenuItem();
        JmnuItemPanelCheckMultiplicity = new javax.swing.JMenuItem();

        setBackground(new java.awt.Color(204, 204, 204));

        jpnelSymbolism.setBackground(Color.BLACK);

        jlblSymbolismOne.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSymbolismOne.setForeground(new java.awt.Color(255, 255, 255));
        jlblSymbolismOne.setText("1");

        jpnelSymbolismOneBlue1.setBackground(Color.BLUE);

        javax.swing.GroupLayout jpnelSymbolismOneBlue1Layout = new javax.swing.GroupLayout(jpnelSymbolismOneBlue1);
        jpnelSymbolismOneBlue1.setLayout(jpnelSymbolismOneBlue1Layout);
        jpnelSymbolismOneBlue1Layout.setHorizontalGroup(
            jpnelSymbolismOneBlue1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismOneBlue1Layout.setVerticalGroup(
            jpnelSymbolismOneBlue1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jpnelSymbolismOneBlue2.setBackground(Color.BLUE);
        jpnelSymbolismOneBlue2.setForeground(Color.BLUE);

        javax.swing.GroupLayout jpnelSymbolismOneBlue2Layout = new javax.swing.GroupLayout(jpnelSymbolismOneBlue2);
        jpnelSymbolismOneBlue2.setLayout(jpnelSymbolismOneBlue2Layout);
        jpnelSymbolismOneBlue2Layout.setHorizontalGroup(
            jpnelSymbolismOneBlue2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismOneBlue2Layout.setVerticalGroup(
            jpnelSymbolismOneBlue2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jpnelSymbolismTwoRed.setBackground(Color.RED);
        jpnelSymbolismTwoRed.setForeground(Color.BLUE);

        javax.swing.GroupLayout jpnelSymbolismTwoRedLayout = new javax.swing.GroupLayout(jpnelSymbolismTwoRed);
        jpnelSymbolismTwoRed.setLayout(jpnelSymbolismTwoRedLayout);
        jpnelSymbolismTwoRedLayout.setHorizontalGroup(
            jpnelSymbolismTwoRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismTwoRedLayout.setVerticalGroup(
            jpnelSymbolismTwoRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );

        jlblSymbolismTwo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSymbolismTwo.setForeground(new java.awt.Color(255, 255, 255));
        jlblSymbolismTwo.setText("2");

        jpnelSymbolismTwoBlue.setBackground(Color.BLUE);

        javax.swing.GroupLayout jpnelSymbolismTwoBlueLayout = new javax.swing.GroupLayout(jpnelSymbolismTwoBlue);
        jpnelSymbolismTwoBlue.setLayout(jpnelSymbolismTwoBlueLayout);
        jpnelSymbolismTwoBlueLayout.setHorizontalGroup(
            jpnelSymbolismTwoBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismTwoBlueLayout.setVerticalGroup(
            jpnelSymbolismTwoBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jlblSymbolismThree.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSymbolismThree.setForeground(new java.awt.Color(255, 255, 255));
        jlblSymbolismThree.setText("3");

        jpnelSymbolismThreeRed1.setBackground(Color.RED);

        javax.swing.GroupLayout jpnelSymbolismThreeRed1Layout = new javax.swing.GroupLayout(jpnelSymbolismThreeRed1);
        jpnelSymbolismThreeRed1.setLayout(jpnelSymbolismThreeRed1Layout);
        jpnelSymbolismThreeRed1Layout.setHorizontalGroup(
            jpnelSymbolismThreeRed1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismThreeRed1Layout.setVerticalGroup(
            jpnelSymbolismThreeRed1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jpnelSymbolismThreeRed2.setBackground(Color.RED);
        jpnelSymbolismThreeRed2.setForeground(Color.BLUE);

        javax.swing.GroupLayout jpnelSymbolismThreeRed2Layout = new javax.swing.GroupLayout(jpnelSymbolismThreeRed2);
        jpnelSymbolismThreeRed2.setLayout(jpnelSymbolismThreeRed2Layout);
        jpnelSymbolismThreeRed2Layout.setHorizontalGroup(
            jpnelSymbolismThreeRed2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismThreeRed2Layout.setVerticalGroup(
            jpnelSymbolismThreeRed2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );

        jlblSymbolismFour.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSymbolismFour.setForeground(new java.awt.Color(255, 255, 255));
        jlblSymbolismFour.setText("4");

        jpnelSymbolismFourRed.setBackground(Color.RED);

        javax.swing.GroupLayout jpnelSymbolismFourRedLayout = new javax.swing.GroupLayout(jpnelSymbolismFourRed);
        jpnelSymbolismFourRed.setLayout(jpnelSymbolismFourRedLayout);
        jpnelSymbolismFourRedLayout.setHorizontalGroup(
            jpnelSymbolismFourRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismFourRedLayout.setVerticalGroup(
            jpnelSymbolismFourRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jpnelSymbolismFourBlue.setBackground(Color.BLUE);
        jpnelSymbolismFourBlue.setForeground(Color.BLUE);

        javax.swing.GroupLayout jpnelSymbolismFourBlueLayout = new javax.swing.GroupLayout(jpnelSymbolismFourBlue);
        jpnelSymbolismFourBlue.setLayout(jpnelSymbolismFourBlueLayout);
        jpnelSymbolismFourBlueLayout.setHorizontalGroup(
            jpnelSymbolismFourBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismFourBlueLayout.setVerticalGroup(
            jpnelSymbolismFourBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jpnelSymbolismLayout = new javax.swing.GroupLayout(jpnelSymbolism);
        jpnelSymbolism.setLayout(jpnelSymbolismLayout);
        jpnelSymbolismLayout.setHorizontalGroup(
            jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                        .addComponent(jlblSymbolismOne)
                        .addGap(3, 3, 3)
                        .addComponent(jpnelSymbolismOneBlue1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelSymbolismOneBlue2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                            .addComponent(jlblSymbolismThree)
                            .addGap(3, 3, 3)
                            .addComponent(jpnelSymbolismThreeRed1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jpnelSymbolismThreeRed2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelSymbolismLayout.createSequentialGroup()
                            .addComponent(jlblSymbolismFour)
                            .addGap(3, 3, 3)
                            .addComponent(jpnelSymbolismFourRed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jpnelSymbolismFourBlue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                        .addComponent(jlblSymbolismTwo)
                        .addGap(3, 3, 3)
                        .addComponent(jpnelSymbolismTwoBlue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelSymbolismTwoRed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpnelSymbolismLayout.setVerticalGroup(
            jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblSymbolismOne, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismOneBlue1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismOneBlue2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblSymbolismTwo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismTwoBlue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismTwoRed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblSymbolismThree, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismThreeRed1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismThreeRed2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblSymbolismFour, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismFourRed, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismFourBlue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jpnelView.setBackground(Color.WHITE);

        jlblViewPincel.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblViewPincel.setForeground(Color.BLACK);
        jlblViewPincel.setText("PINCEL:");

        jpnelViewPincelBlue.setBackground(Color.BLUE);
        jpnelViewPincelBlue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jpnelViewPincelBlueMouseClicked(evt);
            }
        });

        jlblViewPincelBlue.setForeground(new java.awt.Color(255, 255, 255));
        jlblViewPincelBlue.setText("F2");
        jlblViewPincelBlue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblViewPincelBlueMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jpnelViewPincelBlueLayout = new javax.swing.GroupLayout(jpnelViewPincelBlue);
        jpnelViewPincelBlue.setLayout(jpnelViewPincelBlueLayout);
        jpnelViewPincelBlueLayout.setHorizontalGroup(
            jpnelViewPincelBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelViewPincelBlueLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlblViewPincelBlue)
                .addContainerGap())
        );
        jpnelViewPincelBlueLayout.setVerticalGroup(
            jpnelViewPincelBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblViewPincelBlue, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jpnelViewPincelRed.setBackground(Color.RED);
        jpnelViewPincelRed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jpnelViewPincelRedMouseClicked(evt);
            }
        });

        jlblViewPincelRed.setForeground(Color.BLACK);
        jlblViewPincelRed.setText("F1");
        jlblViewPincelRed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblViewPincelRedMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jpnelViewPincelRedLayout = new javax.swing.GroupLayout(jpnelViewPincelRed);
        jpnelViewPincelRed.setLayout(jpnelViewPincelRedLayout);
        jpnelViewPincelRedLayout.setHorizontalGroup(
            jpnelViewPincelRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelViewPincelRedLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlblViewPincelRed)
                .addContainerGap())
        );
        jpnelViewPincelRedLayout.setVerticalGroup(
            jpnelViewPincelRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblViewPincelRed, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jlblViewSignalSymbol.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblViewSignalSymbol.setForeground(Color.BLUE);
        jlblViewSignalSymbol.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblViewSignalSymbol.setText("VERMELHAR-TUDO (F3)");
        jlblViewSignalSymbol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblViewSignalSymbolMouseClicked(evt);
            }
        });

        jlblViewPrice.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblViewPrice.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblViewPrice.setText("R$ 00,00");

        javax.swing.GroupLayout jpnelViewLayout = new javax.swing.GroupLayout(jpnelView);
        jpnelView.setLayout(jpnelViewLayout);
        jpnelViewLayout.setHorizontalGroup(
            jpnelViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelViewLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblViewPincel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jpnelViewPincelRed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jpnelViewPincelBlue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblViewSignalSymbol)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblViewPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnelViewLayout.setVerticalGroup(
            jpnelViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelViewLayout.createSequentialGroup()
                .addGroup(jpnelViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelViewLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jpnelViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jpnelViewPincelBlue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblViewPincel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jpnelViewPincelRed, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblViewSignalSymbol)))
                    .addGroup(jpnelViewLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jlblViewPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jpnelNumber.setBackground(Color.BLACK);

        jpnelNumberFive.setBackground(Color.WHITE);

        jlblNumberFive.setBackground(Color.BLACK);
        jlblNumberFive.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFive.setForeground(Color.WHITE);
        jlblNumberFive.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFive.setText("05");

        javax.swing.GroupLayout jpnelNumberFiveLayout = new javax.swing.GroupLayout(jpnelNumberFive);
        jpnelNumberFive.setLayout(jpnelNumberFiveLayout);
        jpnelNumberFiveLayout.setHorizontalGroup(
            jpnelNumberFiveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFive, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFiveLayout.setVerticalGroup(
            jpnelNumberFiveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFour.setBackground(Color.WHITE);

        jlblNumberFour.setBackground(Color.BLACK);
        jlblNumberFour.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFour.setForeground(Color.WHITE);
        jlblNumberFour.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFour.setText("04");

        javax.swing.GroupLayout jpnelNumberFourLayout = new javax.swing.GroupLayout(jpnelNumberFour);
        jpnelNumberFour.setLayout(jpnelNumberFourLayout);
        jpnelNumberFourLayout.setHorizontalGroup(
            jpnelNumberFourLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFour, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFourLayout.setVerticalGroup(
            jpnelNumberFourLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberThree.setBackground(Color.WHITE);

        jlblNumberThree.setBackground(Color.BLACK);
        jlblNumberThree.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberThree.setForeground(Color.WHITE);
        jlblNumberThree.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberThree.setText("03");

        javax.swing.GroupLayout jpnelNumberThreeLayout = new javax.swing.GroupLayout(jpnelNumberThree);
        jpnelNumberThree.setLayout(jpnelNumberThreeLayout);
        jpnelNumberThreeLayout.setHorizontalGroup(
            jpnelNumberThreeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThree, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberThreeLayout.setVerticalGroup(
            jpnelNumberThreeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThree, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwo.setBackground(Color.WHITE);

        jlblNumberTwo.setBackground(Color.BLACK);
        jlblNumberTwo.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwo.setForeground(Color.WHITE);
        jlblNumberTwo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwo.setText("02");

        javax.swing.GroupLayout jpnelNumberTwoLayout = new javax.swing.GroupLayout(jpnelNumberTwo);
        jpnelNumberTwo.setLayout(jpnelNumberTwoLayout);
        jpnelNumberTwoLayout.setHorizontalGroup(
            jpnelNumberTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwoLayout.setVerticalGroup(
            jpnelNumberTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberOne.setBackground(Color.WHITE);

        jlblNumberOne.setBackground(Color.BLACK);
        jlblNumberOne.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberOne.setForeground(Color.WHITE);
        jlblNumberOne.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberOne.setText("01");

        javax.swing.GroupLayout jpnelNumberOneLayout = new javax.swing.GroupLayout(jpnelNumberOne);
        jpnelNumberOne.setLayout(jpnelNumberOneLayout);
        jpnelNumberOneLayout.setHorizontalGroup(
            jpnelNumberOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberOne, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberOneLayout.setVerticalGroup(
            jpnelNumberOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberOne, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTen.setBackground(Color.WHITE);

        jlblNumberTen.setBackground(Color.BLACK);
        jlblNumberTen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTen.setForeground(Color.WHITE);
        jlblNumberTen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTen.setText("10");

        javax.swing.GroupLayout jpnelNumberTenLayout = new javax.swing.GroupLayout(jpnelNumberTen);
        jpnelNumberTen.setLayout(jpnelNumberTenLayout);
        jpnelNumberTenLayout.setHorizontalGroup(
            jpnelNumberTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTenLayout.setVerticalGroup(
            jpnelNumberTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberNine.setBackground(Color.WHITE);

        jlblNumberNine.setBackground(Color.BLACK);
        jlblNumberNine.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberNine.setForeground(Color.WHITE);
        jlblNumberNine.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberNine.setText("09");

        javax.swing.GroupLayout jpnelNumberNineLayout = new javax.swing.GroupLayout(jpnelNumberNine);
        jpnelNumberNine.setLayout(jpnelNumberNineLayout);
        jpnelNumberNineLayout.setHorizontalGroup(
            jpnelNumberNineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNine, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberNineLayout.setVerticalGroup(
            jpnelNumberNineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNine, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEight.setBackground(Color.WHITE);

        jlblNumberEight.setBackground(Color.BLACK);
        jlblNumberEight.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEight.setForeground(Color.WHITE);
        jlblNumberEight.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEight.setText("08");

        javax.swing.GroupLayout jpnelNumberEightLayout = new javax.swing.GroupLayout(jpnelNumberEight);
        jpnelNumberEight.setLayout(jpnelNumberEightLayout);
        jpnelNumberEightLayout.setHorizontalGroup(
            jpnelNumberEightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEight, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEightLayout.setVerticalGroup(
            jpnelNumberEightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEight, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSeven.setBackground(Color.WHITE);

        jlblNumberSeven.setBackground(Color.BLACK);
        jlblNumberSeven.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSeven.setForeground(Color.WHITE);
        jlblNumberSeven.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSeven.setText("07");

        javax.swing.GroupLayout jpnelNumberSevenLayout = new javax.swing.GroupLayout(jpnelNumberSeven);
        jpnelNumberSeven.setLayout(jpnelNumberSevenLayout);
        jpnelNumberSevenLayout.setHorizontalGroup(
            jpnelNumberSevenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSeven, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSevenLayout.setVerticalGroup(
            jpnelNumberSevenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSeven, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSix.setBackground(Color.WHITE);

        jlblNumberSix.setBackground(Color.BLACK);
        jlblNumberSix.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSix.setForeground(Color.WHITE);
        jlblNumberSix.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSix.setText("06");

        javax.swing.GroupLayout jpnelNumberSixLayout = new javax.swing.GroupLayout(jpnelNumberSix);
        jpnelNumberSix.setLayout(jpnelNumberSixLayout);
        jpnelNumberSixLayout.setHorizontalGroup(
            jpnelNumberSixLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSix, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSixLayout.setVerticalGroup(
            jpnelNumberSixLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSix, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFithTeen.setBackground(Color.WHITE);

        jlblNumberFithTeen.setBackground(Color.BLACK);
        jlblNumberFithTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFithTeen.setForeground(Color.WHITE);
        jlblNumberFithTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFithTeen.setText("15");

        javax.swing.GroupLayout jpnelNumberFithTeenLayout = new javax.swing.GroupLayout(jpnelNumberFithTeen);
        jpnelNumberFithTeen.setLayout(jpnelNumberFithTeenLayout);
        jpnelNumberFithTeenLayout.setHorizontalGroup(
            jpnelNumberFithTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFithTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFithTeenLayout.setVerticalGroup(
            jpnelNumberFithTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFithTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFourTeen.setBackground(Color.WHITE);

        jlblNumberFourTeen.setBackground(Color.BLACK);
        jlblNumberFourTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFourTeen.setForeground(Color.WHITE);
        jlblNumberFourTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFourTeen.setText("14");

        javax.swing.GroupLayout jpnelNumberFourTeenLayout = new javax.swing.GroupLayout(jpnelNumberFourTeen);
        jpnelNumberFourTeen.setLayout(jpnelNumberFourTeenLayout);
        jpnelNumberFourTeenLayout.setHorizontalGroup(
            jpnelNumberFourTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFourTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFourTeenLayout.setVerticalGroup(
            jpnelNumberFourTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFourTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberThirthTeen.setBackground(Color.WHITE);

        jlblNumberThirthTeen.setBackground(Color.BLACK);
        jlblNumberThirthTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberThirthTeen.setForeground(Color.WHITE);
        jlblNumberThirthTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberThirthTeen.setText("13");

        javax.swing.GroupLayout jpnelNumberThirthTeenLayout = new javax.swing.GroupLayout(jpnelNumberThirthTeen);
        jpnelNumberThirthTeen.setLayout(jpnelNumberThirthTeenLayout);
        jpnelNumberThirthTeenLayout.setHorizontalGroup(
            jpnelNumberThirthTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThirthTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberThirthTeenLayout.setVerticalGroup(
            jpnelNumberThirthTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThirthTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwelth.setBackground(Color.WHITE);

        jlblNumberTwelth.setBackground(Color.BLACK);
        jlblNumberTwelth.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwelth.setForeground(Color.WHITE);
        jlblNumberTwelth.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwelth.setText("12");

        javax.swing.GroupLayout jpnelNumberTwelthLayout = new javax.swing.GroupLayout(jpnelNumberTwelth);
        jpnelNumberTwelth.setLayout(jpnelNumberTwelthLayout);
        jpnelNumberTwelthLayout.setHorizontalGroup(
            jpnelNumberTwelthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwelth, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwelthLayout.setVerticalGroup(
            jpnelNumberTwelthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwelth, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEleven.setBackground(Color.WHITE);

        jlblNumberEleven.setBackground(Color.BLACK);
        jlblNumberEleven.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEleven.setForeground(Color.WHITE);
        jlblNumberEleven.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEleven.setText("11");

        javax.swing.GroupLayout jpnelNumberElevenLayout = new javax.swing.GroupLayout(jpnelNumberEleven);
        jpnelNumberEleven.setLayout(jpnelNumberElevenLayout);
        jpnelNumberElevenLayout.setHorizontalGroup(
            jpnelNumberElevenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEleven, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberElevenLayout.setVerticalGroup(
            jpnelNumberElevenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEleven, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwenty.setBackground(Color.WHITE);

        jlblNumberTwenty.setBackground(Color.BLACK);
        jlblNumberTwenty.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwenty.setForeground(Color.WHITE);
        jlblNumberTwenty.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwenty.setText("20");

        javax.swing.GroupLayout jpnelNumberTwentyLayout = new javax.swing.GroupLayout(jpnelNumberTwenty);
        jpnelNumberTwenty.setLayout(jpnelNumberTwentyLayout);
        jpnelNumberTwentyLayout.setHorizontalGroup(
            jpnelNumberTwentyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwenty, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyLayout.setVerticalGroup(
            jpnelNumberTwentyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwenty, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberNineTeen.setBackground(Color.WHITE);

        jlblNumberNineTeen.setBackground(Color.BLACK);
        jlblNumberNineTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberNineTeen.setForeground(Color.WHITE);
        jlblNumberNineTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberNineTeen.setText("19");

        javax.swing.GroupLayout jpnelNumberNineTeenLayout = new javax.swing.GroupLayout(jpnelNumberNineTeen);
        jpnelNumberNineTeen.setLayout(jpnelNumberNineTeenLayout);
        jpnelNumberNineTeenLayout.setHorizontalGroup(
            jpnelNumberNineTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNineTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberNineTeenLayout.setVerticalGroup(
            jpnelNumberNineTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNineTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEightTeen.setBackground(Color.WHITE);

        jlblNumberEightTeen.setBackground(Color.BLACK);
        jlblNumberEightTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEightTeen.setForeground(Color.WHITE);
        jlblNumberEightTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEightTeen.setText("18");

        javax.swing.GroupLayout jpnelNumberEightTeenLayout = new javax.swing.GroupLayout(jpnelNumberEightTeen);
        jpnelNumberEightTeen.setLayout(jpnelNumberEightTeenLayout);
        jpnelNumberEightTeenLayout.setHorizontalGroup(
            jpnelNumberEightTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEightTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEightTeenLayout.setVerticalGroup(
            jpnelNumberEightTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEightTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSevenTeen.setBackground(Color.WHITE);

        jlblNumberSevenTeen.setBackground(Color.BLACK);
        jlblNumberSevenTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSevenTeen.setForeground(Color.WHITE);
        jlblNumberSevenTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSevenTeen.setText("17");

        javax.swing.GroupLayout jpnelNumberSevenTeenLayout = new javax.swing.GroupLayout(jpnelNumberSevenTeen);
        jpnelNumberSevenTeen.setLayout(jpnelNumberSevenTeenLayout);
        jpnelNumberSevenTeenLayout.setHorizontalGroup(
            jpnelNumberSevenTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSevenTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSevenTeenLayout.setVerticalGroup(
            jpnelNumberSevenTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSevenTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSixTeen.setBackground(Color.WHITE);

        jlblNumberSixTeen.setBackground(Color.BLACK);
        jlblNumberSixTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSixTeen.setForeground(Color.WHITE);
        jlblNumberSixTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSixTeen.setText("16");

        javax.swing.GroupLayout jpnelNumberSixTeenLayout = new javax.swing.GroupLayout(jpnelNumberSixTeen);
        jpnelNumberSixTeen.setLayout(jpnelNumberSixTeenLayout);
        jpnelNumberSixTeenLayout.setHorizontalGroup(
            jpnelNumberSixTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSixTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSixTeenLayout.setVerticalGroup(
            jpnelNumberSixTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSixTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyFive.setBackground(Color.WHITE);

        jlblNumberTwentyFive.setBackground(Color.BLACK);
        jlblNumberTwentyFive.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyFive.setForeground(Color.WHITE);
        jlblNumberTwentyFive.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyFive.setText("25");

        javax.swing.GroupLayout jpnelNumberTwentyFiveLayout = new javax.swing.GroupLayout(jpnelNumberTwentyFive);
        jpnelNumberTwentyFive.setLayout(jpnelNumberTwentyFiveLayout);
        jpnelNumberTwentyFiveLayout.setHorizontalGroup(
            jpnelNumberTwentyFiveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFive, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyFiveLayout.setVerticalGroup(
            jpnelNumberTwentyFiveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyFour.setBackground(Color.WHITE);

        jlblNumberTwentyFour.setBackground(Color.BLACK);
        jlblNumberTwentyFour.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyFour.setForeground(Color.WHITE);
        jlblNumberTwentyFour.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyFour.setText("24");

        javax.swing.GroupLayout jpnelNumberTwentyFourLayout = new javax.swing.GroupLayout(jpnelNumberTwentyFour);
        jpnelNumberTwentyFour.setLayout(jpnelNumberTwentyFourLayout);
        jpnelNumberTwentyFourLayout.setHorizontalGroup(
            jpnelNumberTwentyFourLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFour, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyFourLayout.setVerticalGroup(
            jpnelNumberTwentyFourLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyThree.setBackground(Color.WHITE);

        jlblNumberTwentyThree.setBackground(Color.BLACK);
        jlblNumberTwentyThree.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyThree.setForeground(Color.WHITE);
        jlblNumberTwentyThree.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyThree.setText("23");

        javax.swing.GroupLayout jpnelNumberTwentyThreeLayout = new javax.swing.GroupLayout(jpnelNumberTwentyThree);
        jpnelNumberTwentyThree.setLayout(jpnelNumberTwentyThreeLayout);
        jpnelNumberTwentyThreeLayout.setHorizontalGroup(
            jpnelNumberTwentyThreeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyThree, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyThreeLayout.setVerticalGroup(
            jpnelNumberTwentyThreeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyThree, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyTwo.setBackground(Color.WHITE);

        jlblNumberTwentyTwo.setBackground(Color.BLACK);
        jlblNumberTwentyTwo.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyTwo.setForeground(Color.WHITE);
        jlblNumberTwentyTwo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyTwo.setText("22");

        javax.swing.GroupLayout jpnelNumberTwentyTwoLayout = new javax.swing.GroupLayout(jpnelNumberTwentyTwo);
        jpnelNumberTwentyTwo.setLayout(jpnelNumberTwentyTwoLayout);
        jpnelNumberTwentyTwoLayout.setHorizontalGroup(
            jpnelNumberTwentyTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyTwoLayout.setVerticalGroup(
            jpnelNumberTwentyTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyTwo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyOne.setBackground(Color.WHITE);

        jlblNumberTwentyOne.setBackground(Color.BLACK);
        jlblNumberTwentyOne.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyOne.setForeground(Color.WHITE);
        jlblNumberTwentyOne.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyOne.setText("21");

        javax.swing.GroupLayout jpnelNumberTwentyOneLayout = new javax.swing.GroupLayout(jpnelNumberTwentyOne);
        jpnelNumberTwentyOne.setLayout(jpnelNumberTwentyOneLayout);
        jpnelNumberTwentyOneLayout.setHorizontalGroup(
            jpnelNumberTwentyOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyOne, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyOneLayout.setVerticalGroup(
            jpnelNumberTwentyOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyOne, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jlblNumberView.setFont(new java.awt.Font("Dialog", 1, 50)); // NOI18N
        jlblNumberView.setForeground(Color.WHITE);
        jlblNumberView.setText("00");

        jpnelNumberFive1.setBackground(Color.WHITE);

        jlblNumberFive1.setBackground(Color.BLACK);
        jlblNumberFive1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFive1.setForeground(Color.WHITE);
        jlblNumberFive1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFive1.setText("05");

        javax.swing.GroupLayout jpnelNumberFive1Layout = new javax.swing.GroupLayout(jpnelNumberFive1);
        jpnelNumberFive1.setLayout(jpnelNumberFive1Layout);
        jpnelNumberFive1Layout.setHorizontalGroup(
            jpnelNumberFive1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFive1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFive1Layout.setVerticalGroup(
            jpnelNumberFive1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFive1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFour1.setBackground(Color.WHITE);

        jlblNumberFour1.setBackground(Color.BLACK);
        jlblNumberFour1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFour1.setForeground(Color.WHITE);
        jlblNumberFour1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFour1.setText("04");

        javax.swing.GroupLayout jpnelNumberFour1Layout = new javax.swing.GroupLayout(jpnelNumberFour1);
        jpnelNumberFour1.setLayout(jpnelNumberFour1Layout);
        jpnelNumberFour1Layout.setHorizontalGroup(
            jpnelNumberFour1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFour1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFour1Layout.setVerticalGroup(
            jpnelNumberFour1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFour1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberThree1.setBackground(Color.WHITE);

        jlblNumberThree1.setBackground(Color.BLACK);
        jlblNumberThree1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberThree1.setForeground(Color.WHITE);
        jlblNumberThree1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberThree1.setText("03");

        javax.swing.GroupLayout jpnelNumberThree1Layout = new javax.swing.GroupLayout(jpnelNumberThree1);
        jpnelNumberThree1.setLayout(jpnelNumberThree1Layout);
        jpnelNumberThree1Layout.setHorizontalGroup(
            jpnelNumberThree1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThree1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberThree1Layout.setVerticalGroup(
            jpnelNumberThree1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThree1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwo1.setBackground(Color.WHITE);

        jlblNumberTwo1.setBackground(Color.BLACK);
        jlblNumberTwo1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwo1.setForeground(Color.WHITE);
        jlblNumberTwo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwo1.setText("02");

        javax.swing.GroupLayout jpnelNumberTwo1Layout = new javax.swing.GroupLayout(jpnelNumberTwo1);
        jpnelNumberTwo1.setLayout(jpnelNumberTwo1Layout);
        jpnelNumberTwo1Layout.setHorizontalGroup(
            jpnelNumberTwo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwo1Layout.setVerticalGroup(
            jpnelNumberTwo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwo1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberOne1.setBackground(Color.WHITE);

        jlblNumberOne1.setBackground(Color.BLACK);
        jlblNumberOne1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberOne1.setForeground(Color.WHITE);
        jlblNumberOne1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberOne1.setText("01");

        javax.swing.GroupLayout jpnelNumberOne1Layout = new javax.swing.GroupLayout(jpnelNumberOne1);
        jpnelNumberOne1.setLayout(jpnelNumberOne1Layout);
        jpnelNumberOne1Layout.setHorizontalGroup(
            jpnelNumberOne1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberOne1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberOne1Layout.setVerticalGroup(
            jpnelNumberOne1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberOne1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTen1.setBackground(Color.WHITE);

        jlblNumberTen1.setBackground(Color.BLACK);
        jlblNumberTen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTen1.setForeground(Color.WHITE);
        jlblNumberTen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTen1.setText("10");

        javax.swing.GroupLayout jpnelNumberTen1Layout = new javax.swing.GroupLayout(jpnelNumberTen1);
        jpnelNumberTen1.setLayout(jpnelNumberTen1Layout);
        jpnelNumberTen1Layout.setHorizontalGroup(
            jpnelNumberTen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTen1Layout.setVerticalGroup(
            jpnelNumberTen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberNine1.setBackground(Color.WHITE);

        jlblNumberNine1.setBackground(Color.BLACK);
        jlblNumberNine1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberNine1.setForeground(Color.WHITE);
        jlblNumberNine1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberNine1.setText("09");

        javax.swing.GroupLayout jpnelNumberNine1Layout = new javax.swing.GroupLayout(jpnelNumberNine1);
        jpnelNumberNine1.setLayout(jpnelNumberNine1Layout);
        jpnelNumberNine1Layout.setHorizontalGroup(
            jpnelNumberNine1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNine1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberNine1Layout.setVerticalGroup(
            jpnelNumberNine1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNine1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEight1.setBackground(Color.WHITE);

        jlblNumberEight1.setBackground(Color.BLACK);
        jlblNumberEight1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEight1.setForeground(Color.WHITE);
        jlblNumberEight1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEight1.setText("08");

        javax.swing.GroupLayout jpnelNumberEight1Layout = new javax.swing.GroupLayout(jpnelNumberEight1);
        jpnelNumberEight1.setLayout(jpnelNumberEight1Layout);
        jpnelNumberEight1Layout.setHorizontalGroup(
            jpnelNumberEight1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEight1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEight1Layout.setVerticalGroup(
            jpnelNumberEight1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEight1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSeven1.setBackground(Color.WHITE);

        jlblNumberSeven1.setBackground(Color.BLACK);
        jlblNumberSeven1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSeven1.setForeground(Color.WHITE);
        jlblNumberSeven1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSeven1.setText("07");

        javax.swing.GroupLayout jpnelNumberSeven1Layout = new javax.swing.GroupLayout(jpnelNumberSeven1);
        jpnelNumberSeven1.setLayout(jpnelNumberSeven1Layout);
        jpnelNumberSeven1Layout.setHorizontalGroup(
            jpnelNumberSeven1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSeven1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSeven1Layout.setVerticalGroup(
            jpnelNumberSeven1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSeven1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSix1.setBackground(Color.WHITE);

        jlblNumberSix1.setBackground(Color.BLACK);
        jlblNumberSix1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSix1.setForeground(Color.WHITE);
        jlblNumberSix1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSix1.setText("06");

        javax.swing.GroupLayout jpnelNumberSix1Layout = new javax.swing.GroupLayout(jpnelNumberSix1);
        jpnelNumberSix1.setLayout(jpnelNumberSix1Layout);
        jpnelNumberSix1Layout.setHorizontalGroup(
            jpnelNumberSix1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSix1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSix1Layout.setVerticalGroup(
            jpnelNumberSix1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSix1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFithTeen1.setBackground(Color.WHITE);

        jlblNumberFithTeen1.setBackground(Color.BLACK);
        jlblNumberFithTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFithTeen1.setForeground(Color.WHITE);
        jlblNumberFithTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFithTeen1.setText("15");

        javax.swing.GroupLayout jpnelNumberFithTeen1Layout = new javax.swing.GroupLayout(jpnelNumberFithTeen1);
        jpnelNumberFithTeen1.setLayout(jpnelNumberFithTeen1Layout);
        jpnelNumberFithTeen1Layout.setHorizontalGroup(
            jpnelNumberFithTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFithTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFithTeen1Layout.setVerticalGroup(
            jpnelNumberFithTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFithTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFourTeen1.setBackground(Color.WHITE);

        jlblNumberFourTeen1.setBackground(Color.BLACK);
        jlblNumberFourTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFourTeen1.setForeground(Color.WHITE);
        jlblNumberFourTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFourTeen1.setText("14");

        javax.swing.GroupLayout jpnelNumberFourTeen1Layout = new javax.swing.GroupLayout(jpnelNumberFourTeen1);
        jpnelNumberFourTeen1.setLayout(jpnelNumberFourTeen1Layout);
        jpnelNumberFourTeen1Layout.setHorizontalGroup(
            jpnelNumberFourTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFourTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFourTeen1Layout.setVerticalGroup(
            jpnelNumberFourTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFourTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberThirthTeen1.setBackground(Color.WHITE);

        jlblNumberThirthTeen1.setBackground(Color.BLACK);
        jlblNumberThirthTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberThirthTeen1.setForeground(Color.WHITE);
        jlblNumberThirthTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberThirthTeen1.setText("13");

        javax.swing.GroupLayout jpnelNumberThirthTeen1Layout = new javax.swing.GroupLayout(jpnelNumberThirthTeen1);
        jpnelNumberThirthTeen1.setLayout(jpnelNumberThirthTeen1Layout);
        jpnelNumberThirthTeen1Layout.setHorizontalGroup(
            jpnelNumberThirthTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThirthTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberThirthTeen1Layout.setVerticalGroup(
            jpnelNumberThirthTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThirthTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwelth1.setBackground(Color.WHITE);

        jlblNumberTwelth1.setBackground(Color.BLACK);
        jlblNumberTwelth1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwelth1.setForeground(Color.WHITE);
        jlblNumberTwelth1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwelth1.setText("12");

        javax.swing.GroupLayout jpnelNumberTwelth1Layout = new javax.swing.GroupLayout(jpnelNumberTwelth1);
        jpnelNumberTwelth1.setLayout(jpnelNumberTwelth1Layout);
        jpnelNumberTwelth1Layout.setHorizontalGroup(
            jpnelNumberTwelth1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwelth1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwelth1Layout.setVerticalGroup(
            jpnelNumberTwelth1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwelth1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEleven1.setBackground(Color.WHITE);

        jlblNumberEleven1.setBackground(Color.BLACK);
        jlblNumberEleven1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEleven1.setForeground(Color.WHITE);
        jlblNumberEleven1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEleven1.setText("11");

        javax.swing.GroupLayout jpnelNumberEleven1Layout = new javax.swing.GroupLayout(jpnelNumberEleven1);
        jpnelNumberEleven1.setLayout(jpnelNumberEleven1Layout);
        jpnelNumberEleven1Layout.setHorizontalGroup(
            jpnelNumberEleven1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEleven1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEleven1Layout.setVerticalGroup(
            jpnelNumberEleven1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEleven1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwenty1.setBackground(Color.WHITE);

        jlblNumberTwenty1.setBackground(Color.BLACK);
        jlblNumberTwenty1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwenty1.setForeground(Color.WHITE);
        jlblNumberTwenty1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwenty1.setText("20");

        javax.swing.GroupLayout jpnelNumberTwenty1Layout = new javax.swing.GroupLayout(jpnelNumberTwenty1);
        jpnelNumberTwenty1.setLayout(jpnelNumberTwenty1Layout);
        jpnelNumberTwenty1Layout.setHorizontalGroup(
            jpnelNumberTwenty1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwenty1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwenty1Layout.setVerticalGroup(
            jpnelNumberTwenty1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwenty1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberNineTeen1.setBackground(Color.WHITE);

        jlblNumberNineTeen1.setBackground(Color.BLACK);
        jlblNumberNineTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberNineTeen1.setForeground(Color.WHITE);
        jlblNumberNineTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberNineTeen1.setText("19");

        javax.swing.GroupLayout jpnelNumberNineTeen1Layout = new javax.swing.GroupLayout(jpnelNumberNineTeen1);
        jpnelNumberNineTeen1.setLayout(jpnelNumberNineTeen1Layout);
        jpnelNumberNineTeen1Layout.setHorizontalGroup(
            jpnelNumberNineTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNineTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberNineTeen1Layout.setVerticalGroup(
            jpnelNumberNineTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNineTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEightTeen1.setBackground(Color.WHITE);

        jlblNumberEightTeen1.setBackground(Color.BLACK);
        jlblNumberEightTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEightTeen1.setForeground(Color.WHITE);
        jlblNumberEightTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEightTeen1.setText("18");

        javax.swing.GroupLayout jpnelNumberEightTeen1Layout = new javax.swing.GroupLayout(jpnelNumberEightTeen1);
        jpnelNumberEightTeen1.setLayout(jpnelNumberEightTeen1Layout);
        jpnelNumberEightTeen1Layout.setHorizontalGroup(
            jpnelNumberEightTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEightTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEightTeen1Layout.setVerticalGroup(
            jpnelNumberEightTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEightTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSevenTeen1.setBackground(Color.WHITE);

        jlblNumberSevenTeen1.setBackground(Color.BLACK);
        jlblNumberSevenTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSevenTeen1.setForeground(Color.WHITE);
        jlblNumberSevenTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSevenTeen1.setText("17");

        javax.swing.GroupLayout jpnelNumberSevenTeen1Layout = new javax.swing.GroupLayout(jpnelNumberSevenTeen1);
        jpnelNumberSevenTeen1.setLayout(jpnelNumberSevenTeen1Layout);
        jpnelNumberSevenTeen1Layout.setHorizontalGroup(
            jpnelNumberSevenTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSevenTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSevenTeen1Layout.setVerticalGroup(
            jpnelNumberSevenTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSevenTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSixTeen1.setBackground(Color.WHITE);

        jlblNumberSixTeen1.setBackground(Color.BLACK);
        jlblNumberSixTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSixTeen1.setForeground(Color.WHITE);
        jlblNumberSixTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSixTeen1.setText("16");

        javax.swing.GroupLayout jpnelNumberSixTeen1Layout = new javax.swing.GroupLayout(jpnelNumberSixTeen1);
        jpnelNumberSixTeen1.setLayout(jpnelNumberSixTeen1Layout);
        jpnelNumberSixTeen1Layout.setHorizontalGroup(
            jpnelNumberSixTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSixTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSixTeen1Layout.setVerticalGroup(
            jpnelNumberSixTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSixTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyFive1.setBackground(Color.WHITE);

        jlblNumberTwentyFive1.setBackground(Color.BLACK);
        jlblNumberTwentyFive1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyFive1.setForeground(Color.WHITE);
        jlblNumberTwentyFive1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyFive1.setText("25");

        javax.swing.GroupLayout jpnelNumberTwentyFive1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyFive1);
        jpnelNumberTwentyFive1.setLayout(jpnelNumberTwentyFive1Layout);
        jpnelNumberTwentyFive1Layout.setHorizontalGroup(
            jpnelNumberTwentyFive1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFive1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyFive1Layout.setVerticalGroup(
            jpnelNumberTwentyFive1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFive1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyFour1.setBackground(Color.WHITE);

        jlblNumberTwentyFour1.setBackground(Color.BLACK);
        jlblNumberTwentyFour1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyFour1.setForeground(Color.WHITE);
        jlblNumberTwentyFour1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyFour1.setText("24");

        javax.swing.GroupLayout jpnelNumberTwentyFour1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyFour1);
        jpnelNumberTwentyFour1.setLayout(jpnelNumberTwentyFour1Layout);
        jpnelNumberTwentyFour1Layout.setHorizontalGroup(
            jpnelNumberTwentyFour1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFour1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyFour1Layout.setVerticalGroup(
            jpnelNumberTwentyFour1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFour1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyThree1.setBackground(Color.WHITE);

        jlblNumberTwentyThree1.setBackground(Color.BLACK);
        jlblNumberTwentyThree1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyThree1.setForeground(Color.WHITE);
        jlblNumberTwentyThree1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyThree1.setText("23");

        javax.swing.GroupLayout jpnelNumberTwentyThree1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyThree1);
        jpnelNumberTwentyThree1.setLayout(jpnelNumberTwentyThree1Layout);
        jpnelNumberTwentyThree1Layout.setHorizontalGroup(
            jpnelNumberTwentyThree1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyThree1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyThree1Layout.setVerticalGroup(
            jpnelNumberTwentyThree1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyThree1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyTwo1.setBackground(Color.WHITE);

        jlblNumberTwentyTwo1.setBackground(Color.BLACK);
        jlblNumberTwentyTwo1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyTwo1.setForeground(Color.WHITE);
        jlblNumberTwentyTwo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyTwo1.setText("22");

        javax.swing.GroupLayout jpnelNumberTwentyTwo1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyTwo1);
        jpnelNumberTwentyTwo1.setLayout(jpnelNumberTwentyTwo1Layout);
        jpnelNumberTwentyTwo1Layout.setHorizontalGroup(
            jpnelNumberTwentyTwo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyTwo1Layout.setVerticalGroup(
            jpnelNumberTwentyTwo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyTwo1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyOne1.setBackground(Color.WHITE);

        jlblNumberTwentyOne1.setBackground(Color.BLACK);
        jlblNumberTwentyOne1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyOne1.setForeground(Color.WHITE);
        jlblNumberTwentyOne1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyOne1.setText("21");

        javax.swing.GroupLayout jpnelNumberTwentyOne1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyOne1);
        jpnelNumberTwentyOne1.setLayout(jpnelNumberTwentyOne1Layout);
        jpnelNumberTwentyOne1Layout.setHorizontalGroup(
            jpnelNumberTwentyOne1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyOne1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyOne1Layout.setVerticalGroup(
            jpnelNumberTwentyOne1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyOne1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jpnelNumberLayout = new javax.swing.GroupLayout(jpnelNumber);
        jpnelNumber.setLayout(jpnelNumberLayout);
        jpnelNumberLayout.setHorizontalGroup(
            jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelNumberLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberTwentyFive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwentyFour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwentyThree, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwentyTwo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwentyOne, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberTwenty, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberNineTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberEightTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberSevenTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberSixTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberFithTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberFourTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberThirthTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwelth, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberEleven, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberTen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberNine, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberEight, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberSeven, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberSix, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberFive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberFour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberThree, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberOne, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jpnelNumberOne1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberSix1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberEleven1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberSixTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jpnelNumberTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jpnelNumberSeven1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jpnelNumberTwelth1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jpnelNumberSevenTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addComponent(jpnelNumberTwentyOne1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberTwentyTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jpnelNumberThirthTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jpnelNumberThree1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jpnelNumberEight1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jpnelNumberEightTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jpnelNumberTwentyThree1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addComponent(jpnelNumberFour1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberFive1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberNine1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberTen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberNineTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberTwenty1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberFourTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberFithTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberTwentyFour1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberTwentyFive1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(37, 37, 37)
                        .addComponent(jlblNumberView)))
                .addContainerGap(69, Short.MAX_VALUE))
        );
        jpnelNumberLayout.setVerticalGroup(
            jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelNumberLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addComponent(jpnelNumberOne, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberTwo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberThree, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpnelNumberFour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jpnelNumberFive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelNumberLayout.createSequentialGroup()
                        .addComponent(jpnelNumberTwentyOne, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberTwentyTwo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberTwentyThree, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpnelNumberTwentyFour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpnelNumberTwentyFive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jlblNumberView, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelNumberLayout.createSequentialGroup()
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jpnelNumberSeven1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberSix1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberEight1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberNine1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberTen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jpnelNumberEleven1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberTwelth1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12)
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jpnelNumberSevenTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberSixTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jpnelNumberTwentyTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jpnelNumberFourTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberFithTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12)
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                                        .addComponent(jpnelNumberTwenty1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jpnelNumberTwentyFive1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jpnelNumberLayout.createSequentialGroup()
                                            .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jpnelNumberNineTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jpnelNumberEightTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(12, 12, 12)
                                            .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jpnelNumberTwentyThree1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jpnelNumberTwentyFour1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addComponent(jpnelNumberTwentyOne1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberEleven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberTwelth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberThirthTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberFourTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberFithTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberSix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberSeven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberEight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberNine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberSixTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberSevenTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberEightTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberNineTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberTwenty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jpnelNumberOne1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jpnelNumberThree1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberFour1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberFive1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(42, 42, 42)
                                .addComponent(jpnelNumberThirthTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jpnelNumberTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jpnelSorted.setBackground(Color.BLUE);

        jlblSorted.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblSorted.setForeground(Color.WHITE);
        jlblSorted.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSorted.setText("00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00");
        jlblSorted.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jlblSortedPropertyChange(evt);
            }
        });

        jlblSortedTotal.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSortedTotal.setForeground(Color.WHITE);
        jlblSortedTotal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSortedTotal.setText("00");
        jlblSortedTotal.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jlblSortedTotalPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jpnelSortedLayout = new javax.swing.GroupLayout(jpnelSorted);
        jpnelSorted.setLayout(jpnelSortedLayout);
        jpnelSortedLayout.setHorizontalGroup(
            jpnelSortedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSortedLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblSortedTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jpnelSortedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelSortedLayout.createSequentialGroup()
                    .addGap(0, 98, Short.MAX_VALUE)
                    .addComponent(jlblSorted, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jpnelSortedLayout.setVerticalGroup(
            jpnelSortedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSortedLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblSortedTotal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jpnelSortedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jpnelSortedLayout.createSequentialGroup()
                    .addGap(1, 1, 1)
                    .addComponent(jlblSorted, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(1, 1, 1)))
        );

        jlblPrice15.setText("15        R$ 2,00");

        jlblPrice16.setText("16        R$ 32,00");

        jlblPrice18.setText("18        R$ 1632,00");

        jlblPrice17.setText("17        R$ 272,00");

        jmnuCard.setText("Cartao");

        JmnuItemCardNew.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        JmnuItemCardNew.setText("Novo");
        JmnuItemCardNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemCardNewActionPerformed(evt);
            }
        });
        jmnuCard.add(JmnuItemCardNew);

        JmnuItemCardSave.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        JmnuItemCardSave.setText("Salvar");
        JmnuItemCardSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemCardSaveActionPerformed(evt);
            }
        });
        jmnuCard.add(JmnuItemCardSave);

        JmnuItemCardDelete.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        JmnuItemCardDelete.setText("Excluir");
        JmnuItemCardDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemCardDeleteActionPerformed(evt);
            }
        });
        jmnuCard.add(JmnuItemCardDelete);

        JmnuItemCardUndo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        JmnuItemCardUndo.setText("Desfazer");
        JmnuItemCardUndo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemCardUndoActionPerformed(evt);
            }
        });
        jmnuCard.add(JmnuItemCardUndo);

        JmnuBarGame.add(jmnuCard);

        jmnuNavegate.setText("Navegar");

        JmnuItemNavegateGoFirst.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        JmnuItemNavegateGoFirst.setText("Ir Primeiro");
        JmnuItemNavegateGoFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoFirstActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoFirst);

        JmnuItemNavegateGoNext.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        JmnuItemNavegateGoNext.setText("Ir Proximo");
        JmnuItemNavegateGoNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoNextActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoNext);

        JmnuItemNavegateGoPrevious.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F6, 0));
        JmnuItemNavegateGoPrevious.setText("Ir Anterior");
        JmnuItemNavegateGoPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoPreviousActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoPrevious);

        JmnuItemNavegateGoLast.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F7, 0));
        JmnuItemNavegateGoLast.setText("Ir Ultimo");
        JmnuItemNavegateGoLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoLastActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoLast);

        JmnuItemNavegateGoTo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F8, 0));
        JmnuItemNavegateGoTo.setText("Ir Para");
        JmnuItemNavegateGoTo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoToActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoTo);

        JmnuBarGame.add(jmnuNavegate);

        JmnuItemPanel.setText("Painel");

        JmnuItemPanelPincelRed.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        JmnuItemPanelPincelRed.setText("Pincel vermelho");
        JmnuItemPanelPincelRed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelPincelRedActionPerformed(evt);
            }
        });
        JmnuItemPanel.add(JmnuItemPanelPincelRed);

        JmnuItemPanelPincelBlue.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        JmnuItemPanelPincelBlue.setText("Pincel azul");
        JmnuItemPanelPincelBlue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelPincelBlueActionPerformed(evt);
            }
        });
        JmnuItemPanel.add(JmnuItemPanelPincelBlue);

        JmnuItemPanelRedAll.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        JmnuItemPanelRedAll.setText("Vermelhar tudo");
        JmnuItemPanelRedAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelRedAllActionPerformed(evt);
            }
        });
        JmnuItemPanel.add(JmnuItemPanelRedAll);

        JmnuItemPanelNumbers.setText("Numeros");

        JmnuItemPanelNumbersOne.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_1, 0));
        JmnuItemPanelNumbersOne.setText("1");
        JmnuItemPanelNumbersOne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersOneActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersOne);

        JmnuItemPanelNumbersTwo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_2, 0));
        JmnuItemPanelNumbersTwo.setText("2");
        JmnuItemPanelNumbersTwo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersTwoActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersTwo);

        JmnuItemPanelNumbersThree.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_3, 0));
        JmnuItemPanelNumbersThree.setText("3");
        JmnuItemPanelNumbersThree.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersThreeActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersThree);

        JmnuItemPanelNumbersFour.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_4, 0));
        JmnuItemPanelNumbersFour.setText("4");
        JmnuItemPanelNumbersFour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersFourActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersFour);

        JmnuItemPanelNumbersFive.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_5, 0));
        JmnuItemPanelNumbersFive.setText("5");
        JmnuItemPanelNumbersFive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersFiveActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersFive);

        JmnuItemPanelNumbersSix.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_6, 0));
        JmnuItemPanelNumbersSix.setText("6");
        JmnuItemPanelNumbersSix.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersSixActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersSix);

        JmnuItemPanelNumbersSeven.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_7, 0));
        JmnuItemPanelNumbersSeven.setText("7");
        JmnuItemPanelNumbersSeven.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersSevenActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersSeven);

        JmnuItemPanelNumbersEight.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_8, 0));
        JmnuItemPanelNumbersEight.setText("8");
        JmnuItemPanelNumbersEight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersEightActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersEight);

        JmnuItemPanelNumbersNine.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_9, 0));
        JmnuItemPanelNumbersNine.setText("9");
        JmnuItemPanelNumbersNine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersNineActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersNine);

        JmnuItemPanelNumbersZero.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_0, 0));
        JmnuItemPanelNumbersZero.setText("0");
        JmnuItemPanelNumbersZero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelNumbersZeroActionPerformed(evt);
            }
        });
        JmnuItemPanelNumbers.add(JmnuItemPanelNumbersZero);

        JmnuItemPanel.add(JmnuItemPanelNumbers);

        JmnuItemPanelPaintNumber.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ENTER, 0));
        JmnuItemPanelPaintNumber.setText("Pintar numero");
        JmnuItemPanelPaintNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelPaintNumberActionPerformed(evt);
            }
        });
        JmnuItemPanel.add(JmnuItemPanelPaintNumber);

        JmnuItemPanelBackspace.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_BACK_SPACE, 0));
        JmnuItemPanelBackspace.setText("Backspace");
        JmnuItemPanelBackspace.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelBackspaceActionPerformed(evt);
            }
        });
        JmnuItemPanel.add(JmnuItemPanelBackspace);

        JmnuItemPanelEscape.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_ESCAPE, 0));
        JmnuItemPanelEscape.setText("Escape");
        JmnuItemPanelEscape.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelEscapeActionPerformed(evt);
            }
        });
        JmnuItemPanel.add(JmnuItemPanelEscape);

        JmnuItemPanelCheckMultiplicity.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F9, 0));
        JmnuItemPanelCheckMultiplicity.setText("Verificar multiplicidade");
        JmnuItemPanelCheckMultiplicity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemPanelCheckMultiplicityActionPerformed(evt);
            }
        });
        JmnuItemPanel.add(JmnuItemPanelCheckMultiplicity);

        JmnuBarGame.add(JmnuItemPanel);

        setJMenuBar(JmnuBarGame);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelView, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jpnelNumber, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jpnelSorted, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jpnelSymbolism, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblPrice15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblPrice16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblPrice17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblPrice18))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jpnelView, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jpnelNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelSorted, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jpnelSymbolism, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblPrice15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblPrice16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblPrice17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblPrice18)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void keyboardPanelNumber(int number){
        String jlblNumberViewStr = jlblNumberView.getText();
        if(jlblNumberViewStr.length()==1){
            if(jlblNumberViewStr.equalsIgnoreCase("2")){
                switch(number){
                    case 0:
                    case 1:    
                    case 2:
                    case 3:
                    case 4:    
                    case 5:
                        jlblNumberViewStr+=String.valueOf(number);
                        jlblNumberView.setText(jlblNumberViewStr);        
                    break;
                }
            }else if(jlblNumberViewStr.equalsIgnoreCase("0")
                    ||jlblNumberViewStr.equalsIgnoreCase("1")){
                        jlblNumberViewStr+=String.valueOf(number);
                        jlblNumberView.setText(jlblNumberViewStr);        
            }
        }else if(jlblNumberViewStr.length()==2){           
            if(String.valueOf(number).equalsIgnoreCase("0")
                    ||String.valueOf(number).equalsIgnoreCase("1")
                    || String.valueOf(number).equalsIgnoreCase("2"))
                jlblNumberView.setText(String.valueOf(number));
            
        }
    }
    private void keyboardPanelEnter()throws Exception{
        String jlblNumberViewStr = jlblNumberView.getText();
        String jlblSortedStr = jlblSorted.getText();
        if(getSignal()==enmSignal.add)
        if(getCountOfNumberOnJlblSorted()>=18)return;
        
        switch(Integer.valueOf(jlblNumberViewStr))
        {
            case 1:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberOne1.setBackground(Color.red);
                    jpnelNumberOne.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberOne.setBackground(Color.blue);
                    jpnelNumberOne1.setBackground(Color.blue);                     
                    }
                }
            break;    
            case 2:
                
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberTwo1.setBackground(Color.red);
                    jpnelNumberTwo.setBackground(Color.red);
                    }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberTwo1.setBackground(Color.blue);
                    jpnelNumberTwo.setBackground(Color.blue);                
                    }
                }
            break;
            case 3:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberThree.setBackground(Color.red);
                    jpnelNumberThree1.setBackground(Color.red);      
                    }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberThree.setBackground(Color.blue);
                    jpnelNumberThree1.setBackground(Color.blue);
                }
                }
            break;
            case 4:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberFour.setBackground(Color.red);
                    jpnelNumberFour1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberFour.setBackground(Color.blue);
                    jpnelNumberFour1.setBackground(Color.blue);
                }
                }
            break;
            case 5:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberFive.setBackground(Color.red);
                    jpnelNumberFive1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberFive.setBackground(Color.blue);
                    jpnelNumberFive1.setBackground(Color.blue);
                }
                }
            break;    
            case 6:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberSix.setBackground(Color.red);
                    jpnelNumberSix1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberSix.setBackground(Color.blue);
                    jpnelNumberSix1.setBackground(Color.blue);
                }
                }
            break;
            case 7:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberSeven.setBackground(Color.red);
                    jpnelNumberSeven1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberSeven.setBackground(Color.blue);
                    jpnelNumberSeven1.setBackground(Color.blue);          
                }
                }
            break;
            case 8:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberEight.setBackground(Color.red);
                    jpnelNumberEight1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberEight.setBackground(Color.blue);
                    jpnelNumberEight1.setBackground(Color.blue);
                }
                }
            break;    
            case 9:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberNine.setBackground(Color.red);
                    jpnelNumberNine1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberNine.setBackground(Color.blue);
                    jpnelNumberNine1.setBackground(Color.blue);
                }
                }
            break;    
            case 10:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberTen.setBackground(Color.red);
                    jpnelNumberTen1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberTen.setBackground(Color.blue);
                    jpnelNumberTen1.setBackground(Color.blue);
                }
                }
            break;    
            case 11:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberEleven.setBackground(Color.red);
                    jpnelNumberEleven1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberEleven.setBackground(Color.blue);
                    jpnelNumberEleven1.setBackground(Color.blue);
                }
                }
            break;    
            case 12:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberTwelth.setBackground(Color.red);
                    jpnelNumberTwelth1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberTwelth.setBackground(Color.blue);
                    jpnelNumberTwelth1.setBackground(Color.blue);
                }
                }
            break;    
            case 13:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberThirthTeen.setBackground(Color.red);
                    jpnelNumberThirthTeen1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberThirthTeen.setBackground(Color.blue);
                    jpnelNumberThirthTeen1.setBackground(Color.blue);
                }
                }
            break;    
            case 14:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberFourTeen.setBackground(Color.red);
                    jpnelNumberFourTeen1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberFourTeen.setBackground(Color.blue);
                    jpnelNumberFourTeen1.setBackground(Color.blue);
                }
                }
            break;    
            case 15:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberFithTeen.setBackground(Color.red);
                        jpnelNumberFithTeen1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberFithTeen.setBackground(Color.blue);
                      jpnelNumberFithTeen1.setBackground(Color.blue);  
                }
                }
            break;    
            case 16:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberSixTeen.setBackground(Color.red);
                        jpnelNumberSixTeen1.setBackground(Color.red);
                }        
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){        
                      jpnelNumberSixTeen.setBackground(Color.blue);
                      jpnelNumberSixTeen1.setBackground(Color.blue);  
                }
                }
            break;    
            case 17:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberSevenTeen.setBackground(Color.red);
                        jpnelNumberSevenTeen1.setBackground(Color.red);
                    }        
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberSevenTeen.setBackground(Color.blue);
                      jpnelNumberSevenTeen1.setBackground(Color.blue);  
                }
                }
            break;    
            case 18:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberEightTeen.setBackground(Color.red);
                        jpnelNumberEightTeen1.setBackground(Color.red);
                    }  
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberEightTeen.setBackground(Color.blue);
                      jpnelNumberEightTeen1.setBackground(Color.blue);  
                }
                }
            break;    
            case 19:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberNineTeen.setBackground(Color.red);
                        jpnelNumberNineTeen1.setBackground(Color.red);
                    } 
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                        jpnelNumberNineTeen.setBackground(Color.blue);
                        jpnelNumberNineTeen1.setBackground(Color.blue);
                }
                }
            break;    
            case 20:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwenty.setBackground(Color.red);
                        jpnelNumberTwenty1.setBackground(Color.red);
                    }  
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwenty.setBackground(Color.blue);
                      jpnelNumberTwenty1.setBackground(Color.blue);
                }
                }
            break;    
            case 21:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyOne.setBackground(Color.red);
                        jpnelNumberTwentyOne1.setBackground(Color.red);
                    } 
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){   
                      jpnelNumberTwentyOne.setBackground(Color.blue);
                      jpnelNumberTwentyOne1.setBackground(Color.blue);    
                }
                }
            break;    
            case 22:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyTwo.setBackground(Color.red);
                        jpnelNumberTwentyTwo1.setBackground(Color.red);                    
                    } 
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwentyTwo.setBackground(Color.blue);
                      jpnelNumberTwentyTwo1.setBackground(Color.blue);
                }
                }
            break;    
            case 23:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyThree.setBackground(Color.red);
                        jpnelNumberTwentyThree1.setBackground(Color.red);
                    } 
                        
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwentyThree.setBackground(Color.blue);
                      jpnelNumberTwentyThree1.setBackground(Color.blue);  
                      
                }
                }
            break;    
            case 24:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyFour.setBackground(Color.red);
                        jpnelNumberTwentyFour1.setBackground(Color.red);
                    }  
                        
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwentyFour.setBackground(Color.blue);
                      jpnelNumberTwentyFour1.setBackground(Color.blue);
                      
                }
                }
            break;    
            case 25:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyFive.setBackground(Color.red);
                        jpnelNumberTwentyFive1.setBackground(Color.red);
                    } 
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwentyFive.setBackground(Color.blue);
                      jpnelNumberTwentyFive1.setBackground(Color.blue);   
                }                
                }
            break;    
        }
        
    }
    
    private boolean deleteNumberOnJlblSorted(String number)throws Exception{
        String selStr = "";
        Integer selInt = 0;
        String numberingDel = "";
        Integer numberInt = Integer.valueOf(number);
        if(!existNumberOnJlblSorted(number)){
           return false;
        }
        
        if(number.length()!=2)return false;
        
        for(int i=0;i<18;i++)
        {
            selStr = getSortedNumberFromIndex(i);
            selInt = Integer.valueOf(selStr);
            if(numberInt==selInt)
            {
                for(int j=0;j<i;j++)
                {
                    numberingDel+=getSortedNumberFromIndex(j)+" ";
                }
                ++i;
                for(int j=i;j<18;j++)
                {
                    numberingDel+=getSortedNumberFromIndex(j)+" ";
                }
                 jlblSorted.setText(numberingDel+"00");
                 return true;
            }
        }
       
        return true;
    }
    
    private boolean insertNumberOnJlblSorted(String number){
        try
        {
        if(!existNumberOnJlblSorted(number)){
            if(getCountOfNumberOnJlblSorted()<18){
                if(number.length()==2){
                   String newNumberOrdering = getNumberOrdering(number);
                   jlblSorted.setText(newNumberOrdering);                
                   return true;
                }
            }
        }
        }catch(Exception e)
        {
        JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        return false;
    }
    
    private String getNumberOrdering(String number)throws Exception{
        String ret="";
        
        if(existNumberOnJlblSorted(number)){
            return jlblSorted.getText();
        }
        
        if(getCountOfNumberOnJlblSorted()>=18){
            return jlblSorted.getText();
        }   
        final Integer numberInt = Integer.valueOf(number);
        String  selStr = "";
        Integer selInt = 0;
        
        for(int i=0;i<18;i++){
            selStr = getSortedNumberFromIndex(i);
            selInt = Integer.valueOf(selStr);
            if(selInt==0)
            {
                if(i==0)
                {
                    ret=number;
                    for(int j=(++i);j<18;j++){
                        ret+=" "+getSortedNumberFromIndex(j);
                    }
                    return ret;
                }else //i==0
                {
                    for(int j=0;j<i;j++){
                        ret+=getSortedNumberFromIndex(j)+" ";
                    }
                    ret+=number+" ";
                    for(int j=(++i);j<18;j++){
                        ret+=getSortedNumberFromIndex(j)+" ";
                    }
                    return ret;
                }
            }else if(selInt>numberInt)//if selInt
            {
                    for(int j=0;j<i;j++){
                        ret+=getSortedNumberFromIndex(j)+" ";
                    }
                    ret+=number+" ";
                    for(int j=i;j<17;j++){
                        ret+=getSortedNumberFromIndex(j)+" ";
                    }
                    return ret;
            }
        }
        return ret;
    }
    
    private String getSortedNumberFromIndex(int index)throws Exception{
        if(index<0 || index>17){
        throw new Exception(MSGSORTEDNUMBERINDEXOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }   
        String ret="";
        String jlblSortedStr = "";
        for(int i=0;i<jlblSorted.getText().length();i++){
            if(jlblSorted.getText().charAt(i)!=' ')
            jlblSortedStr+=jlblSorted.getText().charAt(i);    
        }
        index*=2;
        ret = jlblSortedStr.substring(index,index+2);
        return ret;
    }
    
    private int getCountOfNumberOnJlblSorted()throws Exception{
        int ret=0;
        for(int i=0;i<18;i++){
            Integer intg=Integer.valueOf(getSortedNumberFromIndex(i));
            if(intg>0)ret++;
        }
        return ret;
    }
    
    private boolean existNumberOnJlblSorted(String number){
        String jlblSortedStr = jlblSorted.getText();
        for(int i=0;i<jlblSortedStr.length();i+=3){
            String strSel = new String(String.valueOf(jlblSortedStr.charAt(i))+String.valueOf(jlblSortedStr.charAt(i+1)));
            if(strSel.equalsIgnoreCase(number)){
                if(number.length()==2)
                    return true;
            }
        }
        return false;
    }
    

    private void jlblViewSignalSymbolMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblViewSignalSymbolMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jlblViewSignalSymbolMouseClicked

    private void jlblViewPincelBlueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblViewPincelBlueMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jlblViewPincelBlueMouseClicked

    private void jpnelViewPincelBlueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpnelViewPincelBlueMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jpnelViewPincelBlueMouseClicked

    private void jlblViewPincelRedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblViewPincelRedMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jlblViewPincelRedMouseClicked

    private void jpnelViewPincelRedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpnelViewPincelRedMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jpnelViewPincelRedMouseClicked

    private void jlblSortedTotalPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jlblSortedTotalPropertyChange
        Integer jlblSortedTotalInt = Integer.valueOf(jlblSortedTotal.getText());
        if(jlblSortedTotalInt==15)
            jlblViewPrice.setText("R$ 2,00");
        else if(jlblSortedTotalInt==16)
            jlblViewPrice.setText("R$ 32,00");
        else if(jlblSortedTotalInt==17)
            jlblViewPrice.setText("R$ 272,00");
        else if(jlblSortedTotalInt==18)
            jlblViewPrice.setText("R$ 1632,00");
        else 
            jlblViewPrice.setText("R$ 00,00");
    }//GEN-LAST:event_jlblSortedTotalPropertyChange

    private void JmnuItemCardNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemCardNewActionPerformed
        
        if(registeredGameIndex==-1)
        if(!jlblSorted.getText().equalsIgnoreCase(ZERONUMBERVIEW)){
            int q=-1;
            q=JOptionPane.showInternalConfirmDialog(this,
            new String("Cartao nao registrado, deseja registra-lo?"),"",
            JOptionPane.YES_NO_OPTION);
            
            if(q==2) return;
            else if(q==1){
               resetAllNumberPanel();
               jlblSorted.setText(ZERONUMBERVIEW);
               jlblNumberView.setText("00");
           }else if(q==0){
           try
           {
               gameList.add(new Game(jlblSorted.getText()));                        
               resetAllNumberPanel();
               jlblSorted.setText(ZERONUMBERVIEW);
               jlblNumberView.setText("00");
               setTitle(" 0:"+String.valueOf(gameList.size())+title);
            if(jbtnMoveFrmToFront!=null)
               jbtnMoveFrmToFront.setText(getTitle());    
            }catch(Exception e){
               JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+
                       e.getMessage()
               +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
            }
            }
            return;
        }
        int q=-1;
            q=JOptionPane.showInternalConfirmDialog(this,
            new String("Deseja continuar a criar novo jogo?"),
            "",JOptionPane.YES_NO_OPTION);
            if(q==0){
               resetAllNumberPanel();
               jlblSorted.setText(ZERONUMBERVIEW);
               jlblNumberView.setText("00");
               registeredGameIndex=-1;
            }
                
        
    }//GEN-LAST:event_JmnuItemCardNewActionPerformed

    private void JmnuItemCardSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemCardSaveActionPerformed
        if(!jlblSorted.getText().equalsIgnoreCase(ZERONUMBERVIEW))
        if(registeredGameIndex==-1){
            int q=-1;
            q=JOptionPane.showInternalConfirmDialog(this,
            new String("Cartao ainda nao registrado, deseja registra-lo?"),
                      "",JOptionPane.YES_NO_OPTION);
            
            if(q==1) return;
            else if(q==0){
                  try
                  {
                     gameList.add(new Game(jlblSorted.getText()));
                     registeredGameIndex=(gameList.size()-1);
                     setTitle(String.valueOf(registeredGameIndex)+
                             ":"+String.valueOf(gameList.size())+" "+title);
                     if(jbtnMoveFrmToFront!=null)
                     jbtnMoveFrmToFront.setText(getTitle());    
                  }catch(Exception e){
                   JOptionPane.showInternalMessageDialog(
                           this,"JIFrmGame.java\n"+
                           e.getMessage()
                   +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                  }
            }
            return;
        }
        
        int q=-1;
        q=JOptionPane.showInternalConfirmDialog(this,
        new String("Deseja continuar a salvar cartao? Sera sobrescrito sem poder recuperar-lo."),
        "",JOptionPane.YES_NO_OPTION);
        
        if(q==1)return;
        try
        {
            Game game = new Game(jlblSorted.getText());
            gameList.get(registeredGameIndex).setSortedNumber(game.getSortedNumber());
            setTitle(String.valueOf(registeredGameIndex)+
                             ":"+String.valueOf(gameList.size())+" "+title);
            if(jbtnMoveFrmToFront!=null)
            jbtnMoveFrmToFront.setText(getTitle());    
        }catch(Exception e){
                   JOptionPane.showInternalMessageDialog(this,
                           "JIFrmGame.java\n"+e.getMessage()
                   +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        
    }//GEN-LAST:event_JmnuItemCardSaveActionPerformed

    private void JmnuItemCardUndoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemCardUndoActionPerformed
        try
        {
            if(registeredGameIndex>-1){
                resetAllNumberPanel();
                Game game = gameList.get(registeredGameIndex);
                for(int i=0;i<18;i++){
                    Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                    insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                    markNumberPanel(intg);                    
                }
            }
            
        }catch(Exception e){
                   JOptionPane.showInternalMessageDialog(this,
                           "JIFrmGame.java\n"+e.getMessage()
                   +"\n"+"linha:"+
                   String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
    }//GEN-LAST:event_JmnuItemCardUndoActionPerformed

    private void JmnuItemCardDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemCardDeleteActionPerformed
        if(registeredGameIndex>-1){
            int q=-1;
            q=JOptionPane.showInternalConfirmDialog(this,
            new String("Deseja continuar a excluir cartao? Sem poder recuperar-lo."
            +"\n"+gameList.get(registeredGameIndex).getSortedNumber()),"",JOptionPane.YES_NO_OPTION);
            if(q==1)return;
            gameList.remove(registeredGameIndex);
            registeredGameIndex=-1;
            resetAllNumberPanel();
            setTitle(" 0"+":"+String.valueOf(gameList.size())+" "+title);
            if(jbtnMoveFrmToFront!=null)
            jbtnMoveFrmToFront.setText(getTitle());    
        }
        
    }//GEN-LAST:event_JmnuItemCardDeleteActionPerformed

    private void jlblSortedPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jlblSortedPropertyChange
    this.grabFocus();
    try
    {
    Integer sortedTotal = Integer.valueOf(jlblSortedTotal.getText());
    if(getCountOfNumberOnJlblSorted()==0 && sortedTotal>0){
        if(jlblViewSignalSymbol.getForeground()==Color.red){
            if(sortedTotal>0)sortedTotal--;
        }
    }else if(getCountOfNumberOnJlblSorted()>0)
    if(jlblViewSignalSymbol.getForeground()==Color.red){
        if(sortedTotal>0)sortedTotal--;
    }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
        if(sortedTotal<18)sortedTotal++;        
    }
    String sortedTotalStr= String.valueOf(sortedTotal);
    if(sortedTotal<=9){
        sortedTotalStr = "0"+String.valueOf(sortedTotal);                  
    }
       jlblSortedTotal.setText(sortedTotalStr);
    }catch(Exception e){
        JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
    }
    }//GEN-LAST:event_jlblSortedPropertyChange

    
    private void JmnuItemNavegateGoFirstActionPerformedPublic(){
        try
        {
           if(gameList.size()<=0)return;
           if(getCountOfNumberOnJlblSorted()>=15 && getCountOfNumberOnJlblSorted()<=18)
           if(registeredGameIndex==-1){
           int q=-1;
            q=JOptionPane.showInternalConfirmDialog(this,
            new String("Deseja prosseguir? O cartao nao podera ser recuperado."),
            "",JOptionPane.YES_NO_OPTION);
            if(q==1)return;
           }
           registeredGameIndex=0;
           resetAllNumberPanel();
           Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
                setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
                if(jbtnMoveFrmToFront!=null)
                jbtnMoveFrmToFront.setText(getTitle());    
           }
        }catch(Exception e){
           JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
                   +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
    }
    
    private void JmnuItemNavegateGoFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoFirstActionPerformed
        JmnuItemNavegateGoFirstActionPerformedPublic();
        
    }//GEN-LAST:event_JmnuItemNavegateGoFirstActionPerformed
    private void JmnuItemNavegateGoNextActionPerformedPublic(){
        try
        {
        if(registeredGameIndex<=-1)return;
        if((registeredGameIndex+1)>=gameList.size())return;
        registeredGameIndex++;
           resetAllNumberPanel();
           Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
                setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
                if(jbtnMoveFrmToFront!=null)
                jbtnMoveFrmToFront.setText(getTitle());    
           }
        }catch(Exception e){
           JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
                   +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
    }
    private void JmnuItemNavegateGoNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoNextActionPerformed
        JmnuItemNavegateGoNextActionPerformedPublic();
    }//GEN-LAST:event_JmnuItemNavegateGoNextActionPerformed
    private void JmnuItemNavegateGoPreviousActionPerformedPublic(){
        try
        {
        if(registeredGameIndex<=-1)return;
        if((registeredGameIndex-1)<0)return;
        registeredGameIndex--;
           resetAllNumberPanel();
           Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
                setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
                if(jbtnMoveFrmToFront!=null)
                jbtnMoveFrmToFront.setText(getTitle());    
           }
        }catch(Exception e){
           JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
           +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
    }
    private void JmnuItemNavegateGoPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoPreviousActionPerformed
        JmnuItemNavegateGoPreviousActionPerformedPublic();
    }//GEN-LAST:event_JmnuItemNavegateGoPreviousActionPerformed
   private void JmnuItemNavegateGoLastActionPerformedPublic(){
       try
        {
           if(gameList.size()<=0)return;
           if(getCountOfNumberOnJlblSorted()>=15 && getCountOfNumberOnJlblSorted()<=18)
           if(registeredGameIndex==-1){
           int q=-1;
            q=JOptionPane.showInternalConfirmDialog(this,
            new String("Deseja prosseguir? O cartao nao podera ser recuperado."),
            "",JOptionPane.YES_NO_OPTION);
            if(q==1)return;
           }
           registeredGameIndex=(gameList.size()-1);
           resetAllNumberPanel();
           Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
                setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
                if(jbtnMoveFrmToFront!=null)
                jbtnMoveFrmToFront.setText(getTitle());    
           }
        }catch(Exception e){
           JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
           +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
   }
    private void JmnuItemNavegateGoLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoLastActionPerformed
        JmnuItemNavegateGoLastActionPerformedPublic();

    }//GEN-LAST:event_JmnuItemNavegateGoLastActionPerformed
   private void JmnuItemNavegateGoToActionPerformedPublic(){
        try
        {
          JmnuItemNavegateGoToActionPerformedException();
        }catch(Exception e){
                 JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
                 +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
   }
    private void JmnuItemNavegateGoToActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoToActionPerformed
       JmnuItemNavegateGoToActionPerformedPublic();
    }//GEN-LAST:event_JmnuItemNavegateGoToActionPerformed

    private void JmnuItemPanelPincelRedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelPincelRedActionPerformed
        jlblViewPincelRed.setForeground(Color.WHITE);
        jlblViewPincelBlue.setForeground(Color.BLACK);
        setSignal(enmSignal.del);
        jlblViewSignalSymbol.setForeground(Color.red);
    }//GEN-LAST:event_JmnuItemPanelPincelRedActionPerformed

    private void JmnuItemPanelPincelBlueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelPincelBlueActionPerformed
        jlblViewPincelRed.setForeground(Color.BLACK);
        jlblViewPincelBlue.setForeground(Color.WHITE);
        setSignal(enmSignal.add);
        jlblViewSignalSymbol.setForeground(Color.blue);
    }//GEN-LAST:event_JmnuItemPanelPincelBlueActionPerformed

    private void JmnuItemPanelRedAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelRedAllActionPerformed
        resetAllNumberPanel();
    }//GEN-LAST:event_JmnuItemPanelRedAllActionPerformed

    private void JmnuItemPanelBackspaceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelBackspaceActionPerformed
        String jlblNumberViewStr=jlblNumberView.getText();
        if(jlblNumberViewStr.length()==2){
                     jlblNumberView.setText(String.valueOf(jlblNumberViewStr.charAt(0)));
        }

    }//GEN-LAST:event_JmnuItemPanelBackspaceActionPerformed

    private void JmnuItemPanelPaintNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelPaintNumberActionPerformed
        try
        {
          keyboardPanelEnter();
        }catch(Exception e){
            JOptionPane.showInternalMessageDialog(this,"JIFrmGame.java\n"+e.getMessage()
            +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
    }//GEN-LAST:event_JmnuItemPanelPaintNumberActionPerformed

    private void JmnuItemPanelNumbersOneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersOneActionPerformed
        keyboardPanelNumber(1);
    }//GEN-LAST:event_JmnuItemPanelNumbersOneActionPerformed

    private void JmnuItemPanelNumbersTwoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersTwoActionPerformed
        keyboardPanelNumber(2);
    }//GEN-LAST:event_JmnuItemPanelNumbersTwoActionPerformed

    private void JmnuItemPanelNumbersThreeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersThreeActionPerformed
        keyboardPanelNumber(3);
    }//GEN-LAST:event_JmnuItemPanelNumbersThreeActionPerformed

    private void JmnuItemPanelNumbersFourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersFourActionPerformed
        keyboardPanelNumber(4);
    }//GEN-LAST:event_JmnuItemPanelNumbersFourActionPerformed

    private void JmnuItemPanelNumbersFiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersFiveActionPerformed
        keyboardPanelNumber(5);
    }//GEN-LAST:event_JmnuItemPanelNumbersFiveActionPerformed

    private void JmnuItemPanelNumbersSixActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersSixActionPerformed
        keyboardPanelNumber(6);
    }//GEN-LAST:event_JmnuItemPanelNumbersSixActionPerformed

    private void JmnuItemPanelNumbersSevenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersSevenActionPerformed
        keyboardPanelNumber(7);
    }//GEN-LAST:event_JmnuItemPanelNumbersSevenActionPerformed

    private void JmnuItemPanelNumbersEightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersEightActionPerformed
        keyboardPanelNumber(8);
    }//GEN-LAST:event_JmnuItemPanelNumbersEightActionPerformed

    private void JmnuItemPanelNumbersNineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersNineActionPerformed
        keyboardPanelNumber(9);
    }//GEN-LAST:event_JmnuItemPanelNumbersNineActionPerformed

    private void JmnuItemPanelNumbersZeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelNumbersZeroActionPerformed
        keyboardPanelNumber(0);
    }//GEN-LAST:event_JmnuItemPanelNumbersZeroActionPerformed

    private void JmnuItemPanelEscapeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelEscapeActionPerformed
        if(!jdlgWait.isVisible())return;
        jdlgWait.dispose();
    }//GEN-LAST:event_JmnuItemPanelEscapeActionPerformed

    private void JmnuItemPanelCheckMultiplicityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemPanelCheckMultiplicityActionPerformed
       
        
        thrDlgWaitOne = new Thread(
                new Runnable() {
                public void run() {
                   JIFrmGame.this.jdlgWait = new JDlgWait(true);
                   JIFrmGame.this.jdlgWait.setVisible(true);
                   
                   ArrayList<Integer> mList = new ArrayList();
                    try
                    {
                       while(JIFrmGame.this.jdlgWait==null);
                       while(!JIFrmGame.this.jdlgWait.isVisible());
                       mList=checkMultiplicity();
                    }catch(Exception e){
                        if(JIFrmGame.this.jdlgWait.isVisible())
                        JIFrmGame.this.jdlgWait.dispose();
                        while(JIFrmGame.this.jdlgWait.isVisible());
                        JOptionPane.showInternalMessageDialog(JIFrmGame.this,"JIFrmGame.java\n"+e.getMessage()
                        +"\n"+"linha:"+
                        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    }finally{
                        if(JIFrmGame.this.jdlgWait.isVisible())
                        JIFrmGame.this.jdlgWait.dispose();
                        while(JIFrmGame.this.jdlgWait.isVisible());
                        if(mList.size()<=0)return;
                        int q=JOptionPane.showInternalConfirmDialog(JIFrmGame.this,
                        "Existe cartao repetido,multiplicado..."
                        +"\n"+"Total de cartao duplicado:"+String.valueOf(mList.size())
                        +"\nDeseja excluir a multiplicidade no jogo?","",
                        JOptionPane.YES_NO_OPTION);
                        if(q>0)return;
                        if(!JIFrmGame.this.jdlgWait.isVisible())
                        JIFrmGame.this.jdlgWait.setVisible(true);
                        while(!JIFrmGame.this.jdlgWait.isVisible());
                        
                        for(int i=0;i<mList.size();i++){
                            int j = Integer.valueOf(mList.get(i));
                            JIFrmGame.this.gameList.remove(j);
                            ArrayList<Integer> tmpList = new ArrayList();
                            for(int n=(j+1);n<mList.size();n++){
                                int k=Integer.valueOf(mList.get(n));
                                --k;
                                tmpList.add(k);
                            }
                            mList=tmpList;
                            tmpList=null;
                            System.gc();
                        }
                             
                        if(JIFrmGame.this.gameList.size()>0)
                        JmnuItemNavegateGoFirstActionPerformedPublic();
                        else{
                           resetAllNumberPanel();
                           setTitle(" 0:"+String.valueOf(gameList.size())+" "+JIFrmGame.this.title);
                           JIFrmGame.this.jbtnMoveFrmToFront.setText(getTitle());
                        }
        
                        if(JIFrmGame.this.jdlgWait.isVisible())
                        JIFrmGame.this.jdlgWait.dispose();
                        while(JIFrmGame.this.jdlgWait.isVisible());
                    }
                   
                }});
        
        thrDlgWaitOne.start();
        
    }//GEN-LAST:event_JmnuItemPanelCheckMultiplicityActionPerformed
    private ArrayList<Integer> checkMultiplicity() throws Exception {
        ArrayList<Integer> mList = new ArrayList();        
            for(int i=0;i<gameList.size() && jdlgWait.isVisible();i++){
               Game g = gameList.get(i);
               int j=(i+1);
               while(j<gameList.size() && jdlgWait.isVisible()){
                   Game gg = gameList.get(j);
                   if(g.getSortedNumber().equalsIgnoreCase(gg.getSortedNumber())){
                       boolean canRegister=true;
                       for(int m=0;m<mList.size() && jdlgWait.isVisible();m++){
                           if(mList.get(m)==j){
                               canRegister=false;
                               break;
                           }
                       }
                       if(canRegister)mList.add(new Integer(j));
                   }
                   j++;
               }
            }
        return mList;
    }
    
    private void JmnuItemNavegateGoToActionPerformedException() throws Exception {
        if(gameList.size()<=0)
        throw new Exception("Nao ha cartao para realizar navegaçao.");
                
        if(thrDlgWaitOne!=null)
        if(thrDlgWaitOne.isAlive()){
            thrDlgWaitOne.interrupt();
            thrDlgWaitOne=null;
        }
        
        String gameStr=JOptionPane.showInternalInputDialog(this,
        "Digite o indice do cartao, ou um cartao com 15 ate 18"
        +" numeros de sorteio\npara ir por pesquisa.",
        "",JOptionPane.YES_NO_OPTION);
                
        if((gameStr==null || gameStr.isEmpty()))return;
                
                thrDlgWaitOne = new Thread(
                new Runnable() {
                public void run() {
                   JIFrmGame.this.jdlgWait = new JDlgWait(true);
                   JIFrmGame.this.jdlgWait.setVisible(true);
                   
                   try
                    {
                        while(JIFrmGame.this.jdlgWait==null);
                        while(!JIFrmGame.this.jdlgWait.isVisible());
                       if(!JIFrmGame.this.startGoToProcess(gameStr)){
                           Game isAGame = new Game(gameStr);
                           isAGame=null;
                           System.gc();
                           ArrayList<Game> gList = new ArrayList();
                           while(JIFrmGame.this.jdlgWait==null
                                   ||!JIFrmGame.this.jdlgWait.isVisible());
                           for(int i=0;JIFrmGame.this.jdlgWait.isVisible() 
                                   && i<JIFrmGame.this.gameList.size();i++){
                               Game g = JIFrmGame.this.gameList.get(i);
                               if(g.getCountOfMatchedSortedNumber(gameStr)>10)
                               gList.add(g);
                           }
                          if(gList.size()<=0)return;
                          if(JIFrmGame.this.jdlgWait.isVisible())
                          JIFrmGame.this.jdlgWait.dispose();
                          while(JIFrmGame.this.jdlgWait.isVisible());
                          int q=JOptionPane.showInternalConfirmDialog(JIFrmGame.this,
                          "Deseja explorar o resultado da pesquisa?"        
                          +"\nTotal-pesquisa:"+String.valueOf(gList.size())+
                           " acima de 10 numeros sorteados...","",
                          JOptionPane.YES_NO_OPTION);
                          if(q>0)return;
                          JIFrmGame frm = new JIFrmGame(
                          JIFrmGame.this.getDesktopPane(),
                          JIFrmGame.this.panelLister,        
                          gList,
                          JIFrmGame.this.getGameName());
                          if(!JIFrmGame.this.jdlgWait.isVisible())
                          JIFrmGame.this.jdlgWait.setVisible(true);
                          while(!JIFrmGame.this.jdlgWait.isVisible());
                          frm.setVisible(true);
                          while(!frm.isVisible());                          
                       }
                    }catch(Exception e){
                        while(JIFrmGame.this.jdlgWait==null || !JIFrmGame.this.jdlgWait.isVisible());
                        if(JIFrmGame.this.jdlgWait.isVisible())
                          JIFrmGame.this.jdlgWait.dispose();
                        while(JIFrmGame.this.jdlgWait.isVisible());
                        JOptionPane.showInternalMessageDialog(JIFrmGame.this,"JIFrmGame.java\n"+e.getMessage()
                        +"\n"+"linha:"+
                        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
                    }finally{
                       if(JIFrmGame.this.jdlgWait!=null)
                       if(JIFrmGame.this.jdlgWait.isVisible())
                       JIFrmGame.this.jdlgWait.dispose();
                   }
                   
                }});
                thrDlgWaitOne.start();
                
    }

    
    private boolean startGoToProcess(String gameStr) throws Exception{
        
        if(!checkIfOnlyNumbers(gameStr))   
                 throw new Exception("O cartao deva ser composto de somente numeros.");
        
        int countOfGameStrContainSpace=0;
        for(int i=0;i<gameStr.length();i++){
        if(gameStr.charAt(i)==' ')
        countOfGameStrContainSpace++;    
        }
                 
        if(countOfGameStrContainSpace>0)return false;
                    
        Integer intg=Integer.valueOf(gameStr);
        if(intg<0 || intg>(gameList.size()-1))
        throw new Exception("Indice de cartao fora da faixa"+" permitida\n"+
        String.valueOf(registeredGameIndex)+":"+gameList.size());
        resetAllNumberPanel();
        Game game = gameList.get(intg);
        registeredGameIndex=intg;
        for(int i=0;i<18;i++){
        Integer intg2=Integer.valueOf(game.getSortedNumberFromIndex(i));
        insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
        markNumberPanel(intg2);
        setTitle(String.valueOf(intg)+":"+String.valueOf(gameList.size())+" "+title);
        if(jbtnMoveFrmToFront!=null)
        jbtnMoveFrmToFront.setText(getTitle());    
        }
                        
        return true;            
    }
    
    private boolean checkIfOnlyNumbers(String sortedNumber){
        final String validCharacter="0123456789 ";
        for(int i=0;i<sortedNumber.length();i++){
            for(int j=0;j<validCharacter.length();j++){
                if(sortedNumber.charAt(i)!=validCharacter.charAt(j)
                        && j==(validCharacter.length()-1)){
                    return false;
                }else if(sortedNumber.charAt(i)==validCharacter.charAt(j)){
                    break;
                }
            }
            
        }        
        return true;
    }

    private void markNumberPanel(int number){
        if(number==1){
            jpnelNumberOne.setBackground(Color.blue);
            jpnelNumberOne1.setBackground(Color.blue);
        }else if(number==2){
            jpnelNumberTwo.setBackground(Color.blue);
            jpnelNumberTwo1.setBackground(Color.blue);
        }else if(number==3){
            jpnelNumberThree.setBackground(Color.blue);
            jpnelNumberThree1.setBackground(Color.blue);
        }else if(number==4){
            jpnelNumberFour.setBackground(Color.blue);
            jpnelNumberFour1.setBackground(Color.blue);
        }else if(number==5){
            jpnelNumberFive.setBackground(Color.blue);
            jpnelNumberFive1.setBackground(Color.blue);
        }else if(number==6){
            jpnelNumberSix.setBackground(Color.blue);
            jpnelNumberSix1.setBackground(Color.blue);
        }else if(number==7){
            jpnelNumberSeven.setBackground(Color.blue);
            jpnelNumberSeven1.setBackground(Color.blue);
        }else if(number==8){
            jpnelNumberEight.setBackground(Color.blue);
            jpnelNumberEight1.setBackground(Color.blue);
        }else if(number==9){
            jpnelNumberNine.setBackground(Color.blue);
            jpnelNumberNine1.setBackground(Color.blue);
        }else if(number==10){
            jpnelNumberTen.setBackground(Color.blue);
            jpnelNumberTen1.setBackground(Color.blue);
        }else if(number==11){
            jpnelNumberEleven.setBackground(Color.blue);
            jpnelNumberEleven1.setBackground(Color.blue);
        }else if(number==12){
            jpnelNumberTwelth.setBackground(Color.blue);
            jpnelNumberTwelth1.setBackground(Color.blue);
        }else if(number==13){
            jpnelNumberThirthTeen.setBackground(Color.blue);
            jpnelNumberThirthTeen1.setBackground(Color.blue);
        }else if(number==14){
            jpnelNumberFourTeen.setBackground(Color.blue);
            jpnelNumberFourTeen1.setBackground(Color.blue);
        }else if(number==15){
            jpnelNumberFithTeen.setBackground(Color.blue);
            jpnelNumberFithTeen1.setBackground(Color.blue);
        }else if(number==16){
            jpnelNumberSixTeen.setBackground(Color.blue);
            jpnelNumberSixTeen1.setBackground(Color.blue);
        }else if(number==17){
            jpnelNumberSevenTeen.setBackground(Color.blue);
            jpnelNumberSevenTeen1.setBackground(Color.blue);
        }else if(number==18){
            jpnelNumberEightTeen.setBackground(Color.blue);
            jpnelNumberEightTeen1.setBackground(Color.blue);
        }else if(number==19){
            jpnelNumberNineTeen.setBackground(Color.blue);
            jpnelNumberNineTeen1.setBackground(Color.blue);
        }else if(number==20){
            jpnelNumberTwenty.setBackground(Color.blue);
            jpnelNumberTwenty1.setBackground(Color.blue);
        }else if(number==21){
            jpnelNumberTwentyOne.setBackground(Color.blue);
            jpnelNumberTwentyOne1.setBackground(Color.blue);
        }else if(number==22){
            jpnelNumberTwentyTwo.setBackground(Color.blue);
            jpnelNumberTwentyTwo1.setBackground(Color.blue);
        }else if(number==23){
            jpnelNumberTwentyThree.setBackground(Color.blue);
            jpnelNumberTwentyThree1.setBackground(Color.blue);
        }else if(number==24){
            jpnelNumberTwentyFour.setBackground(Color.blue);
            jpnelNumberTwentyFour1.setBackground(Color.blue);
        }else if(number==25){
            jpnelNumberTwentyFive.setBackground(Color.blue);
            jpnelNumberTwentyFive1.setBackground(Color.blue);
        }
    }
    
    public void setGameName(String title){
        this.title=title;
        setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
        if(jbtnMoveFrmToFront!=null)
        jbtnMoveFrmToFront.setText(getTitle());    
    }
    
    public String getGameName(){
        return this.title;
    }
    
    public javax.swing.JDesktopPane getDesktopPane(){
        return this.jdskPane;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar JmnuBarGame;
    private javax.swing.JMenuItem JmnuItemCardDelete;
    private javax.swing.JMenuItem JmnuItemCardNew;
    private javax.swing.JMenuItem JmnuItemCardSave;
    private javax.swing.JMenuItem JmnuItemCardUndo;
    private javax.swing.JMenuItem JmnuItemNavegateGoFirst;
    private javax.swing.JMenuItem JmnuItemNavegateGoLast;
    private javax.swing.JMenuItem JmnuItemNavegateGoNext;
    private javax.swing.JMenuItem JmnuItemNavegateGoPrevious;
    private javax.swing.JMenuItem JmnuItemNavegateGoTo;
    private javax.swing.JMenu JmnuItemPanel;
    private javax.swing.JMenuItem JmnuItemPanelBackspace;
    private javax.swing.JMenuItem JmnuItemPanelCheckMultiplicity;
    private javax.swing.JMenuItem JmnuItemPanelEscape;
    private javax.swing.JMenu JmnuItemPanelNumbers;
    private javax.swing.JMenuItem JmnuItemPanelNumbersEight;
    private javax.swing.JMenuItem JmnuItemPanelNumbersFive;
    private javax.swing.JMenuItem JmnuItemPanelNumbersFour;
    private javax.swing.JMenuItem JmnuItemPanelNumbersNine;
    private javax.swing.JMenuItem JmnuItemPanelNumbersOne;
    private javax.swing.JMenuItem JmnuItemPanelNumbersSeven;
    private javax.swing.JMenuItem JmnuItemPanelNumbersSix;
    private javax.swing.JMenuItem JmnuItemPanelNumbersThree;
    private javax.swing.JMenuItem JmnuItemPanelNumbersTwo;
    private javax.swing.JMenuItem JmnuItemPanelNumbersZero;
    private javax.swing.JMenuItem JmnuItemPanelPaintNumber;
    private javax.swing.JMenuItem JmnuItemPanelPincelBlue;
    private javax.swing.JMenuItem JmnuItemPanelPincelRed;
    private javax.swing.JMenuItem JmnuItemPanelRedAll;
    private javax.swing.JLabel jlblNumberEight;
    private javax.swing.JLabel jlblNumberEight1;
    private javax.swing.JLabel jlblNumberEightTeen;
    private javax.swing.JLabel jlblNumberEightTeen1;
    private javax.swing.JLabel jlblNumberEleven;
    private javax.swing.JLabel jlblNumberEleven1;
    private javax.swing.JLabel jlblNumberFithTeen;
    private javax.swing.JLabel jlblNumberFithTeen1;
    private javax.swing.JLabel jlblNumberFive;
    private javax.swing.JLabel jlblNumberFive1;
    private javax.swing.JLabel jlblNumberFour;
    private javax.swing.JLabel jlblNumberFour1;
    private javax.swing.JLabel jlblNumberFourTeen;
    private javax.swing.JLabel jlblNumberFourTeen1;
    private javax.swing.JLabel jlblNumberNine;
    private javax.swing.JLabel jlblNumberNine1;
    private javax.swing.JLabel jlblNumberNineTeen;
    private javax.swing.JLabel jlblNumberNineTeen1;
    private javax.swing.JLabel jlblNumberOne;
    private javax.swing.JLabel jlblNumberOne1;
    private javax.swing.JLabel jlblNumberSeven;
    private javax.swing.JLabel jlblNumberSeven1;
    private javax.swing.JLabel jlblNumberSevenTeen;
    private javax.swing.JLabel jlblNumberSevenTeen1;
    private javax.swing.JLabel jlblNumberSix;
    private javax.swing.JLabel jlblNumberSix1;
    private javax.swing.JLabel jlblNumberSixTeen;
    private javax.swing.JLabel jlblNumberSixTeen1;
    private javax.swing.JLabel jlblNumberTen;
    private javax.swing.JLabel jlblNumberTen1;
    private javax.swing.JLabel jlblNumberThirthTeen;
    private javax.swing.JLabel jlblNumberThirthTeen1;
    private javax.swing.JLabel jlblNumberThree;
    private javax.swing.JLabel jlblNumberThree1;
    private javax.swing.JLabel jlblNumberTwelth;
    private javax.swing.JLabel jlblNumberTwelth1;
    private javax.swing.JLabel jlblNumberTwenty;
    private javax.swing.JLabel jlblNumberTwenty1;
    private javax.swing.JLabel jlblNumberTwentyFive;
    private javax.swing.JLabel jlblNumberTwentyFive1;
    private javax.swing.JLabel jlblNumberTwentyFour;
    private javax.swing.JLabel jlblNumberTwentyFour1;
    private javax.swing.JLabel jlblNumberTwentyOne;
    private javax.swing.JLabel jlblNumberTwentyOne1;
    private javax.swing.JLabel jlblNumberTwentyThree;
    private javax.swing.JLabel jlblNumberTwentyThree1;
    private javax.swing.JLabel jlblNumberTwentyTwo;
    private javax.swing.JLabel jlblNumberTwentyTwo1;
    private javax.swing.JLabel jlblNumberTwo;
    private javax.swing.JLabel jlblNumberTwo1;
    private javax.swing.JLabel jlblNumberView;
    private javax.swing.JLabel jlblPrice15;
    private javax.swing.JLabel jlblPrice16;
    private javax.swing.JLabel jlblPrice17;
    private javax.swing.JLabel jlblPrice18;
    private javax.swing.JLabel jlblSorted;
    private javax.swing.JLabel jlblSortedTotal;
    private javax.swing.JLabel jlblSymbolismFour;
    private javax.swing.JLabel jlblSymbolismOne;
    private javax.swing.JLabel jlblSymbolismThree;
    private javax.swing.JLabel jlblSymbolismTwo;
    private javax.swing.JLabel jlblViewPincel;
    private javax.swing.JLabel jlblViewPincelBlue;
    private javax.swing.JLabel jlblViewPincelRed;
    private javax.swing.JLabel jlblViewPrice;
    private javax.swing.JLabel jlblViewSignalSymbol;
    private javax.swing.JMenu jmnuCard;
    private javax.swing.JMenu jmnuNavegate;
    private javax.swing.JPanel jpnelNumber;
    private javax.swing.JPanel jpnelNumberEight;
    private javax.swing.JPanel jpnelNumberEight1;
    private javax.swing.JPanel jpnelNumberEightTeen;
    private javax.swing.JPanel jpnelNumberEightTeen1;
    private javax.swing.JPanel jpnelNumberEleven;
    private javax.swing.JPanel jpnelNumberEleven1;
    private javax.swing.JPanel jpnelNumberFithTeen;
    private javax.swing.JPanel jpnelNumberFithTeen1;
    private javax.swing.JPanel jpnelNumberFive;
    private javax.swing.JPanel jpnelNumberFive1;
    private javax.swing.JPanel jpnelNumberFour;
    private javax.swing.JPanel jpnelNumberFour1;
    private javax.swing.JPanel jpnelNumberFourTeen;
    private javax.swing.JPanel jpnelNumberFourTeen1;
    private javax.swing.JPanel jpnelNumberNine;
    private javax.swing.JPanel jpnelNumberNine1;
    private javax.swing.JPanel jpnelNumberNineTeen;
    private javax.swing.JPanel jpnelNumberNineTeen1;
    private javax.swing.JPanel jpnelNumberOne;
    private javax.swing.JPanel jpnelNumberOne1;
    private javax.swing.JPanel jpnelNumberSeven;
    private javax.swing.JPanel jpnelNumberSeven1;
    private javax.swing.JPanel jpnelNumberSevenTeen;
    private javax.swing.JPanel jpnelNumberSevenTeen1;
    private javax.swing.JPanel jpnelNumberSix;
    private javax.swing.JPanel jpnelNumberSix1;
    private javax.swing.JPanel jpnelNumberSixTeen;
    private javax.swing.JPanel jpnelNumberSixTeen1;
    private javax.swing.JPanel jpnelNumberTen;
    private javax.swing.JPanel jpnelNumberTen1;
    private javax.swing.JPanel jpnelNumberThirthTeen;
    private javax.swing.JPanel jpnelNumberThirthTeen1;
    private javax.swing.JPanel jpnelNumberThree;
    private javax.swing.JPanel jpnelNumberThree1;
    private javax.swing.JPanel jpnelNumberTwelth;
    private javax.swing.JPanel jpnelNumberTwelth1;
    private javax.swing.JPanel jpnelNumberTwenty;
    private javax.swing.JPanel jpnelNumberTwenty1;
    private javax.swing.JPanel jpnelNumberTwentyFive;
    private javax.swing.JPanel jpnelNumberTwentyFive1;
    private javax.swing.JPanel jpnelNumberTwentyFour;
    private javax.swing.JPanel jpnelNumberTwentyFour1;
    private javax.swing.JPanel jpnelNumberTwentyOne;
    private javax.swing.JPanel jpnelNumberTwentyOne1;
    private javax.swing.JPanel jpnelNumberTwentyThree;
    private javax.swing.JPanel jpnelNumberTwentyThree1;
    private javax.swing.JPanel jpnelNumberTwentyTwo;
    private javax.swing.JPanel jpnelNumberTwentyTwo1;
    private javax.swing.JPanel jpnelNumberTwo;
    private javax.swing.JPanel jpnelNumberTwo1;
    private javax.swing.JPanel jpnelSorted;
    private javax.swing.JPanel jpnelSymbolism;
    private javax.swing.JPanel jpnelSymbolismFourBlue;
    private javax.swing.JPanel jpnelSymbolismFourRed;
    private javax.swing.JPanel jpnelSymbolismOneBlue1;
    private javax.swing.JPanel jpnelSymbolismOneBlue2;
    private javax.swing.JPanel jpnelSymbolismThreeRed1;
    private javax.swing.JPanel jpnelSymbolismThreeRed2;
    private javax.swing.JPanel jpnelSymbolismTwoBlue;
    private javax.swing.JPanel jpnelSymbolismTwoRed;
    private javax.swing.JPanel jpnelView;
    private javax.swing.JPanel jpnelViewPincelBlue;
    private javax.swing.JPanel jpnelViewPincelRed;
    // End of variables declaration//GEN-END:variables
}
//25 24 23 22 21 20 09 08 07 06 05 04 03 02 01
