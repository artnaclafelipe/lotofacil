/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import javax.swing.SwingUtilities;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import model.JBtnMoveFrmToFront;
import java.awt.Color;
import javax.swing.JOptionPane;
import model.Game;
import view.JDlgWait;
import java.util.ArrayList;
/**
 *
 * @author felipe
 */
public class JIFrmGame extends javax.swing.JInternalFrame {

    private enum enmSignal{add,del};
    private String title;
    private static int order = 1;
    private JBtnMoveFrmToFront jbtnMoveFrmToFront = null;
    private enmSignal signal;
    private final static String ZERONUMBERVIEW = "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00";
    private ArrayList<Game> gameList;
    private int registeredGameIndex=-1;
    private static String MSGSORTEDNUMBERINDEXOUTOFRANGE="JIFrmGame.java\nindice de numero sorteado fora da faixa";
    /**
     * Creates new form JIFrmGame
     */
    public JIFrmGame(javax.swing.JDesktopPane jdskPane) {
        //JDlgWait jdlgWait = new JDlgWait();
        //jdlgWait.setVisible(true);                
        //while(!jdlgWait.isVisible());
                
        initComponents();
        this.title = "Novo Jogo-Bolao#"+String.valueOf(order++);
        setIconifiable(true);
        setClosable(true);
        setSignal(enmSignal.add);
        resetAllNumberPanel();
        gameList = new ArrayList();
        setTitle(" 0:"+String.valueOf(gameList.size())+" "+title);
        
        addInternalFrameListener(new InternalFrameListener(){
            @Override
            public void internalFrameOpened(InternalFrameEvent ife) {
              
            }

            @Override
            public void internalFrameClosing(InternalFrameEvent ife) {
                SwingUtilities.invokeLater(new Runnable() {
                @Override
                 public void run() {
                     if(jbtnMoveFrmToFront!=null)
                     JIFrmGame.this.jbtnMoveFrmToFront.destroy();
                 }
                     
                });
            }
            @Override
            public void internalFrameClosed(InternalFrameEvent ife) {
               
            }

            @Override
            public void internalFrameIconified(InternalFrameEvent ife) {
                
            }

            @Override
            public void internalFrameDeiconified(InternalFrameEvent ife) {
               
            }

            @Override
            public void internalFrameActivated(InternalFrameEvent ife) {
                grabFocus();
            }

            @Override
            public void internalFrameDeactivated(InternalFrameEvent ife) {
               
            }
        });
        
        jdskPane.add(this);
        setVisible(true);
        //while(!isVisible());
        //jdlgWait.dispose();
        //grabFocus();
    }
    
    public void setJbtnMoveFrmToFront(JBtnMoveFrmToFront jbtn){
        this.jbtnMoveFrmToFront=jbtn;
    }

    private enmSignal getSignal(){
        return this.signal;
    }
    
    private void setSignal(enmSignal sign){
        this.signal = sign;        
    }
    
    private void resetAllNumberPanel(){
        Color jlblViewSignalSymbolColor = jlblViewSignalSymbol.getForeground();
        jlblViewSignalSymbol.setForeground(Color.red);
        enmSignal currentSignalVal = getSignal();
        setSignal(enmSignal.del);
        jlblSorted.setText(ZERONUMBERVIEW);
        jlblSortedTotal.setText("00");
        jlblNumberView.setText("00");
        jpnelNumberOne.setBackground(Color.red);
        jpnelNumberOne1.setBackground(Color.red);
        jpnelNumberTwo.setBackground(Color.red);
        jpnelNumberTwo1.setBackground(Color.red);
        jpnelNumberThree.setBackground(Color.red);
        jpnelNumberThree1.setBackground(Color.red);
        jpnelNumberFour.setBackground(Color.red);
        jpnelNumberFour1.setBackground(Color.red);
        jpnelNumberFive.setBackground(Color.red);
        jpnelNumberFive1.setBackground(Color.red);
        jpnelNumberSix.setBackground(Color.red);
        jpnelNumberSix1.setBackground(Color.red);
        jpnelNumberSeven.setBackground(Color.red);
        jpnelNumberSeven1.setBackground(Color.red);
        jpnelNumberEight.setBackground(Color.red);
        jpnelNumberEight1.setBackground(Color.red);
        jpnelNumberNine.setBackground(Color.red);
        jpnelNumberNine1.setBackground(Color.red);
        jpnelNumberTen.setBackground(Color.red);
        jpnelNumberTen1.setBackground(Color.red);
        jpnelNumberEleven.setBackground(Color.red);
        jpnelNumberEleven1.setBackground(Color.red);
        jpnelNumberTwelth.setBackground(Color.red);
        jpnelNumberTwelth1.setBackground(Color.red);
        jpnelNumberThirthTeen.setBackground(Color.red);
        jpnelNumberThirthTeen1.setBackground(Color.red);
        jpnelNumberFourTeen.setBackground(Color.red);
        jpnelNumberFourTeen1.setBackground(Color.red);
        jpnelNumberFithTeen.setBackground(Color.red);
        jpnelNumberFithTeen1.setBackground(Color.red);
        jpnelNumberSixTeen.setBackground(Color.red);
        jpnelNumberSixTeen1.setBackground(Color.red);
        jpnelNumberSevenTeen.setBackground(Color.red);
        jpnelNumberSevenTeen1.setBackground(Color.red);
        jpnelNumberEightTeen.setBackground(Color.red);
        jpnelNumberEightTeen1.setBackground(Color.red);
        jpnelNumberNineTeen.setBackground(Color.red);
        jpnelNumberNineTeen1.setBackground(Color.red);
        jpnelNumberTwenty.setBackground(Color.red);
        jpnelNumberTwenty1.setBackground(Color.red);
        jpnelNumberTwentyOne.setBackground(Color.red);
        jpnelNumberTwentyOne1.setBackground(Color.red);
        jpnelNumberTwentyTwo.setBackground(Color.red);
        jpnelNumberTwentyTwo1.setBackground(Color.red);
        jpnelNumberTwentyThree.setBackground(Color.red);
        jpnelNumberTwentyThree1.setBackground(Color.red);
        jpnelNumberTwentyFour.setBackground(Color.red);
        jpnelNumberTwentyFour1.setBackground(Color.red);
        jpnelNumberTwentyFive.setBackground(Color.red);
        jpnelNumberTwentyFive1.setBackground(Color.red);
        setSignal(currentSignalVal);
        jlblViewSignalSymbol.setForeground(jlblViewSignalSymbolColor);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpnelSymbolism = new javax.swing.JPanel();
        jlblSymbolismOne = new javax.swing.JLabel();
        jpnelSymbolismOneBlue1 = new javax.swing.JPanel();
        jpnelSymbolismOneBlue2 = new javax.swing.JPanel();
        jpnelSymbolismTwoRed = new javax.swing.JPanel();
        jlblSymbolismTwo = new javax.swing.JLabel();
        jpnelSymbolismTwoBlue = new javax.swing.JPanel();
        jlblSymbolismThree = new javax.swing.JLabel();
        jpnelSymbolismThreeRed1 = new javax.swing.JPanel();
        jpnelSymbolismThreeRed2 = new javax.swing.JPanel();
        jlblSymbolismFour = new javax.swing.JLabel();
        jpnelSymbolismFourRed = new javax.swing.JPanel();
        jpnelSymbolismFourBlue = new javax.swing.JPanel();
        jpnelView = new javax.swing.JPanel();
        jlblViewPincel = new javax.swing.JLabel();
        jpnelViewPincelBlue = new javax.swing.JPanel();
        jlblViewPincelBlue = new javax.swing.JLabel();
        jpnelViewPincelRed = new javax.swing.JPanel();
        jlblViewPincelRed = new javax.swing.JLabel();
        jlblViewSignalSymbol = new javax.swing.JLabel();
        jlblViewPrice = new javax.swing.JLabel();
        jpnelNumber = new javax.swing.JPanel();
        jpnelNumberFive = new javax.swing.JPanel();
        jlblNumberFive = new javax.swing.JLabel();
        jpnelNumberFour = new javax.swing.JPanel();
        jlblNumberFour = new javax.swing.JLabel();
        jpnelNumberThree = new javax.swing.JPanel();
        jlblNumberThree = new javax.swing.JLabel();
        jpnelNumberTwo = new javax.swing.JPanel();
        jlblNumberTwo = new javax.swing.JLabel();
        jpnelNumberOne = new javax.swing.JPanel();
        jlblNumberOne = new javax.swing.JLabel();
        jpnelNumberTen = new javax.swing.JPanel();
        jlblNumberTen = new javax.swing.JLabel();
        jpnelNumberNine = new javax.swing.JPanel();
        jlblNumberNine = new javax.swing.JLabel();
        jpnelNumberEight = new javax.swing.JPanel();
        jlblNumberEight = new javax.swing.JLabel();
        jpnelNumberSeven = new javax.swing.JPanel();
        jlblNumberSeven = new javax.swing.JLabel();
        jpnelNumberSix = new javax.swing.JPanel();
        jlblNumberSix = new javax.swing.JLabel();
        jpnelNumberFithTeen = new javax.swing.JPanel();
        jlblNumberFithTeen = new javax.swing.JLabel();
        jpnelNumberFourTeen = new javax.swing.JPanel();
        jlblNumberFourTeen = new javax.swing.JLabel();
        jpnelNumberThirthTeen = new javax.swing.JPanel();
        jlblNumberThirthTeen = new javax.swing.JLabel();
        jpnelNumberTwelth = new javax.swing.JPanel();
        jlblNumberTwelth = new javax.swing.JLabel();
        jpnelNumberEleven = new javax.swing.JPanel();
        jlblNumberEleven = new javax.swing.JLabel();
        jpnelNumberTwenty = new javax.swing.JPanel();
        jlblNumberTwenty = new javax.swing.JLabel();
        jpnelNumberNineTeen = new javax.swing.JPanel();
        jlblNumberNineTeen = new javax.swing.JLabel();
        jpnelNumberEightTeen = new javax.swing.JPanel();
        jlblNumberEightTeen = new javax.swing.JLabel();
        jpnelNumberSevenTeen = new javax.swing.JPanel();
        jlblNumberSevenTeen = new javax.swing.JLabel();
        jpnelNumberSixTeen = new javax.swing.JPanel();
        jlblNumberSixTeen = new javax.swing.JLabel();
        jpnelNumberTwentyFive = new javax.swing.JPanel();
        jlblNumberTwentyFive = new javax.swing.JLabel();
        jpnelNumberTwentyFour = new javax.swing.JPanel();
        jlblNumberTwentyFour = new javax.swing.JLabel();
        jpnelNumberTwentyThree = new javax.swing.JPanel();
        jlblNumberTwentyThree = new javax.swing.JLabel();
        jpnelNumberTwentyTwo = new javax.swing.JPanel();
        jlblNumberTwentyTwo = new javax.swing.JLabel();
        jpnelNumberTwentyOne = new javax.swing.JPanel();
        jlblNumberTwentyOne = new javax.swing.JLabel();
        jlblNumberView = new javax.swing.JLabel();
        jpnelNumberFive1 = new javax.swing.JPanel();
        jlblNumberFive1 = new javax.swing.JLabel();
        jpnelNumberFour1 = new javax.swing.JPanel();
        jlblNumberFour1 = new javax.swing.JLabel();
        jpnelNumberThree1 = new javax.swing.JPanel();
        jlblNumberThree1 = new javax.swing.JLabel();
        jpnelNumberTwo1 = new javax.swing.JPanel();
        jlblNumberTwo1 = new javax.swing.JLabel();
        jpnelNumberOne1 = new javax.swing.JPanel();
        jlblNumberOne1 = new javax.swing.JLabel();
        jpnelNumberTen1 = new javax.swing.JPanel();
        jlblNumberTen1 = new javax.swing.JLabel();
        jpnelNumberNine1 = new javax.swing.JPanel();
        jlblNumberNine1 = new javax.swing.JLabel();
        jpnelNumberEight1 = new javax.swing.JPanel();
        jlblNumberEight1 = new javax.swing.JLabel();
        jpnelNumberSeven1 = new javax.swing.JPanel();
        jlblNumberSeven1 = new javax.swing.JLabel();
        jpnelNumberSix1 = new javax.swing.JPanel();
        jlblNumberSix1 = new javax.swing.JLabel();
        jpnelNumberFithTeen1 = new javax.swing.JPanel();
        jlblNumberFithTeen1 = new javax.swing.JLabel();
        jpnelNumberFourTeen1 = new javax.swing.JPanel();
        jlblNumberFourTeen1 = new javax.swing.JLabel();
        jpnelNumberThirthTeen1 = new javax.swing.JPanel();
        jlblNumberThirthTeen1 = new javax.swing.JLabel();
        jpnelNumberTwelth1 = new javax.swing.JPanel();
        jlblNumberTwelth1 = new javax.swing.JLabel();
        jpnelNumberEleven1 = new javax.swing.JPanel();
        jlblNumberEleven1 = new javax.swing.JLabel();
        jpnelNumberTwenty1 = new javax.swing.JPanel();
        jlblNumberTwenty1 = new javax.swing.JLabel();
        jpnelNumberNineTeen1 = new javax.swing.JPanel();
        jlblNumberNineTeen1 = new javax.swing.JLabel();
        jpnelNumberEightTeen1 = new javax.swing.JPanel();
        jlblNumberEightTeen1 = new javax.swing.JLabel();
        jpnelNumberSevenTeen1 = new javax.swing.JPanel();
        jlblNumberSevenTeen1 = new javax.swing.JLabel();
        jpnelNumberSixTeen1 = new javax.swing.JPanel();
        jlblNumberSixTeen1 = new javax.swing.JLabel();
        jpnelNumberTwentyFive1 = new javax.swing.JPanel();
        jlblNumberTwentyFive1 = new javax.swing.JLabel();
        jpnelNumberTwentyFour1 = new javax.swing.JPanel();
        jlblNumberTwentyFour1 = new javax.swing.JLabel();
        jpnelNumberTwentyThree1 = new javax.swing.JPanel();
        jlblNumberTwentyThree1 = new javax.swing.JLabel();
        jpnelNumberTwentyTwo1 = new javax.swing.JPanel();
        jlblNumberTwentyTwo1 = new javax.swing.JLabel();
        jpnelNumberTwentyOne1 = new javax.swing.JPanel();
        jlblNumberTwentyOne1 = new javax.swing.JLabel();
        jpnelSorted = new javax.swing.JPanel();
        jlblSorted = new javax.swing.JLabel();
        jlblSortedTotal = new javax.swing.JLabel();
        jlblPrice15 = new javax.swing.JLabel();
        jlblPrice16 = new javax.swing.JLabel();
        jlblPrice18 = new javax.swing.JLabel();
        jlblPrice17 = new javax.swing.JLabel();
        JmnuBarGame = new javax.swing.JMenuBar();
        jmnuCard = new javax.swing.JMenu();
        JmnuItemCardNew = new javax.swing.JMenuItem();
        JmnuItemCardSave = new javax.swing.JMenuItem();
        JmnuItemCardDelete = new javax.swing.JMenuItem();
        JmnuItemCardUndo = new javax.swing.JMenuItem();
        jmnuNavegate = new javax.swing.JMenu();
        JmnuItemNavegateGoFirst = new javax.swing.JMenuItem();
        JmnuItemNavegateGoNext = new javax.swing.JMenuItem();
        JmnuItemNavegateGoPrevious = new javax.swing.JMenuItem();
        JmnuItemNavegateGoLast = new javax.swing.JMenuItem();
        JmnuItemNavegateGoTo = new javax.swing.JMenuItem();

        setBackground(new java.awt.Color(204, 204, 204));
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });

        jpnelSymbolism.setBackground(Color.BLACK);
        jpnelSymbolism.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismKeyPressed(evt);
            }
        });

        jlblSymbolismOne.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSymbolismOne.setForeground(new java.awt.Color(255, 255, 255));
        jlblSymbolismOne.setText("1");
        jlblSymbolismOne.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblSymbolismOneKeyPressed(evt);
            }
        });

        jpnelSymbolismOneBlue1.setBackground(Color.BLUE);
        jpnelSymbolismOneBlue1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismOneBlue1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSymbolismOneBlue1Layout = new javax.swing.GroupLayout(jpnelSymbolismOneBlue1);
        jpnelSymbolismOneBlue1.setLayout(jpnelSymbolismOneBlue1Layout);
        jpnelSymbolismOneBlue1Layout.setHorizontalGroup(
            jpnelSymbolismOneBlue1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismOneBlue1Layout.setVerticalGroup(
            jpnelSymbolismOneBlue1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jpnelSymbolismOneBlue2.setBackground(Color.BLUE);
        jpnelSymbolismOneBlue2.setForeground(Color.BLUE);
        jpnelSymbolismOneBlue2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismOneBlue2KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSymbolismOneBlue2Layout = new javax.swing.GroupLayout(jpnelSymbolismOneBlue2);
        jpnelSymbolismOneBlue2.setLayout(jpnelSymbolismOneBlue2Layout);
        jpnelSymbolismOneBlue2Layout.setHorizontalGroup(
            jpnelSymbolismOneBlue2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismOneBlue2Layout.setVerticalGroup(
            jpnelSymbolismOneBlue2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jpnelSymbolismTwoRed.setBackground(Color.RED);
        jpnelSymbolismTwoRed.setForeground(Color.BLUE);
        jpnelSymbolismTwoRed.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismTwoRedKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSymbolismTwoRedLayout = new javax.swing.GroupLayout(jpnelSymbolismTwoRed);
        jpnelSymbolismTwoRed.setLayout(jpnelSymbolismTwoRedLayout);
        jpnelSymbolismTwoRedLayout.setHorizontalGroup(
            jpnelSymbolismTwoRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismTwoRedLayout.setVerticalGroup(
            jpnelSymbolismTwoRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );

        jlblSymbolismTwo.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSymbolismTwo.setForeground(new java.awt.Color(255, 255, 255));
        jlblSymbolismTwo.setText("2");
        jlblSymbolismTwo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblSymbolismTwoKeyPressed(evt);
            }
        });

        jpnelSymbolismTwoBlue.setBackground(Color.BLUE);
        jpnelSymbolismTwoBlue.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismTwoBlueKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSymbolismTwoBlueLayout = new javax.swing.GroupLayout(jpnelSymbolismTwoBlue);
        jpnelSymbolismTwoBlue.setLayout(jpnelSymbolismTwoBlueLayout);
        jpnelSymbolismTwoBlueLayout.setHorizontalGroup(
            jpnelSymbolismTwoBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismTwoBlueLayout.setVerticalGroup(
            jpnelSymbolismTwoBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jlblSymbolismThree.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSymbolismThree.setForeground(new java.awt.Color(255, 255, 255));
        jlblSymbolismThree.setText("3");
        jlblSymbolismThree.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblSymbolismThreeKeyPressed(evt);
            }
        });

        jpnelSymbolismThreeRed1.setBackground(Color.RED);
        jpnelSymbolismThreeRed1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismThreeRed1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSymbolismThreeRed1Layout = new javax.swing.GroupLayout(jpnelSymbolismThreeRed1);
        jpnelSymbolismThreeRed1.setLayout(jpnelSymbolismThreeRed1Layout);
        jpnelSymbolismThreeRed1Layout.setHorizontalGroup(
            jpnelSymbolismThreeRed1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismThreeRed1Layout.setVerticalGroup(
            jpnelSymbolismThreeRed1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jpnelSymbolismThreeRed2.setBackground(Color.RED);
        jpnelSymbolismThreeRed2.setForeground(Color.BLUE);
        jpnelSymbolismThreeRed2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismThreeRed2KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSymbolismThreeRed2Layout = new javax.swing.GroupLayout(jpnelSymbolismThreeRed2);
        jpnelSymbolismThreeRed2.setLayout(jpnelSymbolismThreeRed2Layout);
        jpnelSymbolismThreeRed2Layout.setHorizontalGroup(
            jpnelSymbolismThreeRed2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismThreeRed2Layout.setVerticalGroup(
            jpnelSymbolismThreeRed2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );

        jlblSymbolismFour.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSymbolismFour.setForeground(new java.awt.Color(255, 255, 255));
        jlblSymbolismFour.setText("4");
        jlblSymbolismFour.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblSymbolismFourKeyPressed(evt);
            }
        });

        jpnelSymbolismFourRed.setBackground(Color.RED);
        jpnelSymbolismFourRed.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismFourRedKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSymbolismFourRedLayout = new javax.swing.GroupLayout(jpnelSymbolismFourRed);
        jpnelSymbolismFourRed.setLayout(jpnelSymbolismFourRedLayout);
        jpnelSymbolismFourRedLayout.setHorizontalGroup(
            jpnelSymbolismFourRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismFourRedLayout.setVerticalGroup(
            jpnelSymbolismFourRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jpnelSymbolismFourBlue.setBackground(Color.BLUE);
        jpnelSymbolismFourBlue.setForeground(Color.BLUE);
        jpnelSymbolismFourBlue.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSymbolismFourBlueKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSymbolismFourBlueLayout = new javax.swing.GroupLayout(jpnelSymbolismFourBlue);
        jpnelSymbolismFourBlue.setLayout(jpnelSymbolismFourBlueLayout);
        jpnelSymbolismFourBlueLayout.setHorizontalGroup(
            jpnelSymbolismFourBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );
        jpnelSymbolismFourBlueLayout.setVerticalGroup(
            jpnelSymbolismFourBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 29, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jpnelSymbolismLayout = new javax.swing.GroupLayout(jpnelSymbolism);
        jpnelSymbolism.setLayout(jpnelSymbolismLayout);
        jpnelSymbolismLayout.setHorizontalGroup(
            jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                        .addComponent(jlblSymbolismOne)
                        .addGap(3, 3, 3)
                        .addComponent(jpnelSymbolismOneBlue1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelSymbolismOneBlue2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                            .addComponent(jlblSymbolismThree)
                            .addGap(3, 3, 3)
                            .addComponent(jpnelSymbolismThreeRed1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jpnelSymbolismThreeRed2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelSymbolismLayout.createSequentialGroup()
                            .addComponent(jlblSymbolismFour)
                            .addGap(3, 3, 3)
                            .addComponent(jpnelSymbolismFourRed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jpnelSymbolismFourBlue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                        .addComponent(jlblSymbolismTwo)
                        .addGap(3, 3, 3)
                        .addComponent(jpnelSymbolismTwoBlue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelSymbolismTwoRed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpnelSymbolismLayout.setVerticalGroup(
            jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSymbolismLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblSymbolismOne, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismOneBlue1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismOneBlue2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblSymbolismTwo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismTwoBlue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismTwoRed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblSymbolismThree, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismThreeRed1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismThreeRed2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jpnelSymbolismLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlblSymbolismFour, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismFourRed, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpnelSymbolismFourBlue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jpnelView.setBackground(Color.WHITE);
        jpnelView.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelViewKeyPressed(evt);
            }
        });

        jlblViewPincel.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblViewPincel.setForeground(Color.BLACK);
        jlblViewPincel.setText("PINCEL:");
        jlblViewPincel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblViewPincelKeyPressed(evt);
            }
        });

        jpnelViewPincelBlue.setBackground(Color.BLUE);
        jpnelViewPincelBlue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jpnelViewPincelBlueMouseClicked(evt);
            }
        });
        jpnelViewPincelBlue.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelViewPincelBlueKeyPressed(evt);
            }
        });

        jlblViewPincelBlue.setForeground(new java.awt.Color(255, 255, 255));
        jlblViewPincelBlue.setText("F2");
        jlblViewPincelBlue.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblViewPincelBlueMouseClicked(evt);
            }
        });
        jlblViewPincelBlue.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblViewPincelBlueKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelViewPincelBlueLayout = new javax.swing.GroupLayout(jpnelViewPincelBlue);
        jpnelViewPincelBlue.setLayout(jpnelViewPincelBlueLayout);
        jpnelViewPincelBlueLayout.setHorizontalGroup(
            jpnelViewPincelBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelViewPincelBlueLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlblViewPincelBlue)
                .addContainerGap())
        );
        jpnelViewPincelBlueLayout.setVerticalGroup(
            jpnelViewPincelBlueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblViewPincelBlue, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jpnelViewPincelRed.setBackground(Color.RED);
        jpnelViewPincelRed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jpnelViewPincelRedMouseClicked(evt);
            }
        });
        jpnelViewPincelRed.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelViewPincelRedKeyPressed(evt);
            }
        });

        jlblViewPincelRed.setForeground(Color.BLACK);
        jlblViewPincelRed.setText("F1");
        jlblViewPincelRed.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblViewPincelRedMouseClicked(evt);
            }
        });
        jlblViewPincelRed.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblViewPincelRedKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelViewPincelRedLayout = new javax.swing.GroupLayout(jpnelViewPincelRed);
        jpnelViewPincelRed.setLayout(jpnelViewPincelRedLayout);
        jpnelViewPincelRedLayout.setHorizontalGroup(
            jpnelViewPincelRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelViewPincelRedLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlblViewPincelRed)
                .addContainerGap())
        );
        jpnelViewPincelRedLayout.setVerticalGroup(
            jpnelViewPincelRedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblViewPincelRed, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jlblViewSignalSymbol.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblViewSignalSymbol.setForeground(Color.BLUE);
        jlblViewSignalSymbol.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblViewSignalSymbol.setText("VERMELHAR-TUDO (F3)");
        jlblViewSignalSymbol.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlblViewSignalSymbolMouseClicked(evt);
            }
        });
        jlblViewSignalSymbol.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblViewSignalSymbolKeyPressed(evt);
            }
        });

        jlblViewPrice.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jlblViewPrice.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblViewPrice.setText("R$ 00,00");

        javax.swing.GroupLayout jpnelViewLayout = new javax.swing.GroupLayout(jpnelView);
        jpnelView.setLayout(jpnelViewLayout);
        jpnelViewLayout.setHorizontalGroup(
            jpnelViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelViewLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblViewPincel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jpnelViewPincelRed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jpnelViewPincelBlue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblViewSignalSymbol)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlblViewPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jpnelViewLayout.setVerticalGroup(
            jpnelViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelViewLayout.createSequentialGroup()
                .addGroup(jpnelViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelViewLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jpnelViewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jpnelViewPincelBlue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblViewPincel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jpnelViewPincelRed, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblViewSignalSymbol)))
                    .addGroup(jpnelViewLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jlblViewPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jpnelNumber.setBackground(Color.BLACK);
        jpnelNumber.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberKeyPressed(evt);
            }
        });

        jpnelNumberFive.setBackground(Color.WHITE);
        jpnelNumberFive.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberFiveKeyPressed(evt);
            }
        });

        jlblNumberFive.setBackground(Color.BLACK);
        jlblNumberFive.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFive.setForeground(Color.WHITE);
        jlblNumberFive.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFive.setText("05");
        jlblNumberFive.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberFiveKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberFiveLayout = new javax.swing.GroupLayout(jpnelNumberFive);
        jpnelNumberFive.setLayout(jpnelNumberFiveLayout);
        jpnelNumberFiveLayout.setHorizontalGroup(
            jpnelNumberFiveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFive, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFiveLayout.setVerticalGroup(
            jpnelNumberFiveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFour.setBackground(Color.WHITE);
        jpnelNumberFour.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberFourKeyPressed(evt);
            }
        });

        jlblNumberFour.setBackground(Color.BLACK);
        jlblNumberFour.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFour.setForeground(Color.WHITE);
        jlblNumberFour.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFour.setText("04");
        jlblNumberFour.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberFourKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberFourLayout = new javax.swing.GroupLayout(jpnelNumberFour);
        jpnelNumberFour.setLayout(jpnelNumberFourLayout);
        jpnelNumberFourLayout.setHorizontalGroup(
            jpnelNumberFourLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFour, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFourLayout.setVerticalGroup(
            jpnelNumberFourLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberThree.setBackground(Color.WHITE);
        jpnelNumberThree.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberThreeKeyPressed(evt);
            }
        });

        jlblNumberThree.setBackground(Color.BLACK);
        jlblNumberThree.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberThree.setForeground(Color.WHITE);
        jlblNumberThree.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberThree.setText("03");
        jlblNumberThree.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberThreeKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberThreeLayout = new javax.swing.GroupLayout(jpnelNumberThree);
        jpnelNumberThree.setLayout(jpnelNumberThreeLayout);
        jpnelNumberThreeLayout.setHorizontalGroup(
            jpnelNumberThreeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThree, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberThreeLayout.setVerticalGroup(
            jpnelNumberThreeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThree, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwo.setBackground(Color.WHITE);
        jpnelNumberTwo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwoKeyPressed(evt);
            }
        });

        jlblNumberTwo.setBackground(Color.BLACK);
        jlblNumberTwo.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwo.setForeground(Color.WHITE);
        jlblNumberTwo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwo.setText("02");
        jlblNumberTwo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwoKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwoLayout = new javax.swing.GroupLayout(jpnelNumberTwo);
        jpnelNumberTwo.setLayout(jpnelNumberTwoLayout);
        jpnelNumberTwoLayout.setHorizontalGroup(
            jpnelNumberTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwoLayout.setVerticalGroup(
            jpnelNumberTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberOne.setBackground(Color.WHITE);
        jpnelNumberOne.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberOneKeyPressed(evt);
            }
        });

        jlblNumberOne.setBackground(Color.BLACK);
        jlblNumberOne.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberOne.setForeground(Color.WHITE);
        jlblNumberOne.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberOne.setText("01");
        jlblNumberOne.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberOneKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberOneLayout = new javax.swing.GroupLayout(jpnelNumberOne);
        jpnelNumberOne.setLayout(jpnelNumberOneLayout);
        jpnelNumberOneLayout.setHorizontalGroup(
            jpnelNumberOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberOne, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberOneLayout.setVerticalGroup(
            jpnelNumberOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberOne, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTen.setBackground(Color.WHITE);
        jpnelNumberTen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTenKeyPressed(evt);
            }
        });

        jlblNumberTen.setBackground(Color.BLACK);
        jlblNumberTen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTen.setForeground(Color.WHITE);
        jlblNumberTen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTen.setText("10");
        jlblNumberTen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTenLayout = new javax.swing.GroupLayout(jpnelNumberTen);
        jpnelNumberTen.setLayout(jpnelNumberTenLayout);
        jpnelNumberTenLayout.setHorizontalGroup(
            jpnelNumberTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTenLayout.setVerticalGroup(
            jpnelNumberTenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberNine.setBackground(Color.WHITE);
        jpnelNumberNine.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberNineKeyPressed(evt);
            }
        });

        jlblNumberNine.setBackground(Color.BLACK);
        jlblNumberNine.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberNine.setForeground(Color.WHITE);
        jlblNumberNine.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberNine.setText("09");
        jlblNumberNine.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberNineKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberNineLayout = new javax.swing.GroupLayout(jpnelNumberNine);
        jpnelNumberNine.setLayout(jpnelNumberNineLayout);
        jpnelNumberNineLayout.setHorizontalGroup(
            jpnelNumberNineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNine, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberNineLayout.setVerticalGroup(
            jpnelNumberNineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNine, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEight.setBackground(Color.WHITE);
        jpnelNumberEight.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberEightKeyPressed(evt);
            }
        });

        jlblNumberEight.setBackground(Color.BLACK);
        jlblNumberEight.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEight.setForeground(Color.WHITE);
        jlblNumberEight.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEight.setText("08");
        jlblNumberEight.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberEightKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberEightLayout = new javax.swing.GroupLayout(jpnelNumberEight);
        jpnelNumberEight.setLayout(jpnelNumberEightLayout);
        jpnelNumberEightLayout.setHorizontalGroup(
            jpnelNumberEightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEight, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEightLayout.setVerticalGroup(
            jpnelNumberEightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEight, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSeven.setBackground(Color.WHITE);
        jpnelNumberSeven.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberSevenKeyPressed(evt);
            }
        });

        jlblNumberSeven.setBackground(Color.BLACK);
        jlblNumberSeven.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSeven.setForeground(Color.WHITE);
        jlblNumberSeven.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSeven.setText("07");
        jlblNumberSeven.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberSevenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberSevenLayout = new javax.swing.GroupLayout(jpnelNumberSeven);
        jpnelNumberSeven.setLayout(jpnelNumberSevenLayout);
        jpnelNumberSevenLayout.setHorizontalGroup(
            jpnelNumberSevenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSeven, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSevenLayout.setVerticalGroup(
            jpnelNumberSevenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSeven, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSix.setBackground(Color.WHITE);
        jpnelNumberSix.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberSixKeyPressed(evt);
            }
        });

        jlblNumberSix.setBackground(Color.BLACK);
        jlblNumberSix.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSix.setForeground(Color.WHITE);
        jlblNumberSix.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSix.setText("06");
        jlblNumberSix.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberSixKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberSixLayout = new javax.swing.GroupLayout(jpnelNumberSix);
        jpnelNumberSix.setLayout(jpnelNumberSixLayout);
        jpnelNumberSixLayout.setHorizontalGroup(
            jpnelNumberSixLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSix, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSixLayout.setVerticalGroup(
            jpnelNumberSixLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSix, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFithTeen.setBackground(Color.WHITE);
        jpnelNumberFithTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberFithTeenKeyPressed(evt);
            }
        });

        jlblNumberFithTeen.setBackground(Color.BLACK);
        jlblNumberFithTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFithTeen.setForeground(Color.WHITE);
        jlblNumberFithTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFithTeen.setText("15");
        jlblNumberFithTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberFithTeenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberFithTeenLayout = new javax.swing.GroupLayout(jpnelNumberFithTeen);
        jpnelNumberFithTeen.setLayout(jpnelNumberFithTeenLayout);
        jpnelNumberFithTeenLayout.setHorizontalGroup(
            jpnelNumberFithTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFithTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFithTeenLayout.setVerticalGroup(
            jpnelNumberFithTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFithTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFourTeen.setBackground(Color.WHITE);
        jpnelNumberFourTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberFourTeenKeyPressed(evt);
            }
        });

        jlblNumberFourTeen.setBackground(Color.BLACK);
        jlblNumberFourTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFourTeen.setForeground(Color.WHITE);
        jlblNumberFourTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFourTeen.setText("14");
        jlblNumberFourTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberFourTeenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberFourTeenLayout = new javax.swing.GroupLayout(jpnelNumberFourTeen);
        jpnelNumberFourTeen.setLayout(jpnelNumberFourTeenLayout);
        jpnelNumberFourTeenLayout.setHorizontalGroup(
            jpnelNumberFourTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFourTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFourTeenLayout.setVerticalGroup(
            jpnelNumberFourTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFourTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberThirthTeen.setBackground(Color.WHITE);
        jpnelNumberThirthTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberThirthTeenKeyPressed(evt);
            }
        });

        jlblNumberThirthTeen.setBackground(Color.BLACK);
        jlblNumberThirthTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberThirthTeen.setForeground(Color.WHITE);
        jlblNumberThirthTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberThirthTeen.setText("13");
        jlblNumberThirthTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberThirthTeenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberThirthTeenLayout = new javax.swing.GroupLayout(jpnelNumberThirthTeen);
        jpnelNumberThirthTeen.setLayout(jpnelNumberThirthTeenLayout);
        jpnelNumberThirthTeenLayout.setHorizontalGroup(
            jpnelNumberThirthTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThirthTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberThirthTeenLayout.setVerticalGroup(
            jpnelNumberThirthTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThirthTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwelth.setBackground(Color.WHITE);
        jpnelNumberTwelth.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwelthKeyPressed(evt);
            }
        });

        jlblNumberTwelth.setBackground(Color.BLACK);
        jlblNumberTwelth.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwelth.setForeground(Color.WHITE);
        jlblNumberTwelth.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwelth.setText("12");
        jlblNumberTwelth.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwelthKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwelthLayout = new javax.swing.GroupLayout(jpnelNumberTwelth);
        jpnelNumberTwelth.setLayout(jpnelNumberTwelthLayout);
        jpnelNumberTwelthLayout.setHorizontalGroup(
            jpnelNumberTwelthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwelth, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwelthLayout.setVerticalGroup(
            jpnelNumberTwelthLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwelth, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEleven.setBackground(Color.WHITE);
        jpnelNumberEleven.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberElevenKeyPressed(evt);
            }
        });

        jlblNumberEleven.setBackground(Color.BLACK);
        jlblNumberEleven.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEleven.setForeground(Color.WHITE);
        jlblNumberEleven.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEleven.setText("11");
        jlblNumberEleven.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberElevenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberElevenLayout = new javax.swing.GroupLayout(jpnelNumberEleven);
        jpnelNumberEleven.setLayout(jpnelNumberElevenLayout);
        jpnelNumberElevenLayout.setHorizontalGroup(
            jpnelNumberElevenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEleven, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberElevenLayout.setVerticalGroup(
            jpnelNumberElevenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEleven, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwenty.setBackground(Color.WHITE);
        jpnelNumberTwenty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyKeyPressed(evt);
            }
        });

        jlblNumberTwenty.setBackground(Color.BLACK);
        jlblNumberTwenty.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwenty.setForeground(Color.WHITE);
        jlblNumberTwenty.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwenty.setText("20");
        jlblNumberTwenty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyLayout = new javax.swing.GroupLayout(jpnelNumberTwenty);
        jpnelNumberTwenty.setLayout(jpnelNumberTwentyLayout);
        jpnelNumberTwentyLayout.setHorizontalGroup(
            jpnelNumberTwentyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwenty, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyLayout.setVerticalGroup(
            jpnelNumberTwentyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwenty, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberNineTeen.setBackground(Color.WHITE);
        jpnelNumberNineTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberNineTeenKeyPressed(evt);
            }
        });

        jlblNumberNineTeen.setBackground(Color.BLACK);
        jlblNumberNineTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberNineTeen.setForeground(Color.WHITE);
        jlblNumberNineTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberNineTeen.setText("19");
        jlblNumberNineTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberNineTeenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberNineTeenLayout = new javax.swing.GroupLayout(jpnelNumberNineTeen);
        jpnelNumberNineTeen.setLayout(jpnelNumberNineTeenLayout);
        jpnelNumberNineTeenLayout.setHorizontalGroup(
            jpnelNumberNineTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNineTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberNineTeenLayout.setVerticalGroup(
            jpnelNumberNineTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNineTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEightTeen.setBackground(Color.WHITE);
        jpnelNumberEightTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberEightTeenKeyPressed(evt);
            }
        });

        jlblNumberEightTeen.setBackground(Color.BLACK);
        jlblNumberEightTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEightTeen.setForeground(Color.WHITE);
        jlblNumberEightTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEightTeen.setText("18");
        jlblNumberEightTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberEightTeenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberEightTeenLayout = new javax.swing.GroupLayout(jpnelNumberEightTeen);
        jpnelNumberEightTeen.setLayout(jpnelNumberEightTeenLayout);
        jpnelNumberEightTeenLayout.setHorizontalGroup(
            jpnelNumberEightTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEightTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEightTeenLayout.setVerticalGroup(
            jpnelNumberEightTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEightTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSevenTeen.setBackground(Color.WHITE);
        jpnelNumberSevenTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberSevenTeenKeyPressed(evt);
            }
        });

        jlblNumberSevenTeen.setBackground(Color.BLACK);
        jlblNumberSevenTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSevenTeen.setForeground(Color.WHITE);
        jlblNumberSevenTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSevenTeen.setText("17");
        jlblNumberSevenTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberSevenTeenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberSevenTeenLayout = new javax.swing.GroupLayout(jpnelNumberSevenTeen);
        jpnelNumberSevenTeen.setLayout(jpnelNumberSevenTeenLayout);
        jpnelNumberSevenTeenLayout.setHorizontalGroup(
            jpnelNumberSevenTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSevenTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSevenTeenLayout.setVerticalGroup(
            jpnelNumberSevenTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSevenTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSixTeen.setBackground(Color.WHITE);
        jpnelNumberSixTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberSixTeenKeyPressed(evt);
            }
        });

        jlblNumberSixTeen.setBackground(Color.BLACK);
        jlblNumberSixTeen.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSixTeen.setForeground(Color.WHITE);
        jlblNumberSixTeen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSixTeen.setText("16");
        jlblNumberSixTeen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberSixTeenKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberSixTeenLayout = new javax.swing.GroupLayout(jpnelNumberSixTeen);
        jpnelNumberSixTeen.setLayout(jpnelNumberSixTeenLayout);
        jpnelNumberSixTeenLayout.setHorizontalGroup(
            jpnelNumberSixTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSixTeen, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSixTeenLayout.setVerticalGroup(
            jpnelNumberSixTeenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSixTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyFive.setBackground(Color.WHITE);
        jpnelNumberTwentyFive.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyFiveKeyPressed(evt);
            }
        });

        jlblNumberTwentyFive.setBackground(Color.BLACK);
        jlblNumberTwentyFive.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyFive.setForeground(Color.WHITE);
        jlblNumberTwentyFive.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyFive.setText("25");
        jlblNumberTwentyFive.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyFiveKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyFiveLayout = new javax.swing.GroupLayout(jpnelNumberTwentyFive);
        jpnelNumberTwentyFive.setLayout(jpnelNumberTwentyFiveLayout);
        jpnelNumberTwentyFiveLayout.setHorizontalGroup(
            jpnelNumberTwentyFiveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFive, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyFiveLayout.setVerticalGroup(
            jpnelNumberTwentyFiveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyFour.setBackground(Color.WHITE);
        jpnelNumberTwentyFour.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyFourKeyPressed(evt);
            }
        });

        jlblNumberTwentyFour.setBackground(Color.BLACK);
        jlblNumberTwentyFour.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyFour.setForeground(Color.WHITE);
        jlblNumberTwentyFour.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyFour.setText("24");
        jlblNumberTwentyFour.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyFourKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyFourLayout = new javax.swing.GroupLayout(jpnelNumberTwentyFour);
        jpnelNumberTwentyFour.setLayout(jpnelNumberTwentyFourLayout);
        jpnelNumberTwentyFourLayout.setHorizontalGroup(
            jpnelNumberTwentyFourLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFour, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyFourLayout.setVerticalGroup(
            jpnelNumberTwentyFourLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyThree.setBackground(Color.WHITE);
        jpnelNumberTwentyThree.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyThreeKeyPressed(evt);
            }
        });

        jlblNumberTwentyThree.setBackground(Color.BLACK);
        jlblNumberTwentyThree.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyThree.setForeground(Color.WHITE);
        jlblNumberTwentyThree.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyThree.setText("23");
        jlblNumberTwentyThree.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyThreeKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyThreeLayout = new javax.swing.GroupLayout(jpnelNumberTwentyThree);
        jpnelNumberTwentyThree.setLayout(jpnelNumberTwentyThreeLayout);
        jpnelNumberTwentyThreeLayout.setHorizontalGroup(
            jpnelNumberTwentyThreeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyThree, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyThreeLayout.setVerticalGroup(
            jpnelNumberTwentyThreeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyThree, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyTwo.setBackground(Color.WHITE);
        jpnelNumberTwentyTwo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyTwoKeyPressed(evt);
            }
        });

        jlblNumberTwentyTwo.setBackground(Color.BLACK);
        jlblNumberTwentyTwo.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyTwo.setForeground(Color.WHITE);
        jlblNumberTwentyTwo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyTwo.setText("22");
        jlblNumberTwentyTwo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyTwoKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyTwoLayout = new javax.swing.GroupLayout(jpnelNumberTwentyTwo);
        jpnelNumberTwentyTwo.setLayout(jpnelNumberTwentyTwoLayout);
        jpnelNumberTwentyTwoLayout.setHorizontalGroup(
            jpnelNumberTwentyTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyTwo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyTwoLayout.setVerticalGroup(
            jpnelNumberTwentyTwoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyTwo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyOne.setBackground(Color.WHITE);
        jpnelNumberTwentyOne.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyOneKeyPressed(evt);
            }
        });

        jlblNumberTwentyOne.setBackground(Color.BLACK);
        jlblNumberTwentyOne.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyOne.setForeground(Color.WHITE);
        jlblNumberTwentyOne.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyOne.setText("21");
        jlblNumberTwentyOne.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyOneKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyOneLayout = new javax.swing.GroupLayout(jpnelNumberTwentyOne);
        jpnelNumberTwentyOne.setLayout(jpnelNumberTwentyOneLayout);
        jpnelNumberTwentyOneLayout.setHorizontalGroup(
            jpnelNumberTwentyOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyOne, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyOneLayout.setVerticalGroup(
            jpnelNumberTwentyOneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyOne, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jlblNumberView.setFont(new java.awt.Font("Dialog", 1, 50)); // NOI18N
        jlblNumberView.setForeground(Color.WHITE);
        jlblNumberView.setText("00");
        jlblNumberView.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberViewKeyPressed(evt);
            }
        });

        jpnelNumberFive1.setBackground(Color.WHITE);
        jpnelNumberFive1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberFive1KeyPressed(evt);
            }
        });

        jlblNumberFive1.setBackground(Color.BLACK);
        jlblNumberFive1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFive1.setForeground(Color.WHITE);
        jlblNumberFive1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFive1.setText("05");
        jlblNumberFive1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberFive1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberFive1Layout = new javax.swing.GroupLayout(jpnelNumberFive1);
        jpnelNumberFive1.setLayout(jpnelNumberFive1Layout);
        jpnelNumberFive1Layout.setHorizontalGroup(
            jpnelNumberFive1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFive1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFive1Layout.setVerticalGroup(
            jpnelNumberFive1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFive1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFour1.setBackground(Color.WHITE);
        jpnelNumberFour1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberFour1KeyPressed(evt);
            }
        });

        jlblNumberFour1.setBackground(Color.BLACK);
        jlblNumberFour1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFour1.setForeground(Color.WHITE);
        jlblNumberFour1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFour1.setText("04");
        jlblNumberFour1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberFour1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberFour1Layout = new javax.swing.GroupLayout(jpnelNumberFour1);
        jpnelNumberFour1.setLayout(jpnelNumberFour1Layout);
        jpnelNumberFour1Layout.setHorizontalGroup(
            jpnelNumberFour1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFour1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFour1Layout.setVerticalGroup(
            jpnelNumberFour1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFour1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberThree1.setBackground(Color.WHITE);
        jpnelNumberThree1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberThree1KeyPressed(evt);
            }
        });

        jlblNumberThree1.setBackground(Color.BLACK);
        jlblNumberThree1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberThree1.setForeground(Color.WHITE);
        jlblNumberThree1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberThree1.setText("03");
        jlblNumberThree1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberThree1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberThree1Layout = new javax.swing.GroupLayout(jpnelNumberThree1);
        jpnelNumberThree1.setLayout(jpnelNumberThree1Layout);
        jpnelNumberThree1Layout.setHorizontalGroup(
            jpnelNumberThree1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThree1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberThree1Layout.setVerticalGroup(
            jpnelNumberThree1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThree1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwo1.setBackground(Color.WHITE);
        jpnelNumberTwo1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwo1KeyPressed(evt);
            }
        });

        jlblNumberTwo1.setBackground(Color.BLACK);
        jlblNumberTwo1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwo1.setForeground(Color.WHITE);
        jlblNumberTwo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwo1.setText("02");
        jlblNumberTwo1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwo1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwo1Layout = new javax.swing.GroupLayout(jpnelNumberTwo1);
        jpnelNumberTwo1.setLayout(jpnelNumberTwo1Layout);
        jpnelNumberTwo1Layout.setHorizontalGroup(
            jpnelNumberTwo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwo1Layout.setVerticalGroup(
            jpnelNumberTwo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwo1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberOne1.setBackground(Color.WHITE);
        jpnelNumberOne1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberOne1KeyPressed(evt);
            }
        });

        jlblNumberOne1.setBackground(Color.BLACK);
        jlblNumberOne1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberOne1.setForeground(Color.WHITE);
        jlblNumberOne1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberOne1.setText("01");
        jlblNumberOne1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberOne1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberOne1Layout = new javax.swing.GroupLayout(jpnelNumberOne1);
        jpnelNumberOne1.setLayout(jpnelNumberOne1Layout);
        jpnelNumberOne1Layout.setHorizontalGroup(
            jpnelNumberOne1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberOne1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberOne1Layout.setVerticalGroup(
            jpnelNumberOne1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberOne1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTen1.setBackground(Color.WHITE);
        jpnelNumberTen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTen1KeyPressed(evt);
            }
        });

        jlblNumberTen1.setBackground(Color.BLACK);
        jlblNumberTen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTen1.setForeground(Color.WHITE);
        jlblNumberTen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTen1.setText("10");
        jlblNumberTen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTen1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTen1Layout = new javax.swing.GroupLayout(jpnelNumberTen1);
        jpnelNumberTen1.setLayout(jpnelNumberTen1Layout);
        jpnelNumberTen1Layout.setHorizontalGroup(
            jpnelNumberTen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTen1Layout.setVerticalGroup(
            jpnelNumberTen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberNine1.setBackground(Color.WHITE);
        jpnelNumberNine1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberNine1KeyPressed(evt);
            }
        });

        jlblNumberNine1.setBackground(Color.BLACK);
        jlblNumberNine1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberNine1.setForeground(Color.WHITE);
        jlblNumberNine1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberNine1.setText("09");
        jlblNumberNine1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberNine1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberNine1Layout = new javax.swing.GroupLayout(jpnelNumberNine1);
        jpnelNumberNine1.setLayout(jpnelNumberNine1Layout);
        jpnelNumberNine1Layout.setHorizontalGroup(
            jpnelNumberNine1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNine1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberNine1Layout.setVerticalGroup(
            jpnelNumberNine1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNine1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEight1.setBackground(Color.WHITE);
        jpnelNumberEight1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberEight1KeyPressed(evt);
            }
        });

        jlblNumberEight1.setBackground(Color.BLACK);
        jlblNumberEight1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEight1.setForeground(Color.WHITE);
        jlblNumberEight1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEight1.setText("08");
        jlblNumberEight1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberEight1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberEight1Layout = new javax.swing.GroupLayout(jpnelNumberEight1);
        jpnelNumberEight1.setLayout(jpnelNumberEight1Layout);
        jpnelNumberEight1Layout.setHorizontalGroup(
            jpnelNumberEight1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEight1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEight1Layout.setVerticalGroup(
            jpnelNumberEight1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEight1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSeven1.setBackground(Color.WHITE);
        jpnelNumberSeven1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberSeven1KeyPressed(evt);
            }
        });

        jlblNumberSeven1.setBackground(Color.BLACK);
        jlblNumberSeven1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSeven1.setForeground(Color.WHITE);
        jlblNumberSeven1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSeven1.setText("07");
        jlblNumberSeven1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberSeven1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberSeven1Layout = new javax.swing.GroupLayout(jpnelNumberSeven1);
        jpnelNumberSeven1.setLayout(jpnelNumberSeven1Layout);
        jpnelNumberSeven1Layout.setHorizontalGroup(
            jpnelNumberSeven1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSeven1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSeven1Layout.setVerticalGroup(
            jpnelNumberSeven1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSeven1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSix1.setBackground(Color.WHITE);
        jpnelNumberSix1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberSix1KeyPressed(evt);
            }
        });

        jlblNumberSix1.setBackground(Color.BLACK);
        jlblNumberSix1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSix1.setForeground(Color.WHITE);
        jlblNumberSix1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSix1.setText("06");
        jlblNumberSix1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberSix1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberSix1Layout = new javax.swing.GroupLayout(jpnelNumberSix1);
        jpnelNumberSix1.setLayout(jpnelNumberSix1Layout);
        jpnelNumberSix1Layout.setHorizontalGroup(
            jpnelNumberSix1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSix1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSix1Layout.setVerticalGroup(
            jpnelNumberSix1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSix1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFithTeen1.setBackground(Color.WHITE);
        jpnelNumberFithTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberFithTeen1KeyPressed(evt);
            }
        });

        jlblNumberFithTeen1.setBackground(Color.BLACK);
        jlblNumberFithTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFithTeen1.setForeground(Color.WHITE);
        jlblNumberFithTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFithTeen1.setText("15");
        jlblNumberFithTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberFithTeen1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberFithTeen1Layout = new javax.swing.GroupLayout(jpnelNumberFithTeen1);
        jpnelNumberFithTeen1.setLayout(jpnelNumberFithTeen1Layout);
        jpnelNumberFithTeen1Layout.setHorizontalGroup(
            jpnelNumberFithTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFithTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFithTeen1Layout.setVerticalGroup(
            jpnelNumberFithTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFithTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberFourTeen1.setBackground(Color.WHITE);
        jpnelNumberFourTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberFourTeen1KeyPressed(evt);
            }
        });

        jlblNumberFourTeen1.setBackground(Color.BLACK);
        jlblNumberFourTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberFourTeen1.setForeground(Color.WHITE);
        jlblNumberFourTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberFourTeen1.setText("14");
        jlblNumberFourTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberFourTeen1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberFourTeen1Layout = new javax.swing.GroupLayout(jpnelNumberFourTeen1);
        jpnelNumberFourTeen1.setLayout(jpnelNumberFourTeen1Layout);
        jpnelNumberFourTeen1Layout.setHorizontalGroup(
            jpnelNumberFourTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFourTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberFourTeen1Layout.setVerticalGroup(
            jpnelNumberFourTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberFourTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberThirthTeen1.setBackground(Color.WHITE);
        jpnelNumberThirthTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberThirthTeen1KeyPressed(evt);
            }
        });

        jlblNumberThirthTeen1.setBackground(Color.BLACK);
        jlblNumberThirthTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberThirthTeen1.setForeground(Color.WHITE);
        jlblNumberThirthTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberThirthTeen1.setText("13");
        jlblNumberThirthTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberThirthTeen1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberThirthTeen1Layout = new javax.swing.GroupLayout(jpnelNumberThirthTeen1);
        jpnelNumberThirthTeen1.setLayout(jpnelNumberThirthTeen1Layout);
        jpnelNumberThirthTeen1Layout.setHorizontalGroup(
            jpnelNumberThirthTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThirthTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberThirthTeen1Layout.setVerticalGroup(
            jpnelNumberThirthTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberThirthTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwelth1.setBackground(Color.WHITE);
        jpnelNumberTwelth1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwelth1KeyPressed(evt);
            }
        });

        jlblNumberTwelth1.setBackground(Color.BLACK);
        jlblNumberTwelth1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwelth1.setForeground(Color.WHITE);
        jlblNumberTwelth1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwelth1.setText("12");
        jlblNumberTwelth1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwelth1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwelth1Layout = new javax.swing.GroupLayout(jpnelNumberTwelth1);
        jpnelNumberTwelth1.setLayout(jpnelNumberTwelth1Layout);
        jpnelNumberTwelth1Layout.setHorizontalGroup(
            jpnelNumberTwelth1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwelth1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwelth1Layout.setVerticalGroup(
            jpnelNumberTwelth1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwelth1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEleven1.setBackground(Color.WHITE);
        jpnelNumberEleven1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberEleven1KeyPressed(evt);
            }
        });

        jlblNumberEleven1.setBackground(Color.BLACK);
        jlblNumberEleven1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEleven1.setForeground(Color.WHITE);
        jlblNumberEleven1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEleven1.setText("11");
        jlblNumberEleven1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberEleven1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberEleven1Layout = new javax.swing.GroupLayout(jpnelNumberEleven1);
        jpnelNumberEleven1.setLayout(jpnelNumberEleven1Layout);
        jpnelNumberEleven1Layout.setHorizontalGroup(
            jpnelNumberEleven1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEleven1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEleven1Layout.setVerticalGroup(
            jpnelNumberEleven1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEleven1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwenty1.setBackground(Color.WHITE);
        jpnelNumberTwenty1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwenty1KeyPressed(evt);
            }
        });

        jlblNumberTwenty1.setBackground(Color.BLACK);
        jlblNumberTwenty1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwenty1.setForeground(Color.WHITE);
        jlblNumberTwenty1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwenty1.setText("20");
        jlblNumberTwenty1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwenty1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwenty1Layout = new javax.swing.GroupLayout(jpnelNumberTwenty1);
        jpnelNumberTwenty1.setLayout(jpnelNumberTwenty1Layout);
        jpnelNumberTwenty1Layout.setHorizontalGroup(
            jpnelNumberTwenty1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwenty1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwenty1Layout.setVerticalGroup(
            jpnelNumberTwenty1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwenty1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberNineTeen1.setBackground(Color.WHITE);
        jpnelNumberNineTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberNineTeen1KeyPressed(evt);
            }
        });

        jlblNumberNineTeen1.setBackground(Color.BLACK);
        jlblNumberNineTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberNineTeen1.setForeground(Color.WHITE);
        jlblNumberNineTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberNineTeen1.setText("19");
        jlblNumberNineTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberNineTeen1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberNineTeen1Layout = new javax.swing.GroupLayout(jpnelNumberNineTeen1);
        jpnelNumberNineTeen1.setLayout(jpnelNumberNineTeen1Layout);
        jpnelNumberNineTeen1Layout.setHorizontalGroup(
            jpnelNumberNineTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNineTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberNineTeen1Layout.setVerticalGroup(
            jpnelNumberNineTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberNineTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberEightTeen1.setBackground(Color.WHITE);
        jpnelNumberEightTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberEightTeen1KeyPressed(evt);
            }
        });

        jlblNumberEightTeen1.setBackground(Color.BLACK);
        jlblNumberEightTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberEightTeen1.setForeground(Color.WHITE);
        jlblNumberEightTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberEightTeen1.setText("18");
        jlblNumberEightTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberEightTeen1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberEightTeen1Layout = new javax.swing.GroupLayout(jpnelNumberEightTeen1);
        jpnelNumberEightTeen1.setLayout(jpnelNumberEightTeen1Layout);
        jpnelNumberEightTeen1Layout.setHorizontalGroup(
            jpnelNumberEightTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEightTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberEightTeen1Layout.setVerticalGroup(
            jpnelNumberEightTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberEightTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSevenTeen1.setBackground(Color.WHITE);
        jpnelNumberSevenTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberSevenTeen1KeyPressed(evt);
            }
        });

        jlblNumberSevenTeen1.setBackground(Color.BLACK);
        jlblNumberSevenTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSevenTeen1.setForeground(Color.WHITE);
        jlblNumberSevenTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSevenTeen1.setText("17");
        jlblNumberSevenTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberSevenTeen1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberSevenTeen1Layout = new javax.swing.GroupLayout(jpnelNumberSevenTeen1);
        jpnelNumberSevenTeen1.setLayout(jpnelNumberSevenTeen1Layout);
        jpnelNumberSevenTeen1Layout.setHorizontalGroup(
            jpnelNumberSevenTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSevenTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSevenTeen1Layout.setVerticalGroup(
            jpnelNumberSevenTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSevenTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberSixTeen1.setBackground(Color.WHITE);
        jpnelNumberSixTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberSixTeen1KeyPressed(evt);
            }
        });

        jlblNumberSixTeen1.setBackground(Color.BLACK);
        jlblNumberSixTeen1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberSixTeen1.setForeground(Color.WHITE);
        jlblNumberSixTeen1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberSixTeen1.setText("16");
        jlblNumberSixTeen1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberSixTeen1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberSixTeen1Layout = new javax.swing.GroupLayout(jpnelNumberSixTeen1);
        jpnelNumberSixTeen1.setLayout(jpnelNumberSixTeen1Layout);
        jpnelNumberSixTeen1Layout.setHorizontalGroup(
            jpnelNumberSixTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSixTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberSixTeen1Layout.setVerticalGroup(
            jpnelNumberSixTeen1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberSixTeen1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyFive1.setBackground(Color.WHITE);
        jpnelNumberTwentyFive1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyFive1KeyPressed(evt);
            }
        });

        jlblNumberTwentyFive1.setBackground(Color.BLACK);
        jlblNumberTwentyFive1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyFive1.setForeground(Color.WHITE);
        jlblNumberTwentyFive1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyFive1.setText("25");
        jlblNumberTwentyFive1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyFive1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyFive1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyFive1);
        jpnelNumberTwentyFive1.setLayout(jpnelNumberTwentyFive1Layout);
        jpnelNumberTwentyFive1Layout.setHorizontalGroup(
            jpnelNumberTwentyFive1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFive1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyFive1Layout.setVerticalGroup(
            jpnelNumberTwentyFive1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFive1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyFour1.setBackground(Color.WHITE);
        jpnelNumberTwentyFour1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyFour1KeyPressed(evt);
            }
        });

        jlblNumberTwentyFour1.setBackground(Color.BLACK);
        jlblNumberTwentyFour1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyFour1.setForeground(Color.WHITE);
        jlblNumberTwentyFour1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyFour1.setText("24");
        jlblNumberTwentyFour1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyFour1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyFour1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyFour1);
        jpnelNumberTwentyFour1.setLayout(jpnelNumberTwentyFour1Layout);
        jpnelNumberTwentyFour1Layout.setHorizontalGroup(
            jpnelNumberTwentyFour1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFour1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyFour1Layout.setVerticalGroup(
            jpnelNumberTwentyFour1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyFour1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyThree1.setBackground(Color.WHITE);
        jpnelNumberTwentyThree1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyThree1KeyPressed(evt);
            }
        });

        jlblNumberTwentyThree1.setBackground(Color.BLACK);
        jlblNumberTwentyThree1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyThree1.setForeground(Color.WHITE);
        jlblNumberTwentyThree1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyThree1.setText("23");
        jlblNumberTwentyThree1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyThree1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyThree1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyThree1);
        jpnelNumberTwentyThree1.setLayout(jpnelNumberTwentyThree1Layout);
        jpnelNumberTwentyThree1Layout.setHorizontalGroup(
            jpnelNumberTwentyThree1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyThree1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyThree1Layout.setVerticalGroup(
            jpnelNumberTwentyThree1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyThree1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyTwo1.setBackground(Color.WHITE);
        jpnelNumberTwentyTwo1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyTwo1KeyPressed(evt);
            }
        });

        jlblNumberTwentyTwo1.setBackground(Color.BLACK);
        jlblNumberTwentyTwo1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyTwo1.setForeground(Color.WHITE);
        jlblNumberTwentyTwo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyTwo1.setText("22");
        jlblNumberTwentyTwo1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyTwo1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyTwo1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyTwo1);
        jpnelNumberTwentyTwo1.setLayout(jpnelNumberTwentyTwo1Layout);
        jpnelNumberTwentyTwo1Layout.setHorizontalGroup(
            jpnelNumberTwentyTwo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyTwo1Layout.setVerticalGroup(
            jpnelNumberTwentyTwo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyTwo1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        jpnelNumberTwentyOne1.setBackground(Color.WHITE);
        jpnelNumberTwentyOne1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelNumberTwentyOne1KeyPressed(evt);
            }
        });

        jlblNumberTwentyOne1.setBackground(Color.BLACK);
        jlblNumberTwentyOne1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblNumberTwentyOne1.setForeground(Color.WHITE);
        jlblNumberTwentyOne1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblNumberTwentyOne1.setText("21");
        jlblNumberTwentyOne1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblNumberTwentyOne1KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelNumberTwentyOne1Layout = new javax.swing.GroupLayout(jpnelNumberTwentyOne1);
        jpnelNumberTwentyOne1.setLayout(jpnelNumberTwentyOne1Layout);
        jpnelNumberTwentyOne1Layout.setHorizontalGroup(
            jpnelNumberTwentyOne1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyOne1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jpnelNumberTwentyOne1Layout.setVerticalGroup(
            jpnelNumberTwentyOne1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlblNumberTwentyOne1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jpnelNumberLayout = new javax.swing.GroupLayout(jpnelNumber);
        jpnelNumber.setLayout(jpnelNumberLayout);
        jpnelNumberLayout.setHorizontalGroup(
            jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelNumberLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberTwentyFive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwentyFour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwentyThree, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwentyTwo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwentyOne, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberTwenty, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberNineTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberEightTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberSevenTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberSixTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberFithTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberFourTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberThirthTeen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwelth, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberEleven, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberTen, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberNine, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberEight, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberSeven, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberSix, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelNumberFive, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberFour, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberThree, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberTwo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpnelNumberOne, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jpnelNumberOne1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberSix1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberEleven1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberSixTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jpnelNumberTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jpnelNumberSeven1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jpnelNumberTwelth1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jpnelNumberSevenTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addComponent(jpnelNumberTwentyOne1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberTwentyTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jpnelNumberThirthTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jpnelNumberThree1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jpnelNumberEight1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jpnelNumberEightTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jpnelNumberTwentyThree1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addComponent(jpnelNumberFour1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberFive1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberNine1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberTen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberNineTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberTwenty1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberFourTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberFithTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberTwentyFour1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberTwentyFive1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(37, 37, 37)
                        .addComponent(jlblNumberView)))
                .addContainerGap(69, Short.MAX_VALUE))
        );
        jpnelNumberLayout.setVerticalGroup(
            jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelNumberLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addComponent(jpnelNumberOne, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberTwo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberThree, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpnelNumberFour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jpnelNumberFive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelNumberLayout.createSequentialGroup()
                        .addComponent(jpnelNumberTwentyOne, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberTwentyTwo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelNumberTwentyThree, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpnelNumberTwentyFour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jpnelNumberTwentyFive, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jlblNumberView, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelNumberLayout.createSequentialGroup()
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jpnelNumberSeven1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberSix1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberEight1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberNine1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpnelNumberTen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jpnelNumberEleven1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberTwelth1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12)
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jpnelNumberSevenTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberSixTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jpnelNumberTwentyTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jpnelNumberFourTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberFithTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12)
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                                        .addComponent(jpnelNumberTwenty1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jpnelNumberTwentyFive1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jpnelNumberLayout.createSequentialGroup()
                                            .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jpnelNumberNineTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jpnelNumberEightTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(12, 12, 12)
                                            .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jpnelNumberTwentyThree1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jpnelNumberTwentyFour1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addComponent(jpnelNumberTwentyOne1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jpnelNumberLayout.createSequentialGroup()
                        .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberEleven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberTwelth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberThirthTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberFourTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberFithTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberSix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberSeven, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberEight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberNine, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addComponent(jpnelNumberSixTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberSevenTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jpnelNumberEightTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberNineTeen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jpnelNumberTwenty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jpnelNumberOne1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jpnelNumberLayout.createSequentialGroup()
                                .addGroup(jpnelNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jpnelNumberThree1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberFour1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jpnelNumberFive1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(42, 42, 42)
                                .addComponent(jpnelNumberThirthTeen1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jpnelNumberTwo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jpnelSorted.setBackground(Color.BLUE);
        jpnelSorted.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jpnelSortedKeyPressed(evt);
            }
        });

        jlblSorted.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jlblSorted.setForeground(Color.WHITE);
        jlblSorted.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSorted.setText("00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00");
        jlblSorted.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jlblSortedPropertyChange(evt);
            }
        });
        jlblSorted.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblSortedKeyPressed(evt);
            }
        });

        jlblSortedTotal.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jlblSortedTotal.setForeground(Color.WHITE);
        jlblSortedTotal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlblSortedTotal.setText("00");
        jlblSortedTotal.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                jlblSortedTotalPropertyChange(evt);
            }
        });
        jlblSortedTotal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jlblSortedTotalKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jpnelSortedLayout = new javax.swing.GroupLayout(jpnelSorted);
        jpnelSorted.setLayout(jpnelSortedLayout);
        jpnelSortedLayout.setHorizontalGroup(
            jpnelSortedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSortedLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblSortedTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jpnelSortedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpnelSortedLayout.createSequentialGroup()
                    .addGap(0, 98, Short.MAX_VALUE)
                    .addComponent(jlblSorted, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jpnelSortedLayout.setVerticalGroup(
            jpnelSortedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpnelSortedLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlblSortedTotal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jpnelSortedLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jpnelSortedLayout.createSequentialGroup()
                    .addGap(1, 1, 1)
                    .addComponent(jlblSorted, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(1, 1, 1)))
        );

        jlblPrice15.setText("15        R$ 2,00");

        jlblPrice16.setText("16        R$ 32,00");

        jlblPrice18.setText("18        R$ 1632,00");

        jlblPrice17.setText("17        R$ 272,00");

        jmnuCard.setText("Cartao");

        JmnuItemCardNew.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        JmnuItemCardNew.setText("Novo");
        JmnuItemCardNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemCardNewActionPerformed(evt);
            }
        });
        jmnuCard.add(JmnuItemCardNew);

        JmnuItemCardSave.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        JmnuItemCardSave.setText("Salvar");
        JmnuItemCardSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemCardSaveActionPerformed(evt);
            }
        });
        jmnuCard.add(JmnuItemCardSave);

        JmnuItemCardDelete.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        JmnuItemCardDelete.setText("Excluir");
        JmnuItemCardDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemCardDeleteActionPerformed(evt);
            }
        });
        jmnuCard.add(JmnuItemCardDelete);

        JmnuItemCardUndo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        JmnuItemCardUndo.setText("Desfazer");
        JmnuItemCardUndo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemCardUndoActionPerformed(evt);
            }
        });
        jmnuCard.add(JmnuItemCardUndo);

        JmnuBarGame.add(jmnuCard);

        jmnuNavegate.setText("Navegar");

        JmnuItemNavegateGoFirst.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        JmnuItemNavegateGoFirst.setText("Ir Primeiro");
        JmnuItemNavegateGoFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoFirstActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoFirst);

        JmnuItemNavegateGoNext.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        JmnuItemNavegateGoNext.setText("Ir Proximo");
        JmnuItemNavegateGoNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoNextActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoNext);

        JmnuItemNavegateGoPrevious.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F6, 0));
        JmnuItemNavegateGoPrevious.setText("Ir Anterior");
        JmnuItemNavegateGoPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoPreviousActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoPrevious);

        JmnuItemNavegateGoLast.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F7, 0));
        JmnuItemNavegateGoLast.setText("Ir Ultimo");
        JmnuItemNavegateGoLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoLastActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoLast);

        JmnuItemNavegateGoTo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F8, 0));
        JmnuItemNavegateGoTo.setText("Ir Para");
        JmnuItemNavegateGoTo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JmnuItemNavegateGoToActionPerformed(evt);
            }
        });
        jmnuNavegate.add(JmnuItemNavegateGoTo);

        JmnuBarGame.add(jmnuNavegate);

        setJMenuBar(JmnuBarGame);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpnelView, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jpnelNumber, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jpnelSorted, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jpnelSymbolism, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblPrice15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblPrice16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblPrice17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlblPrice18))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jpnelView, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jpnelNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jpnelSorted, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jpnelSymbolism, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblPrice15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblPrice16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblPrice17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlblPrice18)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void keyboardPanel(java.awt.event.KeyEvent evt) throws Exception{                                
        switch(evt.getKeyCode()){
            case java.awt.event.KeyEvent.VK_F1:
                jlblViewPincelRed.setForeground(Color.WHITE);
                jlblViewPincelBlue.setForeground(Color.BLACK);
                setSignal(enmSignal.del);
                jlblViewSignalSymbol.setForeground(Color.red);
            break;
            case java.awt.event.KeyEvent.VK_F2:
                jlblViewPincelRed.setForeground(Color.BLACK);
                jlblViewPincelBlue.setForeground(Color.WHITE);
                setSignal(enmSignal.add);
                jlblViewSignalSymbol.setForeground(Color.blue);
            break;
            case java.awt.event.KeyEvent.VK_F3:
                resetAllNumberPanel();
            break;
            case java.awt.event.KeyEvent.VK_ENTER:
                keyboardPanelEnter();
            break;
            case java.awt.event.KeyEvent.VK_0:
            case java.awt.event.KeyEvent.VK_1:
            case java.awt.event.KeyEvent.VK_2:
            case java.awt.event.KeyEvent.VK_3:    
            case java.awt.event.KeyEvent.VK_4:    
            case java.awt.event.KeyEvent.VK_5:
            case java.awt.event.KeyEvent.VK_6:
            case java.awt.event.KeyEvent.VK_7:
            case java.awt.event.KeyEvent.VK_8:
            case java.awt.event.KeyEvent.VK_9:
                 keyboardPanelNumber(evt);
            break;
            default:
             break;   
        }
    }
    private void keyboardPanelNumber(java.awt.event.KeyEvent evt){
        String jlblNumberViewStr = jlblNumberView.getText();
        if(jlblNumberViewStr.length()==1){
            if(jlblNumberViewStr.equalsIgnoreCase("2")){
                switch(evt.getKeyChar()){
                    case '0':
                    case '1':    
                    case '2':
                    case '3':
                    case '4':    
                    case '5':
                        jlblNumberViewStr+=evt.getKeyChar();
                        jlblNumberView.setText(jlblNumberViewStr);        
                    break;
                }
            }else if(jlblNumberViewStr.equalsIgnoreCase("0")
                    ||jlblNumberViewStr.equalsIgnoreCase("1")){
                        jlblNumberViewStr+=evt.getKeyChar();
                        jlblNumberView.setText(jlblNumberViewStr);        
            }
        }else if(jlblNumberViewStr.length()==2){           
            if(String.valueOf(evt.getKeyChar()).equalsIgnoreCase("0")
                    ||String.valueOf(evt.getKeyChar()).equalsIgnoreCase("1")
                    || String.valueOf(evt.getKeyChar()).equalsIgnoreCase("2"))
                jlblNumberView.setText(String.valueOf(evt.getKeyChar()));
            
        }
    }
    private void keyboardPanelEnter()throws Exception{
        String jlblNumberViewStr = jlblNumberView.getText();
        String jlblSortedStr = jlblSorted.getText();
        if(getSignal()==enmSignal.add)
        if(getCountOfNumberOnJlblSorted()>=18)return;
        
        switch(Integer.valueOf(jlblNumberViewStr))
        {
            case 1:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberOne1.setBackground(Color.red);
                    jpnelNumberOne.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberOne.setBackground(Color.blue);
                    jpnelNumberOne1.setBackground(Color.blue);                     
                    }
                }
            break;    
            case 2:
                
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberTwo1.setBackground(Color.red);
                    jpnelNumberTwo.setBackground(Color.red);
                    }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberTwo1.setBackground(Color.blue);
                    jpnelNumberTwo.setBackground(Color.blue);                
                    }
                }
            break;
            case 3:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberThree.setBackground(Color.red);
                    jpnelNumberThree1.setBackground(Color.red);      
                    }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberThree.setBackground(Color.blue);
                    jpnelNumberThree1.setBackground(Color.blue);
                }
                }
            break;
            case 4:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberFour.setBackground(Color.red);
                    jpnelNumberFour1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberFour.setBackground(Color.blue);
                    jpnelNumberFour1.setBackground(Color.blue);
                }
                }
            break;
            case 5:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberFive.setBackground(Color.red);
                    jpnelNumberFive1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberFive.setBackground(Color.blue);
                    jpnelNumberFive1.setBackground(Color.blue);
                }
                }
            break;    
            case 6:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberSix.setBackground(Color.red);
                    jpnelNumberSix1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberSix.setBackground(Color.blue);
                    jpnelNumberSix1.setBackground(Color.blue);
                }
                }
            break;
            case 7:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberSeven.setBackground(Color.red);
                    jpnelNumberSeven1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberSeven.setBackground(Color.blue);
                    jpnelNumberSeven1.setBackground(Color.blue);          
                }
                }
            break;
            case 8:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberEight.setBackground(Color.red);
                    jpnelNumberEight1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberEight.setBackground(Color.blue);
                    jpnelNumberEight1.setBackground(Color.blue);
                }
                }
            break;    
            case 9:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberNine.setBackground(Color.red);
                    jpnelNumberNine1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberNine.setBackground(Color.blue);
                    jpnelNumberNine1.setBackground(Color.blue);
                }
                }
            break;    
            case 10:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberTen.setBackground(Color.red);
                    jpnelNumberTen1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberTen.setBackground(Color.blue);
                    jpnelNumberTen1.setBackground(Color.blue);
                }
                }
            break;    
            case 11:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberEleven.setBackground(Color.red);
                    jpnelNumberEleven1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberEleven.setBackground(Color.blue);
                    jpnelNumberEleven1.setBackground(Color.blue);
                }
                }
            break;    
            case 12:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberTwelth.setBackground(Color.red);
                    jpnelNumberTwelth1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberTwelth.setBackground(Color.blue);
                    jpnelNumberTwelth1.setBackground(Color.blue);
                }
                }
            break;    
            case 13:
                 if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberThirthTeen.setBackground(Color.red);
                    jpnelNumberThirthTeen1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberThirthTeen.setBackground(Color.blue);
                    jpnelNumberThirthTeen1.setBackground(Color.blue);
                }
                }
            break;    
            case 14:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                    jpnelNumberFourTeen.setBackground(Color.red);
                    jpnelNumberFourTeen1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                    jpnelNumberFourTeen.setBackground(Color.blue);
                    jpnelNumberFourTeen1.setBackground(Color.blue);
                }
                }
            break;    
            case 15:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberFithTeen.setBackground(Color.red);
                        jpnelNumberFithTeen1.setBackground(Color.red);
                }
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberFithTeen.setBackground(Color.blue);
                      jpnelNumberFithTeen1.setBackground(Color.blue);  
                }
                }
            break;    
            case 16:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberSixTeen.setBackground(Color.red);
                        jpnelNumberSixTeen1.setBackground(Color.red);
                }        
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){        
                      jpnelNumberSixTeen.setBackground(Color.blue);
                      jpnelNumberSixTeen1.setBackground(Color.blue);  
                }
                }
            break;    
            case 17:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberSevenTeen.setBackground(Color.red);
                        jpnelNumberSevenTeen1.setBackground(Color.red);
                    }        
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberSevenTeen.setBackground(Color.blue);
                      jpnelNumberSevenTeen1.setBackground(Color.blue);  
                }
                }
            break;    
            case 18:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberEightTeen.setBackground(Color.red);
                        jpnelNumberEightTeen1.setBackground(Color.red);
                    }  
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberEightTeen.setBackground(Color.blue);
                      jpnelNumberEightTeen1.setBackground(Color.blue);  
                }
                }
            break;    
            case 19:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberNineTeen.setBackground(Color.red);
                        jpnelNumberNineTeen1.setBackground(Color.red);
                    } 
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                        jpnelNumberNineTeen.setBackground(Color.blue);
                        jpnelNumberNineTeen1.setBackground(Color.blue);
                }
                }
            break;    
            case 20:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwenty.setBackground(Color.red);
                        jpnelNumberTwenty1.setBackground(Color.red);
                    }  
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwenty.setBackground(Color.blue);
                      jpnelNumberTwenty1.setBackground(Color.blue);
                }
                }
            break;    
            case 21:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyOne.setBackground(Color.red);
                        jpnelNumberTwentyOne1.setBackground(Color.red);
                    } 
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){   
                      jpnelNumberTwentyOne.setBackground(Color.blue);
                      jpnelNumberTwentyOne1.setBackground(Color.blue);    
                }
                }
            break;    
            case 22:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyTwo.setBackground(Color.red);
                        jpnelNumberTwentyTwo1.setBackground(Color.red);                    
                    } 
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwentyTwo.setBackground(Color.blue);
                      jpnelNumberTwentyTwo1.setBackground(Color.blue);
                }
                }
            break;    
            case 23:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyThree.setBackground(Color.red);
                        jpnelNumberTwentyThree1.setBackground(Color.red);
                    } 
                        
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwentyThree.setBackground(Color.blue);
                      jpnelNumberTwentyThree1.setBackground(Color.blue);  
                      
                }
                }
            break;    
            case 24:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyFour.setBackground(Color.red);
                        jpnelNumberTwentyFour1.setBackground(Color.red);
                    }  
                        
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwentyFour.setBackground(Color.blue);
                      jpnelNumberTwentyFour1.setBackground(Color.blue);
                      
                }
                }
            break;    
            case 25:
                if(jlblViewSignalSymbol.getForeground()==Color.red){
                    if(deleteNumberOnJlblSorted(jlblNumberView.getText())){
                        jpnelNumberTwentyFive.setBackground(Color.red);
                        jpnelNumberTwentyFive1.setBackground(Color.red);
                    } 
                }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
                    if(insertNumberOnJlblSorted(jlblNumberView.getText())){                    
                      jpnelNumberTwentyFive.setBackground(Color.blue);
                      jpnelNumberTwentyFive1.setBackground(Color.blue);   
                }                
                }
            break;    
        }
        
    }
    
    private boolean deleteNumberOnJlblSorted(String number)throws Exception{
        String selStr = "";
        Integer selInt = 0;
        String numberingDel = "";
        Integer numberInt = Integer.valueOf(number);
        if(!existNumberOnJlblSorted(number)){
           return false;
        }
        
        if(number.length()!=2)return false;
        
        for(int i=0;i<18;i++)
        {
            selStr = getSortedNumberFromIndex(i);
            selInt = Integer.valueOf(selStr);
            if(numberInt==selInt)
            {
                for(int j=0;j<i;j++)
                {
                    numberingDel+=getSortedNumberFromIndex(j)+" ";
                }
                ++i;
                for(int j=i;j<18;j++)
                {
                    numberingDel+=getSortedNumberFromIndex(j)+" ";
                }
                 jlblSorted.setText(numberingDel+"00");
                 return true;
            }
        }
       
        return true;
    }
    
    private boolean insertNumberOnJlblSorted(String number){
        try
        {
        if(!existNumberOnJlblSorted(number)){
            if(getCountOfNumberOnJlblSorted()<18){
                if(number.length()==2){
                   String newNumberOrdering = getNumberOrdering(number);
                   jlblSorted.setText(newNumberOrdering);                
                   return true;
                }
            }
        }
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        return false;
    }
    
    private String getNumberOrdering(String number)throws Exception{
        String ret="";
        
        if(existNumberOnJlblSorted(number)){
            return jlblSorted.getText();
        }
        
        if(getCountOfNumberOnJlblSorted()>=18){
            return jlblSorted.getText();
        }   
        final Integer numberInt = Integer.valueOf(number);
        String  selStr = "";
        Integer selInt = 0;
        
        for(int i=0;i<18;i++){
            selStr = getSortedNumberFromIndex(i);
            selInt = Integer.valueOf(selStr);
            if(selInt==0)
            {
                if(i==0)
                {
                    ret=number;
                    for(int j=(++i);j<18;j++){
                        ret+=" "+getSortedNumberFromIndex(j);
                    }
                    return ret;
                }else //i==0
                {
                    for(int j=0;j<i;j++){
                        ret+=getSortedNumberFromIndex(j)+" ";
                    }
                    ret+=number+" ";
                    for(int j=(++i);j<18;j++){
                        ret+=getSortedNumberFromIndex(j)+" ";
                    }
                    return ret;
                }
            }else if(selInt>numberInt)//if selInt
            {
                    for(int j=0;j<i;j++){
                        ret+=getSortedNumberFromIndex(j)+" ";
                    }
                    ret+=number+" ";
                    for(int j=i;j<17;j++){
                        ret+=getSortedNumberFromIndex(j)+" ";
                    }
                    return ret;
            }
        }
        return ret;
    }
    
    private String getSortedNumberFromIndex(int index)throws Exception{
        if(index<0 || index>17){
        throw new Exception(MSGSORTEDNUMBERINDEXOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }   
        String ret="";
        String jlblSortedStr = "";
        for(int i=0;i<jlblSorted.getText().length();i++){
            if(jlblSorted.getText().charAt(i)!=' ')
            jlblSortedStr+=jlblSorted.getText().charAt(i);    
        }
        index*=2;
        ret = jlblSortedStr.substring(index,index+2);
        return ret;
    }
    
    private int getCountOfNumberOnJlblSorted()throws Exception{
        int ret=0;
        for(int i=0;i<18;i++){
            Integer intg=Integer.valueOf(getSortedNumberFromIndex(i));
            if(intg>0)ret++;
        }
        return ret;
    }
    
    private boolean existNumberOnJlblSorted(String number){
        String jlblSortedStr = jlblSorted.getText();
        for(int i=0;i<jlblSortedStr.length();i+=3){
            String strSel = new String(String.valueOf(jlblSortedStr.charAt(i))+String.valueOf(jlblSortedStr.charAt(i+1)));
            if(strSel.equalsIgnoreCase(number)){
                if(number.length()==2)
                    return true;
            }
        }
        return false;
    }
    
    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_formKeyPressed

    private void jlblViewPincelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblViewPincelKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblViewPincelKeyPressed

    private void jpnelSymbolismKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismKeyPressed

    private void jlblSymbolismOneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblSymbolismOneKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblSymbolismOneKeyPressed

    private void jpnelSymbolismOneBlue1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismOneBlue1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismOneBlue1KeyPressed

    private void jpnelSymbolismOneBlue2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismOneBlue2KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismOneBlue2KeyPressed

    private void jpnelSymbolismTwoRedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismTwoRedKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismTwoRedKeyPressed

    private void jlblSymbolismTwoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblSymbolismTwoKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblSymbolismTwoKeyPressed

    private void jpnelSymbolismTwoBlueKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismTwoBlueKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismTwoBlueKeyPressed

    private void jlblSymbolismThreeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblSymbolismThreeKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblSymbolismThreeKeyPressed

    private void jpnelSymbolismThreeRed1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismThreeRed1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismThreeRed1KeyPressed

    private void jpnelSymbolismThreeRed2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismThreeRed2KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismThreeRed2KeyPressed

    private void jlblSymbolismFourKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblSymbolismFourKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblSymbolismFourKeyPressed

    private void jpnelSymbolismFourRedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismFourRedKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismFourRedKeyPressed

    private void jpnelSymbolismFourBlueKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSymbolismFourBlueKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSymbolismFourBlueKeyPressed

    private void jpnelViewKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelViewKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelViewKeyPressed

    private void jpnelViewPincelBlueKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelViewPincelBlueKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelViewPincelBlueKeyPressed

    private void jlblViewPincelBlueKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblViewPincelBlueKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblViewPincelBlueKeyPressed

    private void jpnelViewPincelRedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelViewPincelRedKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelViewPincelRedKeyPressed

    private void jlblViewPincelRedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblViewPincelRedKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblViewPincelRedKeyPressed

    private void jlblViewSignalSymbolKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblViewSignalSymbolKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblViewSignalSymbolKeyPressed

    private void jpnelNumberKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberKeyPressed

    private void jpnelSortedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelSortedKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelSortedKeyPressed

    private void jlblSortedKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblSortedKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblSortedKeyPressed

    private void jpnelNumberFiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberFiveKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberFiveKeyPressed

    private void jpnelNumberFourKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberFourKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberFourKeyPressed

    private void jpnelNumberThreeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberThreeKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberThreeKeyPressed

    private void jpnelNumberTwoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwoKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwoKeyPressed

    private void jpnelNumberOneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberOneKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberOneKeyPressed

    private void jpnelNumberTenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTenKeyPressed

    private void jpnelNumberNineKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberNineKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberNineKeyPressed

    private void jpnelNumberEightKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberEightKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberEightKeyPressed

    private void jpnelNumberSevenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberSevenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberSevenKeyPressed

    private void jpnelNumberSixKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberSixKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberSixKeyPressed

    private void jpnelNumberFithTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberFithTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberFithTeenKeyPressed

    private void jpnelNumberFourTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberFourTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberFourTeenKeyPressed

    private void jpnelNumberThirthTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberThirthTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberThirthTeenKeyPressed

    private void jpnelNumberTwelthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwelthKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwelthKeyPressed

    private void jpnelNumberElevenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberElevenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberElevenKeyPressed

    private void jpnelNumberTwentyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyKeyPressed

    private void jpnelNumberNineTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberNineTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberNineTeenKeyPressed

    private void jpnelNumberEightTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberEightTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberEightTeenKeyPressed

    private void jpnelNumberSevenTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberSevenTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberSevenTeenKeyPressed

    private void jpnelNumberSixTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberSixTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberSixTeenKeyPressed

    private void jpnelNumberTwentyFiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyFiveKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyFiveKeyPressed

    private void jpnelNumberTwentyFourKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyFourKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyFourKeyPressed

    private void jpnelNumberTwentyThreeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyThreeKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyThreeKeyPressed

    private void jpnelNumberTwentyTwoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyTwoKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyTwoKeyPressed

    private void jpnelNumberTwentyOneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyOneKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyOneKeyPressed

    private void jlblSortedTotalKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblSortedTotalKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblSortedTotalKeyPressed

    private void jlblNumberTwentyOneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyOneKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyOneKeyPressed

    private void jlblNumberTwentyTwoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyTwoKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyTwoKeyPressed

    private void jlblNumberTwentyThreeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyThreeKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyThreeKeyPressed

    private void jlblNumberTwentyFourKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyFourKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyFourKeyPressed

    private void jlblNumberTwentyFiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyFiveKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyFiveKeyPressed

    private void jlblNumberFiveKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberFiveKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberFiveKeyPressed

    private void jlblNumberFourKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberFourKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberFourKeyPressed

    private void jlblNumberThreeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberThreeKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberThreeKeyPressed

    private void jlblNumberTwoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwoKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwoKeyPressed

    private void jlblNumberOneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberOneKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberOneKeyPressed

    private void jlblNumberTenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTenKeyPressed

    private void jlblNumberNineKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberNineKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberNineKeyPressed

    private void jlblNumberEightKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberEightKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberEightKeyPressed

    private void jlblNumberSevenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberSevenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberSevenKeyPressed

    private void jlblNumberSixKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberSixKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberSixKeyPressed

    private void jlblNumberFithTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberFithTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberFithTeenKeyPressed

    private void jlblNumberFourTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberFourTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberFourTeenKeyPressed

    private void jlblNumberThirthTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberThirthTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberThirthTeenKeyPressed

    private void jlblNumberTwelthKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwelthKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwelthKeyPressed

    private void jlblNumberElevenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberElevenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberElevenKeyPressed

    private void jlblNumberTwentyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyKeyPressed

    private void jlblNumberNineTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberNineTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberNineTeenKeyPressed

    private void jlblNumberEightTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberEightTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberEightTeenKeyPressed

    private void jlblNumberSevenTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberSevenTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberSevenTeenKeyPressed

    private void jlblNumberSixTeenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberSixTeenKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberSixTeenKeyPressed

    private void jlblNumberViewKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberViewKeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberViewKeyPressed

    private void jlblNumberFive1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberFive1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberFive1KeyPressed

    private void jpnelNumberFive1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberFive1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberFive1KeyPressed

    private void jlblNumberFour1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberFour1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberFour1KeyPressed

    private void jpnelNumberFour1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberFour1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberFour1KeyPressed

    private void jlblNumberThree1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberThree1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberThree1KeyPressed

    private void jpnelNumberThree1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberThree1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberThree1KeyPressed

    private void jlblNumberTwo1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwo1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwo1KeyPressed

    private void jpnelNumberTwo1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwo1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwo1KeyPressed

    private void jlblNumberOne1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberOne1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberOne1KeyPressed

    private void jpnelNumberOne1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberOne1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberOne1KeyPressed

    private void jlblNumberTen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTen1KeyPressed

    private void jpnelNumberTen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTen1KeyPressed

    private void jlblNumberNine1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberNine1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberNine1KeyPressed

    private void jpnelNumberNine1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberNine1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberNine1KeyPressed

    private void jlblNumberEight1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberEight1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberEight1KeyPressed

    private void jpnelNumberEight1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberEight1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberEight1KeyPressed

    private void jlblNumberSeven1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberSeven1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberSeven1KeyPressed

    private void jpnelNumberSeven1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberSeven1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberSeven1KeyPressed

    private void jlblNumberSix1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberSix1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberSix1KeyPressed

    private void jpnelNumberSix1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberSix1KeyPressed
    try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberSix1KeyPressed

    private void jlblNumberFithTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberFithTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberFithTeen1KeyPressed

    private void jpnelNumberFithTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberFithTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberFithTeen1KeyPressed

    private void jlblNumberFourTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberFourTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberFourTeen1KeyPressed

    private void jpnelNumberFourTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberFourTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberFourTeen1KeyPressed

    private void jlblNumberThirthTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberThirthTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberThirthTeen1KeyPressed

    private void jpnelNumberThirthTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberThirthTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberThirthTeen1KeyPressed

    private void jlblNumberTwelth1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwelth1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwelth1KeyPressed

    private void jpnelNumberTwelth1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwelth1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwelth1KeyPressed

    private void jlblNumberEleven1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberEleven1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberEleven1KeyPressed

    private void jpnelNumberEleven1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberEleven1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberEleven1KeyPressed

    private void jlblNumberTwenty1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwenty1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwenty1KeyPressed

    private void jpnelNumberTwenty1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwenty1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwenty1KeyPressed

    private void jlblNumberNineTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberNineTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberNineTeen1KeyPressed

    private void jpnelNumberNineTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberNineTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberNineTeen1KeyPressed

    private void jlblNumberEightTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberEightTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberEightTeen1KeyPressed

    private void jpnelNumberEightTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberEightTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberEightTeen1KeyPressed

    private void jlblNumberSevenTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberSevenTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberSevenTeen1KeyPressed

    private void jpnelNumberSevenTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberSevenTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberSevenTeen1KeyPressed

    private void jlblNumberSixTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberSixTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberSixTeen1KeyPressed

    private void jpnelNumberSixTeen1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberSixTeen1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberSixTeen1KeyPressed

    private void jlblNumberTwentyFive1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyFive1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyFive1KeyPressed

    private void jpnelNumberTwentyFive1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyFive1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyFive1KeyPressed

    private void jlblNumberTwentyFour1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyFour1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyFour1KeyPressed

    private void jpnelNumberTwentyFour1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyFour1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyFour1KeyPressed

    private void jlblNumberTwentyThree1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyThree1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyThree1KeyPressed

    private void jpnelNumberTwentyThree1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyThree1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyThree1KeyPressed

    private void jlblNumberTwentyTwo1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyTwo1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyTwo1KeyPressed

    private void jpnelNumberTwentyTwo1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyTwo1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyTwo1KeyPressed

    private void jlblNumberTwentyOne1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jlblNumberTwentyOne1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jlblNumberTwentyOne1KeyPressed

    private void jpnelNumberTwentyOne1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpnelNumberTwentyOne1KeyPressed
        try
        {
            keyboardPanel(evt);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }        
    }//GEN-LAST:event_jpnelNumberTwentyOne1KeyPressed

    private void jlblViewSignalSymbolMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblViewSignalSymbolMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jlblViewSignalSymbolMouseClicked

    private void jlblViewPincelBlueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblViewPincelBlueMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jlblViewPincelBlueMouseClicked

    private void jpnelViewPincelBlueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpnelViewPincelBlueMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jpnelViewPincelBlueMouseClicked

    private void jlblViewPincelRedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlblViewPincelRedMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jlblViewPincelRedMouseClicked

    private void jpnelViewPincelRedMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jpnelViewPincelRedMouseClicked
        resetAllNumberPanel();
    }//GEN-LAST:event_jpnelViewPincelRedMouseClicked

    private void jlblSortedTotalPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jlblSortedTotalPropertyChange
        Integer jlblSortedTotalInt = Integer.valueOf(jlblSortedTotal.getText());
        if(jlblSortedTotalInt==15)
            jlblViewPrice.setText("R$ 2,00");
        else if(jlblSortedTotalInt==16)
            jlblViewPrice.setText("R$ 32,00");
        else if(jlblSortedTotalInt==17)
            jlblViewPrice.setText("R$ 272,00");
        else if(jlblSortedTotalInt==18)
            jlblViewPrice.setText("R$ 1632,00");
        else 
            jlblViewPrice.setText("R$ 00,00");
    }//GEN-LAST:event_jlblSortedTotalPropertyChange

    private void JmnuItemCardNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemCardNewActionPerformed
        
        if(registeredGameIndex==-1)
        if(!jlblSorted.getText().equalsIgnoreCase(ZERONUMBERVIEW)){
            int q=-1;
            q=JOptionPane.showConfirmDialog(this,
            new String("Cartao nao registrado, deseja registra-lo?"));
            
            if(q==2) return;
            else if(q==1){
               resetAllNumberPanel();
               jlblSorted.setText(ZERONUMBERVIEW);
               jlblNumberView.setText("00");
           }else if(q==0){
           try
           {
               gameList.add(new Game(jlblSorted.getText()));                        
               resetAllNumberPanel();
               jlblSorted.setText(ZERONUMBERVIEW);
               jlblNumberView.setText("00");
               setTitle(" 0:"+String.valueOf(gameList.size())+title);
            if(jbtnMoveFrmToFront!=null)
               jbtnMoveFrmToFront.setText(getTitle());    
            }catch(Exception e){
               JOptionPane.showMessageDialog(this,e.getMessage());
            }
            }
            return;
        }
        int q=-1;
            q=JOptionPane.showConfirmDialog(this,
            new String("Deseja continuar a criar novo jogo?"),
            "",JOptionPane.YES_NO_OPTION);
            if(q==0){
               resetAllNumberPanel();
               jlblSorted.setText(ZERONUMBERVIEW);
               jlblNumberView.setText("00");
               registeredGameIndex=-1;
            }
                
        
    }//GEN-LAST:event_JmnuItemCardNewActionPerformed

    private void JmnuItemCardSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemCardSaveActionPerformed
        if(!jlblSorted.getText().equalsIgnoreCase(ZERONUMBERVIEW))
        if(registeredGameIndex==-1){
            int q=-1;
            q=JOptionPane.showConfirmDialog(this,
            new String("Cartao ainda nao registrado, deseja registra-lo?"),
                      "",JOptionPane.YES_NO_OPTION);
            
            if(q==1) return;
            else if(q==0){
                  try
                  {
                     gameList.add(new Game(jlblSorted.getText()));
                     registeredGameIndex=(gameList.size()-1);
                     setTitle(String.valueOf(registeredGameIndex)+
                             ":"+String.valueOf(gameList.size())+" "+title);
                     if(jbtnMoveFrmToFront!=null)
                     jbtnMoveFrmToFront.setText(getTitle());    
                  }catch(Exception e){
                   JOptionPane.showMessageDialog(this,e.getMessage());
                  }
            }
            return;
        }
        
        int q=-1;
        q=JOptionPane.showConfirmDialog(this,
        new String("Deseja continuar a salvar cartao? Sera sobrescrito sem poder recuperar-lo."),
        "",JOptionPane.YES_NO_OPTION);
        
        if(q==1)return;
        try
        {
            Game game = new Game(jlblSorted.getText());
            gameList.get(registeredGameIndex).setSortedNumber(game.getSortedNumber());
            setTitle(String.valueOf(registeredGameIndex)+
                             ":"+String.valueOf(gameList.size())+" "+title);
            if(jbtnMoveFrmToFront!=null)
            jbtnMoveFrmToFront.setText(getTitle());    
        }catch(Exception e){
                   JOptionPane.showMessageDialog(this,e.getMessage());
        }
        
    }//GEN-LAST:event_JmnuItemCardSaveActionPerformed

    private void JmnuItemCardUndoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemCardUndoActionPerformed
        try
        {
            if(registeredGameIndex>-1){
                resetAllNumberPanel();
                Game game = gameList.get(registeredGameIndex);
                for(int i=0;i<18;i++){
                    Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                    insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                    markNumberPanel(intg);                    
                }
            }
            
        }catch(Exception e){
                   JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }//GEN-LAST:event_JmnuItemCardUndoActionPerformed

    private void JmnuItemCardDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemCardDeleteActionPerformed
        if(registeredGameIndex>-1){
            int q=-1;
            q=JOptionPane.showConfirmDialog(this,
            new String("Deseja continuar a excluir cartao? Sem poder recuperar-lo."
            +"\n"+gameList.get(registeredGameIndex).getSortedNumber()),"",JOptionPane.YES_NO_OPTION);
            if(q==1)return;
            gameList.remove(registeredGameIndex);
            registeredGameIndex=-1;
            resetAllNumberPanel();
            setTitle(" 0"+":"+String.valueOf(gameList.size())+" "+title);
            if(jbtnMoveFrmToFront!=null)
            jbtnMoveFrmToFront.setText(getTitle());    
        }
        
    }//GEN-LAST:event_JmnuItemCardDeleteActionPerformed

    private void jlblSortedPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_jlblSortedPropertyChange
    this.grabFocus();
    try
    {
    Integer sortedTotal = Integer.valueOf(jlblSortedTotal.getText());
    if(getCountOfNumberOnJlblSorted()==0 && sortedTotal>0){
        if(jlblViewSignalSymbol.getForeground()==Color.red){
            if(sortedTotal>0)sortedTotal--;
        }
    }else if(getCountOfNumberOnJlblSorted()>0)
    if(jlblViewSignalSymbol.getForeground()==Color.red){
        if(sortedTotal>0)sortedTotal--;
    }else if(jlblViewSignalSymbol.getForeground()==Color.blue){
        if(sortedTotal<18)sortedTotal++;        
    }
    String sortedTotalStr= String.valueOf(sortedTotal);
    if(sortedTotal<=9){
        sortedTotalStr = "0"+String.valueOf(sortedTotal);                  
    }
       jlblSortedTotal.setText(sortedTotalStr);
    }catch(Exception e){
        JOptionPane.showMessageDialog(this,e.getMessage());
    }
    }//GEN-LAST:event_jlblSortedPropertyChange

    private void JmnuItemNavegateGoFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoFirstActionPerformed
        try
        {
           if(gameList.size()<=0)return;
           if(getCountOfNumberOnJlblSorted()>=15 && getCountOfNumberOnJlblSorted()<=18)
           if(registeredGameIndex==-1){
           int q=-1;
            q=JOptionPane.showConfirmDialog(this,
            new String("Deseja prosseguir? O cartao nao podera ser recuperado."),
            "",JOptionPane.YES_NO_OPTION);
            if(q==1)return;
           }
           registeredGameIndex=0;
           resetAllNumberPanel();
           Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
                setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
                if(jbtnMoveFrmToFront!=null)
                jbtnMoveFrmToFront.setText(getTitle());    
           }
        }catch(Exception e){
           JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }//GEN-LAST:event_JmnuItemNavegateGoFirstActionPerformed

    private void JmnuItemNavegateGoNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoNextActionPerformed
        try
        {
        if(registeredGameIndex<=-1)return;
        if((registeredGameIndex+1)>=gameList.size())return;
        registeredGameIndex++;
           resetAllNumberPanel();
           Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
                setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
                if(jbtnMoveFrmToFront!=null)
                jbtnMoveFrmToFront.setText(getTitle());    
           }
        }catch(Exception e){
           JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }//GEN-LAST:event_JmnuItemNavegateGoNextActionPerformed

    private void JmnuItemNavegateGoPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoPreviousActionPerformed
        try
        {
        if(registeredGameIndex<=-1)return;
        if((registeredGameIndex-1)<0)return;
        registeredGameIndex--;
           resetAllNumberPanel();
           Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
                setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
                if(jbtnMoveFrmToFront!=null)
                jbtnMoveFrmToFront.setText(getTitle());    
           }
        }catch(Exception e){
           JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }//GEN-LAST:event_JmnuItemNavegateGoPreviousActionPerformed

    private void JmnuItemNavegateGoLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoLastActionPerformed
        try
        {
           if(gameList.size()<=0)return;
           if(getCountOfNumberOnJlblSorted()>=15 && getCountOfNumberOnJlblSorted()<=18)
           if(registeredGameIndex==-1){
           int q=-1;
            q=JOptionPane.showConfirmDialog(this,
            new String("Deseja prosseguir? O cartao nao podera ser recuperado."),
            "",JOptionPane.YES_NO_OPTION);
            if(q==1)return;
           }
           registeredGameIndex=(gameList.size()-1);
           resetAllNumberPanel();
           Game game = gameList.get(registeredGameIndex);
           for(int i=0;i<18;i++){
                Integer intg=Integer.valueOf(game.getSortedNumberFromIndex(i));
                insertNumberOnJlblSorted(game.getSortedNumberFromIndex(i));
                markNumberPanel(intg);
                setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
                if(jbtnMoveFrmToFront!=null)
                jbtnMoveFrmToFront.setText(getTitle());    
           }
        }catch(Exception e){
           JOptionPane.showMessageDialog(this,e.getMessage());
        }

    }//GEN-LAST:event_JmnuItemNavegateGoLastActionPerformed

    private void JmnuItemNavegateGoToActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JmnuItemNavegateGoToActionPerformed
        try
        {
          JmnuItemNavegateGoToActionPerformedException();
        }catch(Exception e){
                 JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }//GEN-LAST:event_JmnuItemNavegateGoToActionPerformed
    private void JmnuItemNavegateGoToActionPerformedException() throws Exception {
        
            try
            {
                if(gameList.size()<=0)
                    throw new Exception("Nao ha cartao para realizar navegaçao.");
                
                String gameStr=JOptionPane.showInputDialog(this,
                new String("Digite o indice do cartao, ou um cartao com 15 ate 18"
                          +"numeros de sorteio\npara ir por pesquisa."),
               "",JOptionPane.YES_NO_OPTION);
                
                if(getCountOfNumberOnJlblSorted()>=15 
                        && getCountOfNumberOnJlblSorted()<=18)
                if(registeredGameIndex==-1){
                int q=-1;
                q=JOptionPane.showConfirmDialog(this,
                new String("Deseja prosseguir? O cartao nao podera ser recuperado."),
                "",JOptionPane.YES_NO_OPTION);
                if(q==1)return;
                }        
                
                if(!checkIfOnlyNumbers(gameStr))
                 throw new Exception("O cartao deva ser composto de somente numeros.");
                
                
                SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    JDlgWait  jdlgWait = new JDlgWait();
                    jdlgWait.setVisible(true);
                    while(!jdlgWait.isVisible());
                    
                    
                    
                    jdlgWait.dispose();
                }
                });
                
                
            }catch(Exception e){
                if(e.getMessage().isEmpty()
                        ||e.getMessage()==null)return;
                JOptionPane.showMessageDialog(this,e.getMessage());                
            }
    }

    private boolean checkIfOnlyNumbers(String sortedNumber){
        final String validCharacter="0123456789 ";
        for(int i=0;i<sortedNumber.length();i++){
            for(int j=0;j<validCharacter.length();j++){
                if(sortedNumber.charAt(i)!=validCharacter.charAt(j)
                        && j==(validCharacter.length()-1)){
                    return false;
                }else if(sortedNumber.charAt(i)==validCharacter.charAt(j)){
                    break;
                }
            }
            
        }        
        return true;
    }

    private void markNumberPanel(int number){
        if(number==1){
            jpnelNumberOne.setBackground(Color.blue);
            jpnelNumberOne1.setBackground(Color.blue);
        }else if(number==2){
            jpnelNumberTwo.setBackground(Color.blue);
            jpnelNumberTwo1.setBackground(Color.blue);
        }else if(number==3){
            jpnelNumberThree.setBackground(Color.blue);
            jpnelNumberThree1.setBackground(Color.blue);
        }else if(number==4){
            jpnelNumberFour.setBackground(Color.blue);
            jpnelNumberFour1.setBackground(Color.blue);
        }else if(number==5){
            jpnelNumberFive.setBackground(Color.blue);
            jpnelNumberFive1.setBackground(Color.blue);
        }else if(number==6){
            jpnelNumberSix.setBackground(Color.blue);
            jpnelNumberSix1.setBackground(Color.blue);
        }else if(number==7){
            jpnelNumberSeven.setBackground(Color.blue);
            jpnelNumberSeven1.setBackground(Color.blue);
        }else if(number==8){
            jpnelNumberEight.setBackground(Color.blue);
            jpnelNumberEight1.setBackground(Color.blue);
        }else if(number==9){
            jpnelNumberNine.setBackground(Color.blue);
            jpnelNumberNine1.setBackground(Color.blue);
        }else if(number==10){
            jpnelNumberTen.setBackground(Color.blue);
            jpnelNumberTen1.setBackground(Color.blue);
        }else if(number==11){
            jpnelNumberEleven.setBackground(Color.blue);
            jpnelNumberEleven1.setBackground(Color.blue);
        }else if(number==12){
            jpnelNumberTwelth.setBackground(Color.blue);
            jpnelNumberTwelth1.setBackground(Color.blue);
        }else if(number==13){
            jpnelNumberThirthTeen.setBackground(Color.blue);
            jpnelNumberThirthTeen1.setBackground(Color.blue);
        }else if(number==14){
            jpnelNumberFourTeen.setBackground(Color.blue);
            jpnelNumberFourTeen1.setBackground(Color.blue);
        }else if(number==15){
            jpnelNumberFithTeen.setBackground(Color.blue);
            jpnelNumberFithTeen1.setBackground(Color.blue);
        }else if(number==16){
            jpnelNumberSixTeen.setBackground(Color.blue);
            jpnelNumberSixTeen1.setBackground(Color.blue);
        }else if(number==17){
            jpnelNumberSevenTeen.setBackground(Color.blue);
            jpnelNumberSevenTeen1.setBackground(Color.blue);
        }else if(number==18){
            jpnelNumberEightTeen.setBackground(Color.blue);
            jpnelNumberEightTeen1.setBackground(Color.blue);
        }else if(number==19){
            jpnelNumberNineTeen.setBackground(Color.blue);
            jpnelNumberNineTeen1.setBackground(Color.blue);
        }else if(number==20){
            jpnelNumberTwenty.setBackground(Color.blue);
            jpnelNumberTwenty1.setBackground(Color.blue);
        }else if(number==21){
            jpnelNumberTwentyOne.setBackground(Color.blue);
            jpnelNumberTwentyOne1.setBackground(Color.blue);
        }else if(number==22){
            jpnelNumberTwentyTwo.setBackground(Color.blue);
            jpnelNumberTwentyTwo1.setBackground(Color.blue);
        }else if(number==23){
            jpnelNumberTwentyThree.setBackground(Color.blue);
            jpnelNumberTwentyThree1.setBackground(Color.blue);
        }else if(number==24){
            jpnelNumberTwentyFour.setBackground(Color.blue);
            jpnelNumberTwentyFour1.setBackground(Color.blue);
        }else if(number==25){
            jpnelNumberTwentyFive.setBackground(Color.blue);
            jpnelNumberTwentyFive1.setBackground(Color.blue);
        }
    }
    
    public void setGameName(String title){
        this.title=title;
        setTitle(String.valueOf(registeredGameIndex)+":"+String.valueOf(gameList.size())+" "+title);
        if(jbtnMoveFrmToFront!=null)
        jbtnMoveFrmToFront.setText(getTitle());    
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuBar JmnuBarGame;
    private javax.swing.JMenuItem JmnuItemCardDelete;
    private javax.swing.JMenuItem JmnuItemCardNew;
    private javax.swing.JMenuItem JmnuItemCardSave;
    private javax.swing.JMenuItem JmnuItemCardUndo;
    private javax.swing.JMenuItem JmnuItemNavegateGoFirst;
    private javax.swing.JMenuItem JmnuItemNavegateGoLast;
    private javax.swing.JMenuItem JmnuItemNavegateGoNext;
    private javax.swing.JMenuItem JmnuItemNavegateGoPrevious;
    private javax.swing.JMenuItem JmnuItemNavegateGoTo;
    private javax.swing.JLabel jlblNumberEight;
    private javax.swing.JLabel jlblNumberEight1;
    private javax.swing.JLabel jlblNumberEightTeen;
    private javax.swing.JLabel jlblNumberEightTeen1;
    private javax.swing.JLabel jlblNumberEleven;
    private javax.swing.JLabel jlblNumberEleven1;
    private javax.swing.JLabel jlblNumberFithTeen;
    private javax.swing.JLabel jlblNumberFithTeen1;
    private javax.swing.JLabel jlblNumberFive;
    private javax.swing.JLabel jlblNumberFive1;
    private javax.swing.JLabel jlblNumberFour;
    private javax.swing.JLabel jlblNumberFour1;
    private javax.swing.JLabel jlblNumberFourTeen;
    private javax.swing.JLabel jlblNumberFourTeen1;
    private javax.swing.JLabel jlblNumberNine;
    private javax.swing.JLabel jlblNumberNine1;
    private javax.swing.JLabel jlblNumberNineTeen;
    private javax.swing.JLabel jlblNumberNineTeen1;
    private javax.swing.JLabel jlblNumberOne;
    private javax.swing.JLabel jlblNumberOne1;
    private javax.swing.JLabel jlblNumberSeven;
    private javax.swing.JLabel jlblNumberSeven1;
    private javax.swing.JLabel jlblNumberSevenTeen;
    private javax.swing.JLabel jlblNumberSevenTeen1;
    private javax.swing.JLabel jlblNumberSix;
    private javax.swing.JLabel jlblNumberSix1;
    private javax.swing.JLabel jlblNumberSixTeen;
    private javax.swing.JLabel jlblNumberSixTeen1;
    private javax.swing.JLabel jlblNumberTen;
    private javax.swing.JLabel jlblNumberTen1;
    private javax.swing.JLabel jlblNumberThirthTeen;
    private javax.swing.JLabel jlblNumberThirthTeen1;
    private javax.swing.JLabel jlblNumberThree;
    private javax.swing.JLabel jlblNumberThree1;
    private javax.swing.JLabel jlblNumberTwelth;
    private javax.swing.JLabel jlblNumberTwelth1;
    private javax.swing.JLabel jlblNumberTwenty;
    private javax.swing.JLabel jlblNumberTwenty1;
    private javax.swing.JLabel jlblNumberTwentyFive;
    private javax.swing.JLabel jlblNumberTwentyFive1;
    private javax.swing.JLabel jlblNumberTwentyFour;
    private javax.swing.JLabel jlblNumberTwentyFour1;
    private javax.swing.JLabel jlblNumberTwentyOne;
    private javax.swing.JLabel jlblNumberTwentyOne1;
    private javax.swing.JLabel jlblNumberTwentyThree;
    private javax.swing.JLabel jlblNumberTwentyThree1;
    private javax.swing.JLabel jlblNumberTwentyTwo;
    private javax.swing.JLabel jlblNumberTwentyTwo1;
    private javax.swing.JLabel jlblNumberTwo;
    private javax.swing.JLabel jlblNumberTwo1;
    private javax.swing.JLabel jlblNumberView;
    private javax.swing.JLabel jlblPrice15;
    private javax.swing.JLabel jlblPrice16;
    private javax.swing.JLabel jlblPrice17;
    private javax.swing.JLabel jlblPrice18;
    private javax.swing.JLabel jlblSorted;
    private javax.swing.JLabel jlblSortedTotal;
    private javax.swing.JLabel jlblSymbolismFour;
    private javax.swing.JLabel jlblSymbolismOne;
    private javax.swing.JLabel jlblSymbolismThree;
    private javax.swing.JLabel jlblSymbolismTwo;
    private javax.swing.JLabel jlblViewPincel;
    private javax.swing.JLabel jlblViewPincelBlue;
    private javax.swing.JLabel jlblViewPincelRed;
    private javax.swing.JLabel jlblViewPrice;
    private javax.swing.JLabel jlblViewSignalSymbol;
    private javax.swing.JMenu jmnuCard;
    private javax.swing.JMenu jmnuNavegate;
    private javax.swing.JPanel jpnelNumber;
    private javax.swing.JPanel jpnelNumberEight;
    private javax.swing.JPanel jpnelNumberEight1;
    private javax.swing.JPanel jpnelNumberEightTeen;
    private javax.swing.JPanel jpnelNumberEightTeen1;
    private javax.swing.JPanel jpnelNumberEleven;
    private javax.swing.JPanel jpnelNumberEleven1;
    private javax.swing.JPanel jpnelNumberFithTeen;
    private javax.swing.JPanel jpnelNumberFithTeen1;
    private javax.swing.JPanel jpnelNumberFive;
    private javax.swing.JPanel jpnelNumberFive1;
    private javax.swing.JPanel jpnelNumberFour;
    private javax.swing.JPanel jpnelNumberFour1;
    private javax.swing.JPanel jpnelNumberFourTeen;
    private javax.swing.JPanel jpnelNumberFourTeen1;
    private javax.swing.JPanel jpnelNumberNine;
    private javax.swing.JPanel jpnelNumberNine1;
    private javax.swing.JPanel jpnelNumberNineTeen;
    private javax.swing.JPanel jpnelNumberNineTeen1;
    private javax.swing.JPanel jpnelNumberOne;
    private javax.swing.JPanel jpnelNumberOne1;
    private javax.swing.JPanel jpnelNumberSeven;
    private javax.swing.JPanel jpnelNumberSeven1;
    private javax.swing.JPanel jpnelNumberSevenTeen;
    private javax.swing.JPanel jpnelNumberSevenTeen1;
    private javax.swing.JPanel jpnelNumberSix;
    private javax.swing.JPanel jpnelNumberSix1;
    private javax.swing.JPanel jpnelNumberSixTeen;
    private javax.swing.JPanel jpnelNumberSixTeen1;
    private javax.swing.JPanel jpnelNumberTen;
    private javax.swing.JPanel jpnelNumberTen1;
    private javax.swing.JPanel jpnelNumberThirthTeen;
    private javax.swing.JPanel jpnelNumberThirthTeen1;
    private javax.swing.JPanel jpnelNumberThree;
    private javax.swing.JPanel jpnelNumberThree1;
    private javax.swing.JPanel jpnelNumberTwelth;
    private javax.swing.JPanel jpnelNumberTwelth1;
    private javax.swing.JPanel jpnelNumberTwenty;
    private javax.swing.JPanel jpnelNumberTwenty1;
    private javax.swing.JPanel jpnelNumberTwentyFive;
    private javax.swing.JPanel jpnelNumberTwentyFive1;
    private javax.swing.JPanel jpnelNumberTwentyFour;
    private javax.swing.JPanel jpnelNumberTwentyFour1;
    private javax.swing.JPanel jpnelNumberTwentyOne;
    private javax.swing.JPanel jpnelNumberTwentyOne1;
    private javax.swing.JPanel jpnelNumberTwentyThree;
    private javax.swing.JPanel jpnelNumberTwentyThree1;
    private javax.swing.JPanel jpnelNumberTwentyTwo;
    private javax.swing.JPanel jpnelNumberTwentyTwo1;
    private javax.swing.JPanel jpnelNumberTwo;
    private javax.swing.JPanel jpnelNumberTwo1;
    private javax.swing.JPanel jpnelSorted;
    private javax.swing.JPanel jpnelSymbolism;
    private javax.swing.JPanel jpnelSymbolismFourBlue;
    private javax.swing.JPanel jpnelSymbolismFourRed;
    private javax.swing.JPanel jpnelSymbolismOneBlue1;
    private javax.swing.JPanel jpnelSymbolismOneBlue2;
    private javax.swing.JPanel jpnelSymbolismThreeRed1;
    private javax.swing.JPanel jpnelSymbolismThreeRed2;
    private javax.swing.JPanel jpnelSymbolismTwoBlue;
    private javax.swing.JPanel jpnelSymbolismTwoRed;
    private javax.swing.JPanel jpnelView;
    private javax.swing.JPanel jpnelViewPincelBlue;
    private javax.swing.JPanel jpnelViewPincelRed;
    // End of variables declaration//GEN-END:variables
}
