package view;

import java.awt.Color;
import java.awt.FlowLayout;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import model.JBtnMoveFrmToFront;


public class Main extends JFrame{

    private static final String WINDOWTITLE = "Loteria Lotofacil";
    private static final int WINDOWWIDTH = 1200;
    private static final int WINDOWHEIGHT = 680;
    
    private JMenuBar        jmnubarMain;
    private JMenu           jmnuGame;
    private JMenuItem       jmnuGameNew;
    private JMenuItem       jmnuGameImport;
    private JMenuItem       jmnuGameExport;
    private JMenuItem       jmnuGameExit;
    private JMenuItem       jmnuGameSave;
    private JMenuItem       jmnuGameSaveAs;
    private JPanel  jlstGameWindowLister;
    private JScrollPane     jlstGameWindowListerScrollPane;   
    private JDesktopPane    jdskpne;
            
    public Main(){
        super(WINDOWTITLE);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setBounds(0,0,WINDOWWIDTH,WINDOWHEIGHT);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        
        jdskpne = new JDesktopPane();
        jdskpne.setName("DesktopPane");
        jdskpne.setBackground(Color.WHITE);
        
        jlstGameWindowLister = new JPanel();
        jlstGameWindowLister.setName("jlstGameWindowLister");
        jlstGameWindowLister.setBackground(Color.LIGHT_GRAY);
        jlstGameWindowLister.setForeground(Color.BLACK);
        jlstGameWindowListerScrollPane = new JScrollPane();
        jlstGameWindowListerScrollPane.setViewportView(jlstGameWindowLister);
        BoxLayout jlstGameWindowListerLayout = new BoxLayout(jlstGameWindowLister,BoxLayout.Y_AXIS);
        jlstGameWindowLister.setLayout(jlstGameWindowListerLayout);
        
        
        jmnubarMain = new JMenuBar();
        jmnuGame = new JMenu();
        jmnuGameNew = new JMenuItem();
        jmnuGameImport = new JMenuItem();
        jmnuGameExport = new JMenuItem();
        jmnuGameExit = new JMenuItem();
        jmnuGameSave = new JMenuItem();
        jmnuGameSave.setText("Salvar");
        jmnuGameSave.setEnabled(false);
        jmnuGameSaveAs = new JMenuItem();
        jmnuGameSaveAs.setText("Salvar Como");
        jmnuGameSaveAs.setEnabled(false);
        jmnuGameNew.setText("Novo");
        jmnuGameImport.setText("Importar");
        jmnuGameExport.setText("Exportar");
        jmnuGameExport.setEnabled(false);
        jmnuGameExit.setText("Sair");
        jmnuGame.setText("Jogo");
        jmnuGame.add(jmnuGameNew);
        jmnuGame.add(jmnuGameImport);
        jmnuGame.add(jmnuGameExport);
        jmnuGame.add(jmnuGameSave);
        jmnuGame.add(jmnuGameSaveAs);
        jmnuGame.add(jmnuGameExit);
    
        jmnuGameSave.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        jmnuGameSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuGameSaveAction(evt);
            }
        });
        
        jmnuGameSaveAs.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        jmnuGameSaveAs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuGameSaveAsAction(evt);
            }
        });
        
        jmnuGameNew.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        jmnuGameNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuGameNewAction(evt);
            }
        });
        jmnuGameImport.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        jmnuGameImport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuGameImportAction(evt);
            }
        });
        
        jmnuGameExport.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        jmnuGameExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuGameExportAction(evt);
            }
        });
        
        jmnuGameExit.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        jmnuGameExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmnuGameExitAction(evt);
            }
        });
        jmnubarMain.add(jmnuGame);
        setJMenuBar(jmnubarMain);
        
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jlstGameWindowListerScrollPane, GroupLayout.PREFERRED_SIZE, 208, GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(ComponentPlacement.RELATED)
                .addComponent(jdskpne))
            
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addComponent(jdskpne)
            .addComponent(jlstGameWindowListerScrollPane,GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );

        GroupLayout jdskpneLayout = new GroupLayout(jdskpne);
        jdskpne.setLayout(jdskpneLayout);
        jdskpneLayout.setHorizontalGroup(
            jdskpneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 202, Short.MAX_VALUE)
        );
        jdskpneLayout.setVerticalGroup(
            jdskpneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 279, Short.MAX_VALUE)
        );
        
        pack();
        
    }
    
    private void jmnuGameNewAction(java.awt.event.ActionEvent evt){
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JIFrmGame  frm = new JIFrmGame(jdskpne);
                JBtnMoveFrmToFront jbtn = new JBtnMoveFrmToFront(frm); 
                frm.setJbtnMoveFrmToFront(jbtn);
                jlstGameWindowLister.add(jbtn);                        
            }
        });
        
    }
    private void jmnuGameImportAction(java.awt.event.ActionEvent evt){
           JOptionPane.showMessageDialog(this,"Importar");
    }
    private void jmnuGameExportAction(java.awt.event.ActionEvent evt){
           JOptionPane.showMessageDialog(this,"Exportar");
    }
    private void jmnuGameSaveAction(java.awt.event.ActionEvent evt){
           JOptionPane.showMessageDialog(this,"Salvar");
    }
    private void jmnuGameSaveAsAction(java.awt.event.ActionEvent evt){
           JOptionPane.showMessageDialog(this,"Salvar Comor");
    }
    private void jmnuGameExitAction(java.awt.event.ActionEvent evt){
           this.dispose();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    private void addWindowListener() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
