package model;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;
import java.lang.management.GarbageCollectorMXBean;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import view.JIFrmGame;

/**
 *
 * @author felipe
 */
public class JBtnMoveFrmToFront extends JButton {
    private String title;
    private JIFrmGame jintrnFrmGame;
    public JBtnMoveFrmToFront(JIFrmGame frm){
        super(frm.getTitle());
        this.title=frm.getTitle();
        this.jintrnFrmGame = frm;
        setMaximumSize(new Dimension(205,70));
        setMinimumSize(new Dimension(205,70));
        setPreferredSize(new Dimension(190,70));
        
        this.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent ae) {
                SwingUtilities.invokeLater(new Runnable() {
                @Override
                 public void run() {
                    try {
                        JBtnMoveFrmToFront.this.jintrnFrmGame.setIcon(false);
                        JBtnMoveFrmToFront.this.jintrnFrmGame.moveToFront();
                        JBtnMoveFrmToFront.this.jintrnFrmGame.grabFocus();
                    } catch (PropertyVetoException ex) {
                        JOptionPane.showMessageDialog(null,ex.getMessage());
                    }
                  }
                 });
                  
            }
        });
    }

    public void destroy(){
        this.setVisible(false);
        System.gc();
    }
}
