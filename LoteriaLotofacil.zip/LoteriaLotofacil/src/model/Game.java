/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author felipe
 */
public class Game {

    private String sortedNumber;
    private float  price;
    private int    sortedNumberGroup;
    private static String MSGSORTEDNUMBERINDEXOUTOFRANGE="Game.java\nindice de numero sorteado fora da faixa";
    private static String MSGCHEKIFONLYNUMBERS="Game.java\ncartao deve ser composto de somente numeros.";
    private static String MSGCOUNTOFSORTEDNUMBERSOUTOFRANGE="Game.java\ncartao deve ser composto dentre 15 a 18 numeros.";        
    public Game(){
        sortedNumber=null;
        price=0;
        sortedNumberGroup=0;
    }
    
    public Game(String sortedNumber) throws Exception{
        
        this.sortedNumber=sortedNumber;
        
        if(!checkIfOnlyNumbers()) {
            this.sortedNumber=null;
            throw new Exception(MSGCHEKIFONLYNUMBERS
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        
        
        if(getCountOfSortedNumber()>18 || getCountOfSortedNumber()<15){
            this.sortedNumber=null;
        throw new Exception(MSGCOUNTOFSORTEDNUMBERSOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));    
        }
        orderSortedNumber();
        calculateGamePrice();
        calculateSortedNumberGroup();        
        
    }

    public String getSortedNumber() {
        return sortedNumber;
    }

    public void setSortedNumber(String sortedNumber) throws Exception {
        this.sortedNumber = sortedNumber;
        
        if(!checkIfOnlyNumbers()) {
            throw new Exception(MSGCHEKIFONLYNUMBERS
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
        
        
        if(getCountOfSortedNumber()>18 || getCountOfSortedNumber()<15){
            throw new Exception(MSGCOUNTOFSORTEDNUMBERSOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));    
        }
        orderSortedNumber();
        calculateGamePrice();
        calculateSortedNumberGroup();        
    }

    public float getPrice() {
        return price;
    }

    private void setPrice(float price) {
        this.price = price;
    }

    public int getSortedNumberGroup() {
        return sortedNumberGroup;
    }

    private void setSortedNumberGroup(int sortedNumberGroup) {
        this.sortedNumberGroup = sortedNumberGroup;
    }
    
    private void calculateGamePrice()throws Exception{
       calculateSortedNumberGroup();
        if(getSortedNumberGroup()==15)
         setPrice((float)2.00);   
        if(getSortedNumberGroup()==16)
         setPrice((float)32.00);   
        if(getSortedNumberGroup()==17)
         setPrice((float)272.00);   
        if(getSortedNumberGroup()==18)
         setPrice((float)1632.00);   
    }
    
    private void calculateSortedNumberGroup()throws Exception{
        String str="";
        String strRet="";
        Integer intg=0;
        for(int i=0;i<18;i++){
            String str2=getSortedNumberFromIndex(i);
            intg=Integer.valueOf(str2);
            if(intg>0)str+=str2+" ";
        }
        for(int i=0;i<str.length();i++)
        if(str.charAt(i)!=' ')
        strRet+=String.valueOf(str.charAt(i));
        setSortedNumberGroup(strRet.length()/2);        
    }
    
    private void orderSortedNumber() throws Exception{
        
        if(!checkIfOnlyNumbers())return;    
        
        if(getCountOfSortedNumber()!=15 && 
                getCountOfSortedNumber()!=16 &&
                getCountOfSortedNumber()!=17 &&
                getCountOfSortedNumber()!=18)
        throw new Exception(MSGCOUNTOFSORTEDNUMBERSOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        
        String order="";
        
                for(int i=1;i<26;i++){
                    if(existNumberOnSortedNumber(i))
                    if(i<=9)
                    order+=String.valueOf("0"+i)+" ";
                    else
                    order+=String.valueOf(i)+" ";    
                }
        
        this.sortedNumber=order;        
        for(int i=0;i<(18-getCountOfSortedNumber());i++){
            order+="00 ";    
        }
        this.sortedNumber="";
        for(int i=0;i<(order.length()-1);i++){
            this.sortedNumber+=String.valueOf(order.charAt(i));
        }
    }
    
    public int getCountOfMatchedSortedNumber(String matchNumber) throws Exception{
       
       int ret=0; 
       
       if(this.sortedNumber==null)return ret;
       
       String tmpStr=this.sortedNumber;
       this.sortedNumber=matchNumber;
       
       if(!checkIfOnlyNumbers()) {
           this.sortedNumber=tmpStr;
            throw new Exception(MSGCHEKIFONLYNUMBERS
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
       
       if(getCountOfSortedNumber()!=15 ){
           this.sortedNumber=tmpStr;
           throw new Exception(MSGCOUNTOFSORTEDNUMBERSOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
       }
       
       for(int i=0;i<15;i++){
           if(tmpStr.contains(getSortedNumberFromIndex(i)))ret++;
       }
       
       this.sortedNumber=tmpStr;
       
       return ret;
    }
    
    public String importSortedNumber(String imported) throws Exception{
        javax.swing.JOptionPane.showMessageDialog(null,this.sortedNumber);
       String tmpStr="";
       String ret="";
       for(int i=0;i<imported.length();i++){
          if(imported.charAt(i)==','){
              if(i==1){
              tmpStr+="0"+String.valueOf(imported.charAt(i-1))+" ";
              }else{
                  if(imported.charAt(i-2)==',')
                  tmpStr+="0"+String.valueOf(imported.charAt(i-1))+" ";    
                  else
                  tmpStr+=String.valueOf(imported.charAt(i-2))+String.valueOf(imported.charAt(i-1))+" ";        
              }
              
          }
       }
       if(imported.charAt(imported.length()-2)==','){
         tmpStr+="0"+String.valueOf(imported.charAt(imported.length()-1));        
       }else if(imported.charAt(imported.length()-2)!=','){
           tmpStr+=String.valueOf(imported.charAt(imported.length()-2));        
           tmpStr+=String.valueOf(imported.charAt(imported.length()-1));
       }
       String tmpStr2=this.sortedNumber;
       this.sortedNumber=tmpStr;
       
       if(!checkIfOnlyNumbers()) {
           this.sortedNumber=tmpStr2;
            throw new Exception(MSGCHEKIFONLYNUMBERS
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }
       
       if(getCountOfSortedNumber()!=15
               && getCountOfSortedNumber()!=16
               && getCountOfSortedNumber()!=17
               && getCountOfSortedNumber()!=18){
           this.sortedNumber=tmpStr2;
           throw new Exception(MSGCOUNTOFSORTEDNUMBERSOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
       }
       orderSortedNumber();
       tmpStr=this.sortedNumber;
       this.sortedNumber=tmpStr2;
       ret=tmpStr;
       javax.swing.JOptionPane.showMessageDialog(null,this.sortedNumber);
       return ret;
    }
    
    public String exportSortedNumber() throws Exception{
        if(!checkIfOnlyNumbers())return null;    
        
        if(getCountOfSortedNumber()!=15 && 
                getCountOfSortedNumber()!=16 &&
                getCountOfSortedNumber()!=17 &&
                getCountOfSortedNumber()!=18){return null;}
        
        String tmp="";
        String ret="";
        
        for(int i=0;i<18;i++)
        {
            String str=getSortedNumberFromIndex(i);
            Integer intg=Integer.valueOf(str);
            if(intg!=0)tmp+=String.valueOf(intg)+",";            
        }
        for(int i=0;i<(tmp.length()-1);i++){
            ret+=String.valueOf(tmp.charAt(i));            
        }
        return ret;
    }
    
    private boolean existNumberOnSortedNumber(int number)throws Exception{
        for(int i=0;i<18;i++){
            String str=getSortedNumberFromIndex(i);
            Integer intg=Integer.valueOf(str);
            if(intg==number)return true;
        }
        return false;
    }
    private boolean checkIfCrescentOrder()throws Exception{
        boolean ret = true;
        
        for(int i=0;i<=16;i++){
            if(!getSortedNumberFromIndex(i).equalsIgnoreCase("00"))
            if(Integer.valueOf(getSortedNumberFromIndex(i))<
                        Integer.valueOf(getSortedNumberFromIndex(i+1))){
                      continue;  
                }else {
                    ret=false;
                    break;
                }                    
        }
        
        return ret;
        
    }
    
    private int getCountOfSortedNumber() throws Exception{
        if(!checkIfOnlyNumbers()) throw new Exception(MSGCHEKIFONLYNUMBERS
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        
        String str="";
        for(int i=0;i<this.sortedNumber.length();i++){
            if(this.sortedNumber.charAt(i)!=' '){
                str+=String.valueOf(this.sortedNumber.charAt(i));
            }
        }
        
        if((str.length()%2)!=0) throw new 
        Exception("Game.java\n"+
        "A composiçao do numero de sorteio deve ser em sua unidade dois digitos."        
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        
        int ret=0;
        for(int i=0;i<str.length();i+=2)
        if(Integer.valueOf(String.valueOf(str.substring(i,i+2)))>0)
        ret++;
        
        return ret;
    }
    
    public String getSortedNumberFromIndex(int index)throws Exception{
        String ret="";
        
        if(index<0 || index>17){
        throw new Exception(MSGSORTEDNUMBERINDEXOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }   
        String sortedStr = "";
        for(int i=0;i<this.sortedNumber.length();i++){
            if(this.sortedNumber.charAt(i)!=' ')
            sortedStr+=this.sortedNumber.charAt(i);    
        }
        index*=2;
        try
        {
           ret = sortedStr.substring(index,index+2);
        }catch(Exception e)
        {
            ret = this.sortedNumber.substring(this.sortedNumber.length()-2,this.sortedNumber.length());
        }
        return ret;        
    }
    
    private void removeSortedNumberFromIndex(int index)throws Exception{
        String ret="";
        if(index<0 || index>17){
        throw new Exception(MSGSORTEDNUMBERINDEXOUTOFRANGE
        +"\n"+"linha:"+
        String.valueOf(Thread.currentThread().getStackTrace()[1].getLineNumber()));
        }   
        int i=0;
        for(i=0;i<index;i++){
            ret+=getSortedNumberFromIndex(i)+" ";
        }
        for(i++;i<18;i++){
            ret+=getSortedNumberFromIndex(i)+" ";
        }
        this.sortedNumber=ret+"00";
    }
    
    private void setSortedNumberFromIndex(int index,String number)throws Exception{
        String ret="";
        if(index<0 || index>17)return;
        int i=0;
        for(i=0;i<index;i++){
            ret+=getSortedNumberFromIndex(i)+" ";
        }
        ret+=number+" ";
        for(++i;i<18;i++){
            ret+=getSortedNumberFromIndex(i)+" ";
        }
        this.sortedNumber=ret; 
    }
    
    private boolean checkIfOnlyNumbers(){
        final String validCharacter="0123456789 ";
        for(int i=0;i<sortedNumber.length();i++){
            for(int j=0;j<validCharacter.length();j++){
                if(sortedNumber.charAt(i)!=validCharacter.charAt(j)
                        && j==(validCharacter.length()-1)){
                    return false;
                }else if(sortedNumber.charAt(i)==validCharacter.charAt(j)){
                    break;
                }
            }
            
        }        
        return true;
    }
}
